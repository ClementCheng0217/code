#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""LocalTabICLv2Model：TabICLv2Model 的本地包装。

beyondarena 部分数据集（如 audiology_diagnosis、anes_voting_2026）含 string
特征列，AG preprocess 后仍保留 object dtype，tabicl 的 X_encoder_.transform
在 predict 时对非数值列做 isnan 检查导致崩溃
（"ufunc 'isnan' not supported" / "'<' not supported between 'float' and 'str'"）。

这里覆写 preprocess：AG 在 fit 与 predict 两个路径都会调用它，
输出前把所有非数值列转为数值（category -> codes，其余 pd.to_numeric coerce）。
"""

import pandas as pd

from tabarena.models.tabicl.model import TabICLv2Model


def _to_numeric_df(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col in df.columns:
        if pd.api.types.is_categorical_dtype(df[col].dtype):
            df[col] = df[col].cat.codes
        elif not pd.api.types.is_numeric_dtype(df[col].dtype):
            df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


class LocalTabICLv2Model(TabICLv2Model):
    """TabICL v2 包装：preprocess 后数值化所有列（修复 string 列崩溃）。"""

    ag_key = "TA-TABICLv2"
    ag_name = "TA-TabICLv2"

    def preprocess(self, X, y=None, **kwargs):
        X = super().preprocess(X, y=y, **kwargs)
        if isinstance(X, pd.DataFrame):
            X = _to_numeric_df(X)
        return X
