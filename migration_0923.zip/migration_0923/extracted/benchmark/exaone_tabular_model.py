"""AutoGluon/TabArena adapter for the official EXAONE-Tabular runtime."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

import numpy as np
from autogluon.common.utils.resource_utils import ResourceManager
from autogluon.features.generators import LabelEncoderFeatureGenerator
from autogluon.tabular.models.abstract.abstract_torch_model import (
    AbstractTorchModel,
)

if TYPE_CHECKING:
    import pandas as pd


class LocalEXAONETabularModel(AbstractTorchModel):
    """Expose EXAONE-Tabular through TabArena's AutoGluon model interface.

    The official estimator accepts numeric NumPy arrays only.  TabArena can
    supply pandas categoricals, so this adapter learns a stable ordinal mapping
    on the training split before handing the table to EXAONE's own
    preprocessing.  Missing numeric values remain NaN and are handled by the
    official runtime.
    """

    ag_key = "LOCAL-EXAONE-TABULAR"
    ag_name = "Local-EXAONE-Tabular"
    ag_priority = 100
    seed_name = "random_state"

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._feature_generator: LabelEncoderFeatureGenerator | None = None

    def _preprocess(
        self,
        X: pd.DataFrame,
        *,
        is_train: bool = False,
        **kwargs: Any,
    ) -> np.ndarray:
        X = super()._preprocess(X, **kwargs)

        if is_train:
            self._feature_generator = LabelEncoderFeatureGenerator(verbosity=0)
            self._feature_generator.fit(X=X)
        if self._feature_generator is None:
            raise RuntimeError("EXAONE-Tabular preprocessor has not been fitted")

        if self._feature_generator.features_in:
            X = X.copy()
            X[self._feature_generator.features_in] = (
                self._feature_generator.transform(X=X)
            )
        return np.asarray(X.to_numpy(), dtype=np.float32)

    def _fit(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        num_cpus: int = 1,
        num_gpus: int = 0,
        **kwargs: Any,
    ) -> None:
        del num_cpus, kwargs
        import torch
        from exaonetabular import (
            EXAONETabularClassifier,
            EXAONETabularRegressor,
        )

        available_num_gpus = ResourceManager.get_gpu_count_torch(cuda_only=True)
        if num_gpus > available_num_gpus:
            raise AssertionError(
                f"Fit requested {num_gpus} GPU, but only "
                f"{available_num_gpus} CUDA GPUs are available."
            )
        if num_gpus and not torch.cuda.is_available():
            raise AssertionError(
                "EXAONE-Tabular requested a GPU, but CUDA is unavailable."
            )
        device = "cuda" if num_gpus else "cpu"

        hps = dict(self._get_model_params())
        checkpoint_path = hps.pop("checkpoint_path", None)
        if checkpoint_path is None:
            checkpoint_path = hps.pop("model_path", None)
        if checkpoint_path is None:
            checkpoint_path = hps.pop("weights", None)
        if checkpoint_path is None:
            raise ValueError("LocalEXAONETabularModel requires checkpoint_path")
        checkpoint = Path(checkpoint_path).expanduser().resolve()
        if not checkpoint.is_file():
            raise FileNotFoundError(checkpoint)

        random_state = int(hps.pop(self.seed_name, 0))
        n_estimators = hps.pop("n_estimators", None)
        ensemble_count = hps.pop("ensemble_count", None)
        if (
            n_estimators is not None
            and ensemble_count is not None
            and int(n_estimators) != int(ensemble_count)
        ):
            raise ValueError(
                "n_estimators and ensemble_count specify different values"
            )
        if ensemble_count is None and n_estimators is not None:
            ensemble_count = int(n_estimators)

        # The official CUDA path is validated in half precision; its CPU path
        # requires float32 because the fused half-precision attention kernels
        # are CUDA-only.
        compute_dtype = hps.pop(
            "compute_dtype",
            "float16" if device == "cuda" else "float32",
        )
        max_vram_bytes = hps.pop("max_vram_bytes", None)
        cache_dir = hps.pop("cache_dir", None)
        hps.pop("n_jobs", None)
        if hps:
            raise ValueError(
                "Unknown EXAONE-Tabular hyperparameters: "
                f"{sorted(hps)}"
            )

        model_kwargs: dict[str, Any] = {
            "weights": str(checkpoint),
            "device": device,
            "compute_dtype": compute_dtype,
            "seed": random_state,
            "max_vram_bytes": max_vram_bytes,
        }
        if ensemble_count is not None:
            model_kwargs["ensemble_count"] = int(ensemble_count)
        if cache_dir is not None:
            model_kwargs["cache_dir"] = str(cache_dir)

        is_classification = self.problem_type in {"binary", "multiclass"}
        estimator_cls = (
            EXAONETabularClassifier
            if is_classification
            else EXAONETabularRegressor
        )
        self.model = estimator_cls.from_pretrained(**model_kwargs)
        X_processed = self.preprocess(X, y=y, is_train=True)
        target = np.asarray(
            y,
            dtype=None if is_classification else np.float32,
        )
        self.model.fit(X_processed, target)

    def _predict_proba(
        self,
        X: pd.DataFrame,
        **kwargs: Any,
    ) -> np.ndarray:
        del kwargs
        if self.problem_type in {"binary", "multiclass"}:
            prediction = self.model.predict_proba(self.preprocess(X))
        else:
            prediction = self.model.predict(self.preprocess(X))
        return self._convert_proba_to_unified_form(np.asarray(prediction))

    @classmethod
    def supported_problem_types(cls) -> list[str]:
        # The wrapper is ready for both official estimator APIs.  Model
        # discovery currently exposes classification only because LG AI
        # Research has not published the regression checkpoint yet.
        return ["binary", "multiclass", "regression"]

    def _get_default_resources(self) -> tuple[int, int]:
        num_cpus = ResourceManager.get_cpu_count(only_physical_cores=True)
        num_gpus = min(
            1,
            ResourceManager.get_gpu_count_torch(cuda_only=True),
        )
        return num_cpus, num_gpus

    def get_minimum_resources(
        self,
        is_gpu_available: bool = False,
    ) -> dict[str, int | float]:
        return {
            "num_cpus": 1,
            "num_gpus": 1 if is_gpu_available else 0,
        }

    def get_device(self) -> str:
        if self.model is None:
            return "cpu"
        return str(self.model.device)

    def _set_device(self, device: str) -> None:
        if self.model is None:
            return
        import torch

        resolved = torch.device(device)
        self.model.device = resolved
        self.model.model.to(resolved)

    @classmethod
    def _get_default_ag_args_ensemble(cls, **kwargs: Any) -> dict[str, Any]:
        defaults = super()._get_default_ag_args_ensemble(**kwargs)
        defaults.update(
            {
                "fold_fitting_strategy": "sequential_local",
                "refit_folds": defaults.pop("refit_folds", True),
            }
        )
        return defaults

    def _more_tags(self) -> dict[str, bool]:
        return {"can_refit_full": True}
