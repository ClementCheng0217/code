#!/bin/bash
# 查看 raw_results.json 大小/内容 + _runs 目录结构
BASE=/ssd/lamdatfm/chengzj/benchmark/benchmark_results
for d in \
  beyondarena_reg_s1_260808_float32 \
  beyondarena_reg_s1_260813_muon \
  beyondarena_reg_s2_260815_float32 \
  beyondarena_reg_s3_260820_float32 \
  beyondarena_260814_s3amp \
  beyondarena_cls_s1_260817 \
  beyondarena_cls_s3_260819 ; do
  echo "========== $d =========="
  SUB=$(ls $BASE/$d/beyondarena/ | grep -v per_dataset | head -1)
  RAW=$BASE/$d/beyondarena/$SUB/raw_results.json
  ls -la $RAW 2>/dev/null
  echo "--- raw_results.json 前 500 字符 ---"
  head -c 500 $RAW 2>/dev/null
  echo
  echo "--- _runs 目录 ---"
  ls $BASE/$d/beyondarena/$SUB/_runs/ 2>/dev/null | head -8
  echo "--- _runs 内一个文件 ---"
  F=$(ls $BASE/$d/beyondarena/$SUB/_runs/ 2>/dev/null | head -1)
  ls -la "$BASE/$d/beyondarena/$SUB/_runs/$F" 2>/dev/null
  echo
done
