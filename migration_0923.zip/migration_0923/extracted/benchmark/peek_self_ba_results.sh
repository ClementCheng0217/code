#!/bin/bash
# 查看 reg 4 模型 + 260814 的 summary.json 和 raw_results.json 结构
PY=/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python
BASE=/ssd/lamdatfm/chengzj/benchmark/benchmark_results
for d in \
  beyondarena_reg_s1_260808_float32 \
  beyondarena_reg_s1_260813_muon \
  beyondarena_reg_s2_260815_float32 \
  beyondarena_reg_s3_260820_float32 \
  beyondarena_260814_s3amp ; do
  echo "========== $d =========="
  SUB=$(ls $BASE/$d/beyondarena/ | grep -v per_dataset | head -1)
  echo "--- summary.json ---"
  cat $BASE/$d/beyondarena/$SUB/summary.json
  echo
  echo "--- raw_results.json 结构 ---"
  $PY - <<'EOF'
import json, sys, os
path = sys.argv[1]
d = json.load(open(path))
print("type:", type(d).__name__, "len:", len(d) if hasattr(d, "__len__") else "?")
if isinstance(d, dict):
    keys = list(d.keys())[:3]
    print("keys:", keys)
    for k in keys[:1]:
        v = d[k]
        print(f"  {k}: type={type(v).__name__}", end="")
        if isinstance(v, dict):
            print(" subkeys:", list(v.keys())[:10])
        elif isinstance(v, list):
            print(" len:", len(v), " first:", str(v[0])[:300] if v else "")
        else:
            print(" value:", str(v)[:300])
elif isinstance(d, list):
    print("first item:", str(d[0])[:500])
EOF
  echo
done
