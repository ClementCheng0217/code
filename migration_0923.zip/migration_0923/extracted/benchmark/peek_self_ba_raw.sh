#!/bin/bash
# 检查 raw_results.json 完整字段 + errors.json
PY=/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python
BASE=/ssd/lamdatfm/chengzj/benchmark/benchmark_results
$PY - <<'EOF'
import json
base = "/ssd/lamdatfm/chengzj/benchmark/benchmark_results"
models = [
    "beyondarena_reg_s1_260808_float32",
    "beyondarena_reg_s1_260813_muon",
    "beyondarena_reg_s2_260815_float32",
    "beyondarena_reg_s3_260820_float32",
    "beyondarena_260814_s3amp",
]
for m in models:
    import glob
    raws = glob.glob(f"{base}/{m}/beyondarena/*/raw_results.json")
    if not raws:
        print(f"== {m}: NO raw_results.json")
        continue
    raw = raws[0]
    d = json.load(open(raw))
    print(f"== {m}: {len(d)} items, first item keys: {list(d[0].keys())}")
    tm = d[0].get("task_metadata", {})
    print(f"   task_metadata keys: {list(tm.keys())}")
    print(f"   sample: name={tm.get('name')} fold={tm.get('fold')} tid={tm.get('tid')} metric_error={d[0].get('metric_error')}")
    # 检查缺失 job
    errs = glob.glob(f"{base}/{m}/beyondarena/*/errors.json")
    for e in errs:
        ej = json.load(open(e))
        print(f"   errors.json: {str(ej)[:300]}")
    # 统计每个数据集的 fold 数
    from collections import Counter
    c = Counter(x["task_metadata"]["name"] for x in d)
    print(f"   datasets: {len(c)}, total folds: {sum(c.values())}")
    print(f"   min/max folds: {min(c.values())}/{max(c.values())}")
    print()
EOF
