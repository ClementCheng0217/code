#!/bin/bash
# 列出 7 个 self 模型在 BeyondArena 上的 per_dataset_results.csv 位置
BASE=/ssd/lamdatfm/chengzj/benchmark/benchmark_results
for d in \
  beyondarena_reg_s1_260808_float32 \
  beyondarena_reg_s1_260813_muon \
  beyondarena_reg_s2_260815_float32 \
  beyondarena_reg_s3_260820_float32 \
  beyondarena_cls_s1_260817 \
  beyondarena_cls_s3_260819 \
  beyondarena_260814_s3amp \
  beyondarena_260811_s3amp ; do
  echo "=== $d ==="
  ls -la $BASE/$d/beyondarena/*/per_dataset_results.csv 2>/dev/null
  ls -la $BASE/$d/beyondarena/*/summary.json 2>/dev/null | head -2
done
echo "=== self-s3-260814 在 beyondarena 的可能目录(260814 当日) ==="
find $BASE/beyondarena_260814* -maxdepth 3 -type d 2>/dev/null | head -10
