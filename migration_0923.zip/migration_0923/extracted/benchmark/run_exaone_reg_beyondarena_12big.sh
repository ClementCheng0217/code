#!/bin/bash
# EXAONE-Tabular regressor v1: 补跑被规模过滤的 12 个 BeyondArena 回归数据集
# 不传 ba_max_train_rows/ba_max_cols —— 模型内部处理超限输入:
#   行 > 100000 -> 随机采样到 100000 (exaonetabular regressor._prepare_support)
#   列 > 100    -> SelectKBest 选 top-100 (preprocessing._prepare)
# 12 个数据集: allstate_claims_severity, california_house_prices_2020,
#   climate_model_weather_forecasting_1m, cooking_time_1m, delivery_eta_1m,
#   early_learning_predictors, electric_motor_temperature_prediction,
#   maps_router_eta_1m, mercari_price_suggestion_1m, qsar_tid_11,
#   rossmann_store_sales, santander_transaction_value
export TMPDIR=/ssd/lamdatfm/chengzj/tmp
mkdir -p $TMPDIR
cd /ssd/lamdatfm/chengzj/benchmark
PY=/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python
LOG=/tmp/exaone_reg_beyondarena_12big.log
rm -f $LOG
setsid nohup env PYTHONPATH=/ssd/lamdatfm/chengzj/pylib \
  CUDA_VISIBLE_DEVICES=0,1,2,3 $PY -u run_all_benchmarks.py \
  --direct_ckpt /ssd/lamdatfm/chengzj/models/exaone-tabular-regressor-v1_default.safetensors \
  --direct_adapter exaone_tabular --model_name exaone-tabular-v1 \
  --benchmarks beyondarena --reg_only --num_gpus 4 --time_limit 21600 \
  --datasets "allstate_claims_severity,california_house_prices_2020,climate_model_weather_forecasting_1m,cooking_time_1m,delivery_eta_1m,early_learning_predictors,electric_motor_temperature_prediction,maps_router_eta_1m,mercari_price_suggestion_1m,qsar_tid_11,rossmann_store_sales,santander_transaction_value" \
  --output_dir benchmark_results/exaone_reg_v1_beyondarena_12big > $LOG 2>&1 &
echo "STARTED PID $!  LOG=$LOG"
sleep 30
echo "===== 日志开头 ====="
head -60 $LOG
