"""Runtime compatibility helpers shared by EXAONE benchmark adapters.

EXAONE-Tabular already chunks large FLASH_ATTENTION batches, but the runtime
can select PyTorch's memory-efficient SDPA backend for short sequences.  That
backend has the same 65,535 flat-batch launch limit and otherwise raises
``CUDA error: invalid configuration argument`` on large TALENT tables.
"""

from __future__ import annotations

import importlib
import sys
from pathlib import Path
from typing import Any


EXAONE_SDPA_BATCH_LIMIT = 65_535
_PATCH_MARKER = "_exaone_sdpa_batch_chunking"


def activate_exaone_source(source_path: str | Path | None) -> Path | None:
    """Import EXAONE from an explicitly requested checkout.

    ``source_path`` may point either at the repository root or its ``src``
    directory.  Refuse to continue if this process has already imported a
    different EXAONE installation: silently mixing code and weights would make
    benchmark caches impossible to audit.
    """
    if source_path is None:
        return None

    requested = Path(source_path).expanduser().resolve()
    candidates = (requested, requested / "src")
    source_root = next(
        (
            candidate
            for candidate in candidates
            if (candidate / "exaonetabular" / "__init__.py").is_file()
        ),
        None,
    )
    if source_root is None:
        raise FileNotFoundError(
            "EXAONE source path must be a checkout root or src directory "
            f"containing exaonetabular/__init__.py: {requested}"
        )

    existing = sys.modules.get("exaonetabular")
    if existing is not None:
        existing_file = Path(existing.__file__).resolve()
        if not existing_file.is_relative_to(source_root):
            raise RuntimeError(
                "exaonetabular was already imported from a different source: "
                f"{existing_file}; requested {source_root}"
            )

    source_string = str(source_root)
    sys.path[:] = [entry for entry in sys.path if entry != source_string]
    sys.path.insert(0, source_string)
    importlib.invalidate_caches()
    module = importlib.import_module("exaonetabular")
    loaded_file = Path(module.__file__).resolve()
    if not loaded_file.is_relative_to(source_root):
        raise RuntimeError(
            f"failed to activate requested EXAONE source {source_root}; "
            f"loaded {loaded_file}"
        )
    print(f"[EXAONE] runtime source: {loaded_file}", flush=True)
    return loaded_file


def _needs_sdpa_batch_chunking(
    query: Any,
    key: Any,
    value: Any,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> bool:
    """Return whether this EXAONE-style unmasked SDPA call needs chunking."""
    if not getattr(query, "is_cuda", False):
        return False
    if query.dim() != 4 or key.dim() != 4 or value.dim() != 4:
        return False
    flat_batch = query.shape[0]
    if flat_batch <= EXAONE_SDPA_BATCH_LIMIT:
        return False
    if key.shape[0] != flat_batch or value.shape[0] != flat_batch:
        return False

    # EXAONE's affected path is unmasked.  Staying narrow here avoids changing
    # the broadcasting semantics of unrelated masked SDPA calls in a process
    # that later evaluates another model.
    positional_mask = args[0] if args else None
    return positional_mask is None and kwargs.get("attn_mask") is None


def patch_exaone_sdpa() -> bool:
    """Install an idempotent flat-batch chunker around PyTorch SDPA.

    Returns ``True`` only when this call installed the wrapper.  Splitting the
    flat batch is numerically equivalent because those batch elements do not
    attend to one another.
    """
    import torch
    import torch.nn.functional as functional

    current = functional.scaled_dot_product_attention
    if getattr(current, _PATCH_MARKER, False):
        return False

    original = current

    def chunked(query, key, value, *args, **kwargs):
        if not _needs_sdpa_batch_chunking(
            query,
            key,
            value,
            args,
            kwargs,
        ):
            return original(query, key, value, *args, **kwargs)

        parts = [
            original(
                query[start : start + EXAONE_SDPA_BATCH_LIMIT],
                key[start : start + EXAONE_SDPA_BATCH_LIMIT],
                value[start : start + EXAONE_SDPA_BATCH_LIMIT],
                *args,
                **kwargs,
            )
            for start in range(
                0,
                query.shape[0],
                EXAONE_SDPA_BATCH_LIMIT,
            )
        ]
        return torch.cat(parts, dim=0)

    setattr(chunked, _PATCH_MARKER, True)
    setattr(chunked, "_exaone_original_sdpa", original)
    functional.scaled_dot_product_attention = chunked
    print(
        "[EXAONE] installed SDPA flat-batch chunking "
        f"(limit={EXAONE_SDPA_BATCH_LIMIT})",
        flush=True,
    )
    return True


__all__ = [
    "EXAONE_SDPA_BATCH_LIMIT",
    "activate_exaone_source",
    "patch_exaone_sdpa",
]
