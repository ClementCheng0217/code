#!/bin/bash
# 诊断 exaone-tabular-regressor 权重无法加载的原因
echo "===== 1. models 目录下 exaone 相关文件 ====="
ls -la /ssd/lamdatfm/chengzj/models/ | grep -i exaone
ls -la /ssd/lamdatfm/chengzj/models/exaone-tabular/ 2>/dev/null

echo ""
echo "===== 2. exaonetabular 包位置与版本 ====="
/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python - <<'EOF'
import exaonetabular, os
print("pkg:", os.path.dirname(exaonetabular.__file__))
print("version:", getattr(exaonetabular, "__version__", "no-version"))
print("presets:", os.path.dirname(exaonetabular.__file__))
EOF

echo ""
echo "===== 3. regressor 权重 keys ====="
/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python - <<'EOF'
import safetensors.torch as st
p = "/ssd/lamdatfm/chengzj/models/exaone-tabular-regressor-v1_default.safetensors"
sd = st.load_file(p)
print("total keys:", len(sd))
for k in list(sd.keys())[:30]:
    print(" ", k, tuple(sd[k].shape))
EOF

echo ""
echo "===== 4. classifier 权重 keys(对比) ====="
/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python - <<'EOF'
import safetensors.torch as st
p = "/ssd/lamdatfm/chengzj/models/exaone-tabular/exaone-tabular-classifier-v1_default.safetensors"
sd = st.load_file(p)
print("total keys:", len(sd))
for k in list(sd.keys())[:30]:
    print(" ", k, tuple(sd[k].shape))
EOF

echo ""
echo "===== 5. 模型期望的 keys(加载 RegressionModel 后对比) ====="
/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python - <<'EOF'
import torch, safetensors.torch as st
from exaonetabular.presets import released_checkpoint
from exaonetabular.model.heads import RegressionModel

ckpt = released_checkpoint("regression")
print("manifest:", ckpt.manifest)
m = RegressionModel(ckpt.manifest.model, ckpt.manifest.regression, device="cpu", dtype=torch.float32)
expect = {k: tuple(v.shape) for k, v in m.state_dict().items()}
print("model total keys:", len(expect))
for k, s in list(expect.items())[:30]:
    print(" ", k, s)

sd = st.load_file("/ssd/lamdatfm/chengzj/models/exaone-tabular-regressor-v1_default.safetensors")
sd_k = {k: tuple(v.shape) for k, v in sd.items()}
only_model = set(expect) - set(sd_k)
only_ckpt = set(sd_k) - set(expect)
shape_mismatch = [k for k in set(expect) & set(sd_k) if expect[k] != sd_k[k]]
print()
print("only in model:", len(only_model), list(only_model)[:20])
print("only in ckpt :", len(only_ckpt), list(only_ckpt)[:20])
print("shape mismatch:", len(shape_mismatch), shape_mismatch[:10])
EOF
