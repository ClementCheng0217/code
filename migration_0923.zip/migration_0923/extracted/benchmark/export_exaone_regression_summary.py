#!/usr/bin/env python3
"""Export audited EXAONE TALENT regression performance artifacts."""

from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


MODEL = "exaone-tabular-v1"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--result-root", type=Path, required=True)
    return parser.parse_args()


def atomic_csv(frame: pd.DataFrame, path: Path) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(
        temporary,
        index=False,
        encoding="utf-8-sig",
        float_format="%.12g",
    )
    os.replace(temporary, path)


def atomic_json(payload: dict[str, Any], path: Path) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def main() -> None:
    root = args.result_root.expanduser().resolve()
    metadata = pd.read_csv(
        root / "model_by_dataset_acc_results_with_avgrank_metadata.csv",
        encoding="utf-8-sig",
    )
    datasets = metadata.loc[
        metadata["task_type"].eq("regression"), "dataset"
    ].tolist()
    if len(datasets) != 100:
        raise RuntimeError(f"expected 100 regression datasets, found {len(datasets)}")
    matrix = pd.read_csv(
        root / "model_by_dataset_acc_results_with_avgrank_and_reg_elo.csv",
        encoding="utf-8-sig",
    )
    elo_ranking = pd.read_csv(
        root / "regression_rmse_elo_ranking.csv", encoding="utf-8-sig"
    )
    models = elo_ranking["model"].tolist()
    fixed = (
        matrix.loc[matrix["model"].isin(models)]
        .set_index("model")
        .loc[models]
        .reset_index()
    )
    fixed["rmse_macro_mean"] = fixed[datasets].mean(axis=1)
    fixed["reg_avg_rank_position"] = fixed["reg_avg_rank"].rank(
        method="min", ascending=True
    ).astype(int)
    fixed["elo_rank"] = fixed["model"].map(
        elo_ranking.set_index("model")["elo_rank"]
    )
    matrix_columns = [
        "model",
        *datasets,
        "rmse_macro_mean",
        "reg_avg_rank",
        "reg_avg_rank_position",
        "reg_rmse_elo",
        "elo_rank",
    ]
    fixed = fixed.sort_values(["reg_avg_rank", "model"], kind="stable")
    atomic_csv(
        fixed[matrix_columns],
        root / "fixed_reproduced_models_regression_rmse_with_avgrank_elo.csv",
    )
    ranking_columns = [
        "model",
        "rmse_macro_mean",
        "reg_avg_rank",
        "reg_avg_rank_position",
        "reg_rmse_elo",
        "elo_rank",
    ]
    atomic_csv(
        fixed[ranking_columns],
        root / "fixed_reproduced_models_regression_ranking.csv",
    )

    by_model = fixed.set_index("model")
    exaone = by_model.loc[MODEL]
    head_to_head: list[dict[str, Any]] = []
    for opponent, row in by_model.iterrows():
        if opponent == MODEL:
            continue
        exaone_values = pd.to_numeric(exaone[datasets], errors="coerce")
        opponent_values = pd.to_numeric(row[datasets], errors="coerce")
        valid = exaone_values.notna() & opponent_values.notna()
        wins = int((exaone_values[valid] < opponent_values[valid]).sum())
        ties = int((exaone_values[valid] == opponent_values[valid]).sum())
        losses = int((exaone_values[valid] > opponent_values[valid]).sum())
        head_to_head.append(
            {
                "opponent": opponent,
                "common_datasets": int(valid.sum()),
                "exaone_wins": wins,
                "ties": ties,
                "exaone_losses": losses,
                "exaone_win_rate_excluding_ties": (
                    wins / (wins + losses) if wins + losses else math.nan
                ),
            }
        )
    atomic_csv(
        pd.DataFrame(head_to_head).sort_values(
            ["exaone_wins", "opponent"], ascending=[False, True]
        ),
        root / "exaone_head_to_head_rmse.csv",
    )

    performance: list[dict[str, Any]] = []
    records_by_task: dict[str, list[dict[str, Any]]] = {}
    for task_type, suffix, primary_metric in (
        ("classification", "cla", "Accuracy"),
        ("regression", "reg", "RMSE"),
    ):
        raw_path = root / f"talent/{MODEL}_{suffix}/raw_results.json"
        records = json.loads(raw_path.read_text(encoding="utf-8"))
        records_by_task[task_type] = records
        metric_names = sorted(
            {metric for record in records for metric in record["metrics"]}
        )
        row = {
            "model": MODEL,
            "task_type": task_type,
            "checkpoint": records[0]["checkpoint"],
            "source_path": records[0].get("source_path"),
            "n_estimators": records[0].get("n_estimators"),
            "num_datasets": len(records),
            "primary_metric": primary_metric,
            "primary_mean": float(
                np.mean(
                    [record["metrics"][primary_metric] for record in records]
                )
            ),
            "fit_time_seconds_sum": float(
                sum(record["fit_time"] for record in records)
            ),
            "predict_time_seconds_sum": float(
                sum(record["predict_time"] for record in records)
            ),
        }
        for metric in metric_names:
            row[f"{metric}_mean"] = float(
                np.mean([record["metrics"][metric] for record in records])
            )
        if task_type == "regression":
            row.update(
                {
                    "fixed_pool_avg_rank": float(exaone["reg_avg_rank"]),
                    "fixed_pool_avg_rank_position": int(
                        exaone["reg_avg_rank_position"]
                    ),
                    "fixed_pool_elo": float(exaone["reg_rmse_elo"]),
                    "fixed_pool_elo_rank": int(exaone["elo_rank"]),
                    "fixed_pool_size": len(fixed),
                }
            )
        performance.append(row)
    atomic_csv(pd.DataFrame(performance), root / "model_performance.csv")

    regression_records = records_by_task["regression"]
    validation = {
        "status": "complete",
        "task_type": "regression",
        "expected_datasets": 100,
        "successful_datasets": len(regression_records),
        "failed_datasets": 0,
        "unique_datasets": len(
            {record["dataset"] for record in regression_records}
        ),
        "all_metrics_finite": all(
            all(math.isfinite(float(value)) for value in record["metrics"].values())
            for record in regression_records
        ),
        "checkpoint": regression_records[0]["checkpoint"],
        "source_path": regression_records[0]["source_path"],
        "runtime_module_file": regression_records[0]["runtime_module_file"],
        "n_estimators": regression_records[0]["n_estimators"],
        "max_vram_bytes": regression_records[0]["max_vram_bytes"],
        "rmse_macro_mean": float(
            np.mean([record["metrics"]["RMSE"] for record in regression_records])
        ),
        "mae_macro_mean": float(
            np.mean([record["metrics"]["MAE"] for record in regression_records])
        ),
        "r2_macro_mean": float(
            np.mean([record["metrics"]["R2"] for record in regression_records])
        ),
        "r2_median": float(
            np.median([record["metrics"]["R2"] for record in regression_records])
        ),
        "fixed_model_pool_size": len(fixed),
        "fixed_pool_rmse_avg_rank": float(exaone["reg_avg_rank"]),
        "fixed_pool_rmse_avg_rank_position": int(
            exaone["reg_avg_rank_position"]
        ),
        "fixed_pool_rmse_elo": float(exaone["reg_rmse_elo"]),
        "fixed_pool_rmse_elo_rank": int(exaone["elo_rank"]),
        "elo_datasets": int(elo_ranking["num_datasets"].iloc[0]),
    }
    atomic_json(validation, root / "validation.json")
    print(json.dumps(validation, ensure_ascii=False))


if __name__ == "__main__":
    args = parse_args()
    main()
