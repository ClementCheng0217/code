#!/bin/bash
# 查看 raw_results.json 的 metric / problem_type 字段值
PY=/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python
$PY - <<'EOF'
import json
p = "/ssd/lamdatfm/chengzj/benchmark/benchmark_results/beyondarena_reg_s1_260808_float32/beyondarena/self-reg-s1-260808-float32_reg/raw_results.json"
d = json.load(open(p))
print("item0 metric:", d[0].get("metric"))
print("item0 problem_type:", d[0].get("problem_type"))
print("item0 framework:", d[0].get("framework"))
print("item0 experiment_metadata:", str(d[0].get("experiment_metadata"))[:200])
# 数据集列表 + fold 数
from collections import Counter
c = Counter(x["task_metadata"]["name"] for x in d)
print("datasets:", len(c))
for k, v in sorted(c.items(), key=lambda kv: -kv[1]):
    print(f"  {v:3d}  {k}")
EOF
