#!/usr/bin/env python3
"""Local model discovery for the unified tabular benchmark runner.

The model directory is intentionally the source of truth.  Every supported
checkpoint is assigned to exactly one logical model, and paired classifier /
regressor checkpoints are exposed as one model when their variant names match.
"""

from __future__ import annotations

import filecmp
import re
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Iterable, Mapping, Sequence

TASK_TYPES = ("classification", "regression")
BENCHMARKS = ("tabarena", "beyondarena", "talent")
DEFAULT_MODELS_DIR = Path("/ssd/lamdatfm/chengzj/models")


@dataclass(frozen=True)
class ModelSpec:
    """One selectable local model and its benchmark adapters."""

    name: str
    family: str
    arena_adapter: str
    talent_method: str
    checkpoints: Mapping[str, Path]
    artifacts: tuple[Path, ...]
    benchmarks: tuple[str, ...] = BENCHMARKS

    @property
    def task_types(self) -> tuple[str, ...]:
        return tuple(task for task in TASK_TYPES if task in self.checkpoints)

    def checkpoint_for(self, task_type: str) -> Path | None:
        return self.checkpoints.get(task_type)

    def to_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "family": self.family,
            "arena_adapter": self.arena_adapter,
            "talent_method": self.talent_method,
            "benchmarks": list(self.benchmarks),
            "task_types": list(self.task_types),
            "checkpoints": {
                task: str(path)
                for task, path in self.checkpoints.items()
            },
            "artifacts": [str(path) for path in self.artifacts],
        }


def _freeze_checkpoints(values: Mapping[str, Path]) -> Mapping[str, Path]:
    return MappingProxyType(dict(values))


def _slug(value: str) -> str:
    value = value.replace("_", "-").lower()
    value = re.sub(r"[^a-z0-9.-]+", "-", value)
    value = re.sub(r"-+", "-", value)
    return value.strip("-.")


def _make_spec(
    *,
    name: str,
    family: str,
    arena_adapter: str,
    talent_method: str,
    checkpoints: Mapping[str, Path],
    artifacts: Iterable[Path] | None = None,
    benchmarks: Sequence[str] = BENCHMARKS,
) -> ModelSpec:
    checkpoint_map = {task: path.resolve() for task, path in checkpoints.items()}
    artifact_paths = tuple(
        sorted(
            (path.resolve() for path in (artifacts or checkpoint_map.values())),
            key=str,
        )
    )
    return ModelSpec(
        name=name,
        family=family,
        arena_adapter=arena_adapter,
        talent_method=talent_method,
        checkpoints=_freeze_checkpoints(checkpoint_map),
        artifacts=artifact_paths,
        benchmarks=tuple(benchmarks),
    )


_TABPFN_PATTERN = re.compile(
    r"^tabpfn-(?P<version>v[0-9.]+)-"
    r"(?P<kind>classifier|regressor)"
    r"(?:-(?P<variant>.+))?\.(?:ckpt|cpkt)$"
)


def _discover_tabpfn(models_dir: Path) -> list[ModelSpec]:
    grouped: dict[tuple[str, str], dict[str, Path]] = {}
    grouped_artifacts: dict[tuple[str, str], list[Path]] = {}
    candidates = sorted(
        path
        for path in (models_dir / "tabpfn").rglob("*")
        if path.is_file() and path.suffix.lower() in {".ckpt", ".cpkt"}
    )
    for checkpoint in candidates:
        match = _TABPFN_PATTERN.match(checkpoint.name)
        if match is None:
            raise ValueError(f"无法识别 TabPFN checkpoint 名称: {checkpoint}")
        version = match.group("version")
        variant = match.group("variant") or "base"
        task = (
            "classification"
            if match.group("kind") == "classifier"
            else "regression"
        )
        key = (version, variant)
        grouped_artifacts.setdefault(key, []).append(checkpoint)
        existing = grouped.setdefault(key, {}).get(task)
        if existing is None:
            grouped[key][task] = checkpoint
        elif (
            existing.stem == checkpoint.stem
            and filecmp.cmp(existing, checkpoint, shallow=False)
        ):
            # One local v2 payload has both a canonical `.ckpt` filename and
            # an identical transposed-extension `.cpkt` alias. Track both
            # files for complete inventory coverage, but benchmark it once.
            if checkpoint.suffix.lower() == ".ckpt":
                grouped[key][task] = checkpoint
        else:
            raise ValueError(
                f"TabPFN {version}/{variant} 存在不同内容的重复 "
                f"{task} checkpoint: {existing}, {checkpoint}"
            )

    specs: list[ModelSpec] = []
    for (version, variant), checkpoints in sorted(grouped.items()):
        canonical_variant = f"{version}_default"
        if variant == canonical_variant:
            name = f"tabpfn-{version}"
        elif variant == "base":
            name = f"tabpfn-{version}-base"
        elif len(checkpoints) == 2:
            name = f"tabpfn-{version}-{_slug(variant)}"
        else:
            task_tag = "cls" if "classification" in checkpoints else "reg"
            name = f"tabpfn-{version}-{task_tag}-{_slug(variant)}"

        # The current official TabPFN package infers the architecture version
        # from a local checkpoint, so one wrapper safely covers v2--v3.  One
        # early v2 regression artifact predates the attention-key conversion
        # supported by tabpfn>=8 and must use TALENT's vendored v2 runtime.
        uses_legacy_v2_runtime = (
            version == "v2"
            and variant == "5wof9ojf"
            and set(checkpoints) == {"regression"}
        )
        specs.append(
            _make_spec(
                name=name,
                family="tabpfn",
                arena_adapter=(
                    "tabpfn_v2_legacy"
                    if uses_legacy_v2_runtime
                    else "tabpfn"
                ),
                talent_method=(
                    "tabpfn_v2"
                    if uses_legacy_v2_runtime
                    else "tabpfn_v3"
                ),
                checkpoints=checkpoints,
                artifacts=grouped_artifacts[(version, variant)],
            )
        )
    return specs


_TABICL_PATTERN = re.compile(
    r"^tabicl-(?P<kind>classifier|regressor)-"
    r"(?P<version>v[0-9.]+)-.+\.ckpt$"
)


def _discover_tabicl(models_dir: Path) -> list[ModelSpec]:
    grouped: dict[str, dict[str, Path]] = {}
    for checkpoint in sorted((models_dir / "tabicl").glob("*.ckpt")):
        match = _TABICL_PATTERN.match(checkpoint.name)
        if match is None:
            raise ValueError(f"无法识别 TabICL checkpoint 名称: {checkpoint}")
        version = match.group("version")
        task = (
            "classification"
            if match.group("kind") == "classifier"
            else "regression"
        )
        if task in grouped.setdefault(version, {}):
            raise ValueError(f"TabICL {version} 存在重复 {task} checkpoint")
        grouped[version][task] = checkpoint

    specs: list[ModelSpec] = []
    for version, checkpoints in sorted(grouped.items()):
        checkpoints = dict(checkpoints)
        if (
            "classification" in checkpoints
            and "regression" in checkpoints
            and checkpoints["classification"].resolve()
            == checkpoints["regression"].resolve()
        ):
            # A local self-trained TabICL checkpoint was exposed through both
            # classifier/regressor symlink names.  Its checkpoint config is
            # classification-only (`max_classes`), and every TALENT regression
            # dataset fails when loaded through TabICLRegressor.  Do not claim
            # regression support merely because the second symlink exists.
            checkpoints.pop("regression")
        specs.append(
            _make_spec(
                name=f"tabicl-{version}",
                family="tabicl",
                arena_adapter=(
                    "tabicl_v2"
                    if version.startswith("v2")
                    else "tabicl_v1"
                ),
                talent_method=(
                    "tabicl_v2"
                    if version.startswith("v2")
                    else "tabicl"
                ),
                checkpoints=checkpoints,
            )
        )
    return specs


def _discover_limix(models_dir: Path) -> list[ModelSpec]:
    specs: list[ModelSpec] = []
    for checkpoint in sorted((models_dir / "limix").glob("*/*.ckpt")):
        specs.append(
            _make_spec(
                name=_slug(checkpoint.stem),
                family="limix",
                arena_adapter="limix",
                talent_method="limix",
                checkpoints={
                    "classification": checkpoint,
                    "regression": checkpoint,
                },
                artifacts=(checkpoint,),
            )
        )
    return specs


def _discover_tabfm(models_dir: Path) -> list[ModelSpec]:
    root = models_dir / "tabfm"
    classification = root / "classification" / "model.safetensors"
    regression = root / "regression" / "model.safetensors"
    checkpoints: dict[str, Path] = {}
    artifacts: list[Path] = []
    if classification.is_file():
        checkpoints["classification"] = root
        artifacts.append(classification)
    if regression.is_file():
        checkpoints["regression"] = root
        artifacts.append(regression)
    if not checkpoints:
        return []
    return [
        _make_spec(
            name="tabfm",
            family="tabfm",
            arena_adapter="tabfm",
            talent_method="tabfm",
            checkpoints=checkpoints,
            artifacts=artifacts,
        )
    ]


def _discover_exaone_tabular(models_dir: Path) -> list[ModelSpec]:
    """Discover the official EXAONE-Tabular v1 checkpoint files.

    Prefer top-level files because the official code and weights may be kept
    outside a shared ``exaone-tabular`` directory that is not readable by the
    benchmark user.  Retain the legacy subdirectory as a fallback.
    """
    legacy_root = models_dir / "exaone-tabular"
    filenames = {
        "classification": "exaone-tabular-classifier-v1_default.safetensors",
        "regression": "exaone-tabular-regressor-v1_default.safetensors",
    }
    checkpoints: dict[str, Path] = {}
    artifacts: list[Path] = []
    for task, filename in filenames.items():
        for checkpoint in (models_dir / filename, legacy_root / filename):
            if checkpoint.is_file():
                artifacts.append(checkpoint)
                checkpoints.setdefault(task, checkpoint)
    if not checkpoints:
        return []
    return [
        _make_spec(
            name="exaone-tabular-v1",
            family="exaone-tabular",
            arena_adapter="exaone_tabular",
            talent_method="exaone_tabular",
            checkpoints=checkpoints,
            artifacts=artifacts,
        )
    ]


def _discover_tabswift(models_dir: Path) -> list[ModelSpec]:
    """Discover the shared official TabSwift classification/regression weight."""
    checkpoint = models_dir / "tabswift" / "swift.ckpt"
    if not checkpoint.is_file():
        return []
    return [
        _make_spec(
            name="tabswift",
            family="tabswift",
            arena_adapter="tabswift",
            talent_method="tabswift",
            checkpoints={
                "classification": checkpoint,
                "regression": checkpoint,
            },
            artifacts=(checkpoint,),
            benchmarks=("talent",),
        )
    ]

def _discover_mitra(models_dir: Path) -> list[ModelSpec]:
    # Discover the local Mitra v2 fine-tune checkpoints (classifier/regressor).
    root = models_dir / "mitra-tabular"
    cls_dir = root / "models" / "mitra-classifier-2"
    reg_dir = root / "models" / "mitra-regressor-2"
    checkpoints: dict[str, Path] = {}
    artifacts: list[Path] = []
    if (cls_dir / "model.safetensors").is_file():
        checkpoints["classification"] = cls_dir
        artifacts.append(cls_dir / "model.safetensors")
    if (reg_dir / "model.safetensors").is_file():
        checkpoints["regression"] = reg_dir
        artifacts.append(reg_dir / "model.safetensors")
    if not checkpoints:
        return []
    return [
        _make_spec(
            name="mitra-tabular",
            family="mitra",
            arena_adapter="mitra",
            talent_method="mitra",
            checkpoints=checkpoints,
            artifacts=artifacts,
            benchmarks=("tabarena", "beyondarena"),
        )
    ]


def _discover_tabldm(models_dir: Path) -> list[ModelSpec]:
    # Discover the local Xiaomi-TabLDM inference checkpoints.
    root = models_dir / "xiaomi-tabldm"
    checkpoints: dict[str, Path] = {}
    artifacts: list[Path] = []
    for task, name in (
        ("classification", "clf_default.ckpt"),
        ("regression", "reg_default.ckpt"),
    ):
        ckpt = root / name
        if ckpt.is_file():
            checkpoints[task] = ckpt
            artifacts.append(ckpt)
    if not checkpoints:
        return []
    return [
        _make_spec(
            name="xiaomi-tabldm",
            family="tabldm",
            arena_adapter="tabldm",
            talent_method="tabldm",
            checkpoints=checkpoints,
            artifacts=artifacts,
            benchmarks=("tabarena", "beyondarena"),
        )
    ]



def discover_models(
    models_dir: str | Path = DEFAULT_MODELS_DIR,
) -> dict[str, ModelSpec]:
    """Discover and validate all supported local model artifacts."""
    root = Path(models_dir).expanduser().resolve()
    specs = [
        *_discover_tabswift(root),
        *_discover_exaone_tabular(root),
        *_discover_limix(root),
        *_discover_tabfm(root),
        *_discover_tabicl(root),
        *_discover_tabpfn(root),
        *_discover_mitra(root),
        *_discover_tabldm(root),
    ]
    registry: dict[str, ModelSpec] = {}
    for spec in specs:
        if spec.name in registry:
            raise ValueError(f"重复模型名: {spec.name}")
        registry[spec.name] = spec

    discovered_artifacts = {
        path.resolve()
        for pattern in (
            "limix/**/*.ckpt",
            "tabicl/**/*.ckpt",
            "tabpfn/**/*.ckpt",
            "tabpfn/**/*.cpkt",
            "tabfm/**/model.safetensors",
            "exaone-tabular-*.safetensors",
            "exaone-tabular/*.safetensors",
            "tabswift/swift.ckpt",
            "mitra-tabular/models/*/model.safetensors",
            "xiaomi-tabldm/*.ckpt",
        )
        for path in root.glob(pattern)
    }
    registered_artifacts = {
        artifact
        for spec in registry.values()
        for artifact in spec.artifacts
    }
    missing = sorted(discovered_artifacts - registered_artifacts, key=str)
    stale = sorted(registered_artifacts - discovered_artifacts, key=str)
    if missing or stale:
        raise RuntimeError(
            "本地模型注册不完整。"
            f" 未注册={list(map(str, missing))};"
            f" 不存在={list(map(str, stale))}"
        )
    return dict(sorted(registry.items()))


def select_models(
    selection: str | Sequence[str] | None,
    registry: Mapping[str, ModelSpec],
    *,
    skipped_families: Iterable[str] = (),
) -> list[ModelSpec]:
    """Resolve ``all``, exact model names, or family selectors."""
    if selection is None or (
        isinstance(selection, str)
        and selection.strip().lower() == "all"
    ):
        requested = ["all"]
    elif isinstance(selection, str):
        requested = [
            part.strip()
            for part in selection.split(",")
            if part.strip()
        ]
    else:
        requested = [str(part).strip() for part in selection if str(part).strip()]
    if not requested:
        raise ValueError("--models 不能为空")

    skipped = set(skipped_families)
    families = {spec.family for spec in registry.values()}
    selected_names: list[str] = []
    unknown: list[str] = []
    for value in requested:
        if value == "all":
            selected_names.extend(registry)
        elif value in registry:
            selected_names.append(value)
        elif value.startswith("family:") and value[7:] in families:
            selected_names.extend(
                name
                for name, spec in registry.items()
                if spec.family == value[7:]
            )
        elif value in families:
            selected_names.extend(
                name
                for name, spec in registry.items()
                if spec.family == value
            )
        else:
            unknown.append(value)
    if unknown:
        raise ValueError(
            f"未知模型选择: {unknown}。可用模型: {list(registry)}；"
            f"可用模型族: {sorted(families)}"
        )

    deduplicated = list(dict.fromkeys(selected_names))
    return [
        registry[name]
        for name in deduplicated
        if registry[name].family not in skipped
    ]


def registry_inventory(
    registry: Mapping[str, ModelSpec],
) -> dict[str, object]:
    artifacts = {
        artifact
        for spec in registry.values()
        for artifact in spec.artifacts
    }
    return {
        "num_models": len(registry),
        "num_artifacts": len(artifacts),
        "families": {
            family: sum(spec.family == family for spec in registry.values())
            for family in sorted({spec.family for spec in registry.values()})
        },
        "models": [spec.to_dict() for spec in registry.values()],
    }
