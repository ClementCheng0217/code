#!/bin/bash
# 重新复制 exaonetabular 包并用 Python 精确 patch(一次到位)
set -e
SRC=/ssd/lamdatfm/chengzj/miniconda3/envs/arena/lib/python3.12/site-packages/exaonetabular
DST=/ssd/lamdatfm/chengzj/pylib/exaonetabular

# 旧副本移到备份(避免 rm -rf)
if [ -d "$DST" ]; then
  mv "$DST" "${DST}.broken.$(date +%s)"
  echo "moved broken copy aside"
fi
mkdir -p /ssd/lamdatfm/chengzj/pylib
cp -r "$SRC" "$DST"
echo "fresh copy -> $DST"

/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python - "$DST/checkpoint.py" <<'PYEOF'
import sys
p = sys.argv[1]
src = open(p, encoding="utf-8").read()

# ---- 修改 1: key 集合校验(仅要求模型所需 key 齐全) ----
old_check = """    if set(checkpoint) != set(targets):
        raise ValueError("checkpoint state keys do not match the model")"""
new_check = """    missing = set(targets) - set(checkpoint)
    if missing:
        raise ValueError("checkpoint state keys do not match the model")
    # 官方回归权重含 72 个 head_scale 参数(值全部等于 fixed_head_scale=0.43),
    # 本模型以常量使用该值、不保存参数: 忽略 checkpoint 中多余的 key。
    extra = sorted(set(checkpoint) - set(targets))
    if extra:
        _logger.warning("ignoring %d extra checkpoint keys: %s", len(extra), extra[:3])"""
assert src.count(old_check) == 2, f"check pattern x2 expected, got {src.count(old_check)}"
src = src.replace(old_check, new_check)

# ---- 修改 2: 校验循环遍历 targets(regressor 版, 4 空格缩进) ----
old_loop = """    for key, value in checkpoint.items():
        target = targets[key]
        if value.layout is not torch.strided or value.dtype not in _CHECKPOINT_DTYPES:
            raise ValueError("checkpoint tensor has an unsupported domain")
        if value.shape != target.shape:
            raise ValueError("checkpoint tensor metadata does not match the model")
        if not bool(torch.isfinite(value).all()):
            raise ValueError("checkpoint tensor contains a nonfinite value")"""
new_loop = """    for key in targets:
        value = checkpoint[key]
        if value.layout is not torch.strided or value.dtype not in _CHECKPOINT_DTYPES:
            raise ValueError("checkpoint tensor has an unsupported domain")
        if value.shape != targets[key].shape:
            raise ValueError("checkpoint tensor metadata does not match the model")
        if not bool(torch.isfinite(value).all()):
            raise ValueError("checkpoint tensor contains a nonfinite value")"""
assert src.count(old_loop) == 1, f"loop pattern x1 expected, got {src.count(old_loop)}"
src = src.replace(old_loop, new_loop)

# ---- 修改 3: 复制循环只复制模型所需 key(regressor 版, 4 空格缩进) ----
old_copy = """    backups = {key: value.detach().clone() for key, value in targets.items()}
    try:
        with torch.no_grad():
            for key, value in checkpoint.items():
                targets[key].copy_(value)"""
new_copy = """    backups = {key: value.detach().clone() for key, value in targets.items()}
    try:
        with torch.no_grad():
            for key in targets:
                targets[key].copy_(checkpoint[key])"""
assert src.count(old_copy) == 2, f"copy pattern x2 expected, got {src.count(old_copy)}"
src = src.replace(old_copy, new_copy)

open(p, "w", encoding="utf-8").write(src)
print("FULL PATCH OK")
PYEOF

echo "===== 验证: 加载 + 预测 ====="
cd /ssd/lamdatfm/chengzj/benchmark
PYTHONPATH=/ssd/lamdatfm/chengzj/pylib /ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python - <<'EOF'
import exaonetabular, os
print("loaded from:", os.path.dirname(exaonetabular.__file__))

import numpy as np
from exaonetabular import EXAONETabularRegressor

CKPT = "/ssd/lamdatfm/chengzj/models/exaone-tabular-regressor-v1_default.safetensors"
m = EXAONETabularRegressor.from_pretrained(weights=CKPT, device="cpu", seed=0)
print("LOAD OK, is_fitted =", m.is_fitted)

rng = np.random.default_rng(0)
Xtr = rng.normal(size=(200, 5)).astype(np.float32)
ytr = (Xtr[:, 0] * 2 + Xtr[:, 1] - Xtr[:, 2]).astype(np.float32)
Xte = rng.normal(size=(10, 5)).astype(np.float32)
m.fit(Xtr, ytr)
p = m.predict(Xte)
print("predict OK, shape:", p.shape, "sample:", np.round(p[:5], 4))
assert np.isfinite(p).all()
print("ALL GOOD")
EOF
