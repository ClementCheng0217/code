#!/bin/bash
# EXAONE-Tabular regressor v1: 重跑 12big 中失败的 3 个数据集
#   allstate_claims_severity    (OOM: 10万行推理需 >70GB, 之前与其他进程抢卡)
#   cooking_time_1m             (超时 21600s: 1M 行预处理 + 10万行推理 >6h)
#   maps_router_eta_1m          (超时 27700s: 997 列 + 1M 行)
# 策略: GPU 0-2 独占(当前全部空闲), time_limit 放宽到 12h,
#       输出到同一结果目录, 由评测框架 resume 合并(跳过已成功 job)
export TMPDIR=/ssd/lamdatfm/chengzj/tmp
mkdir -p $TMPDIR
cd /ssd/lamdatfm/chengzj/benchmark
PY=/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python
LOG=/tmp/exaone_reg_beyondarena_12big_rerun.log
rm -f $LOG
setsid nohup env PYTHONPATH=/ssd/lamdatfm/chengzj/pylib \
  CUDA_VISIBLE_DEVICES=0,1,2 $PY -u run_all_benchmarks.py \
  --direct_ckpt /ssd/lamdatfm/chengzj/models/exaone-tabular-regressor-v1_default.safetensors \
  --direct_adapter exaone_tabular --model_name exaone-tabular-v1 \
  --benchmarks beyondarena --reg_only --num_gpus 3 --time_limit 43200 \
  --datasets "allstate_claims_severity,cooking_time_1m,maps_router_eta_1m" \
  --output_dir benchmark_results/exaone_reg_v1_beyondarena_12big > $LOG 2>&1 &
echo "STARTED PID $!  LOG=$LOG"
sleep 30
echo "===== 日志开头 ====="
head -60 $LOG
