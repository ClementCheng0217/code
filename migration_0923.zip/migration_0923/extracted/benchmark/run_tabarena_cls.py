#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TabArena / BeyondArena 分类任务 GPU 分布式评测脚本。

功能：
  - 使用本地预下载的数据集（通过 --data_dir 指定 OpenML 缓存目录），
    全程不连接 HuggingFace / 外网。
  - 传入模型 checkpoint，自动在分类数据集（binary + multiclass）上评测。
  - 支持多 GPU 分布式推理：N 张卡并行处理 splits，自动排队调度。
  - 输出两个结果文件：
      1. per_dataset_results.json  — 每个数据集的最终结果（mean ± std）
      2. per_split_results.json    — 每个 split 的明细结果

用法示例：
    # TabPFN 分类 checkpoint，16 卡，TabArena 分类子集
    python run_tabarena_cls.py \\
        --model tabpfn \\
        --checkpoint tabpfn-v3-classifier-v3_default.ckpt \\
        --data_dir /path/to/local/openml_cache \\
        --output_dir benchmark_results \\
        --num_gpus 16 \\
        --benchmark tabarena

    # TabICL 分类 checkpoint，8 卡，BeyondArena + TabArena
    python run_tabarena_cls.py \\
        --model tabicl \\
        --checkpoint tabicl-classifier-v2-20260212.ckpt \\
        --data_dir /path/to/local/openml_cache \\
        --output_dir benchmark_results \\
        --num_gpus 8 \\
        --benchmark both

    # 只跑 BeyondArena，指定子集
    python run_tabarena_cls.py \\
        --model tabpfn \\
        --checkpoint my-model.ckpt \\
        --data_dir /path/to/local/openml_cache \\
        --output_dir benchmark_results \\
        --num_gpus 4 \\
        --benchmark beyondarena \\
        --subset core,tiny

数据准备：
    脚本使用本地 OpenML 缓存，不会连接网络。运行前需要将数据预下载到 --data_dir：
    - TabArena:  通过 openml.tasks.get_task(task_id) 预下载到缓存
    - BeyondArena: 先运行一次 materialize 将 data_foundry 数据转换为 OpenML 格式

输出结构：
    {output_dir}/{model_name}/
    ├── tabarena/
    │   ├── per_dataset_results.json   # 每个数据集 mean ± std
    │   └── per_split_results.json     # 每个 split 明细
    └── beyondarena/
        ├── per_dataset_results.json
        └── per_split_results.json
"""

from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import os
import sys
import time
import traceback
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


# ============================================================================
#  命令行参数
# ============================================================================

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="TabArena/BeyondArena 分类任务 GPU 分布式评测",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    # --- 模型 ---
    parser.add_argument("--model", type=str, required=True,
                        choices=["tabpfn", "tabicl"],
                        help="模型类型: tabpfn 或 tabicl")
    parser.add_argument("--checkpoint", type=str, required=True,
                        help="模型 checkpoint 文件路径（.ckpt）")

    # --- 数据 ---
    parser.add_argument("--data_dir", type=str, required=True,
                        help="本地 OpenML 缓存目录（预下载的数据集路径，不连外网）")

    # --- 输出 ---
    parser.add_argument("--output_dir", type=str, default="benchmark_results",
                        help="结果输出根目录（默认: benchmark_results）")
    parser.add_argument("--model_name", type=str, default=None,
                        help="模型显示名称（默认根据 checkpoint 自动生成）")

    # --- Benchmark ---
    parser.add_argument("--benchmark", type=str, default="both",
                        choices=["tabarena", "beyondarena", "both"],
                        help="要运行的 benchmark（默认: both）")
    parser.add_argument("--tabarena_subset", type=str, default="classification",
                        help="TabArena 子集过滤表达式，用 | 组合 "
                             "（默认: classification，即 binary+multiclass）")
    parser.add_argument("--beyondarena_subset", type=str,
                        default="core,classification",
                        help="BeyondArena 子集，逗号分隔（AND 语义），"
                             "默认: core,classification。"
                             "可加 !high-dim 排除高维，"
                             "加 tiny/small/medium/large 限制大小")

    # --- 资源 ---
    parser.add_argument("--num_gpus", type=int, default=1,
                        help="使用的 GPU 数量（默认: 1）")
    parser.add_argument("--num_cpus", type=int, default=None,
                        help="每个任务使用的 CPU 核心数（默认: 自动检测）")
    parser.add_argument("--time_limit", type=int, default=3600,
                        help="每个 split 训练时间上限秒数（默认: 3600）")

    # --- 调试 ---
    parser.add_argument("--debug", action="store_true", default=False,
                        help="debug 模式：只运行少量数据集验证流程")
    parser.add_argument("--debug_datasets", type=int, default=3,
                        help="debug 模式下运行的数据集数量（默认: 3）")

    return parser.parse_args()


# ============================================================================
#  工具函数
# ============================================================================

def get_model_display_name(args: argparse.Namespace) -> str:
    """根据参数生成模型显示名称."""
    if args.model_name:
        return args.model_name
    ckpt_name = Path(args.checkpoint).stem
    return f"{args.model}_{ckpt_name}"


def _numpy_converter(obj: Any) -> Any:
    """JSON 序列化时的 numpy 类型转换."""
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, pd.Timestamp):
        return str(obj)
    return obj


def save_json(data: dict | list, path: Path) -> None:
    """保存为 JSON 文件."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, default=_numpy_converter)


# ============================================================================
#  模型配置构建
# ============================================================================

def build_config_generator(
    model_type: str,
    checkpoint_path: str,
) -> "ConfigGenerator":
    """为指定模型类型构建 ConfigGenerator."""
    from tabarena.utils.config_utils import ConfigGenerator

    if model_type == "tabpfn":
        from tabarena.models.tabpfn_3.model import TabPFN3Model
        model_cls = TabPFN3Model
        manual_config = {
            "checkpoint_per_problem_type": {
                "classification": checkpoint_path,
            },
        }
    elif model_type == "tabicl":
        from tabarena.models.tabicl.model import TabICLv2Model
        model_cls = TabICLv2Model
        ckpt_filename = Path(checkpoint_path).name
        manual_config = {
            "checkpoint_version": ckpt_filename,
            "model_path": checkpoint_path,
        }
    else:
        raise ValueError(f"Unknown model: {model_type}")

    return ConfigGenerator(
        search_space={},
        model_cls=model_cls,
        manual_configs=[manual_config],
    )


# ============================================================================
#  Benchmark Context 构建
# ============================================================================

def build_context(
    benchmark: str,
    data_dir: str,
) -> "AbstractArenaContext":
    """构建 benchmark context（使用本地数据缓存）."""
    from tabarena.caching import CacheConfig
    from tabarena.contexts import BeyondArenaContext, TabArenaContext

    cache_config = CacheConfig(openml=data_dir)

    if benchmark == "tabarena":
        return TabArenaContext(cache_config=cache_config)
    elif benchmark == "beyondarena":
        return BeyondArenaContext(cache_config=cache_config)
    else:
        raise ValueError(f"Unknown benchmark: {benchmark}")


def build_experiments_for_benchmark(
    benchmark: str,
    config_gen: "ConfigGenerator",
    time_limit: int,
) -> list["Experiment"]:
    """为指定 benchmark 构建实验列表."""
    if benchmark == "tabarena":
        from tabarena.benchmark.experiment import TabArenaV0pt1ExperimentBundle
        bundle = TabArenaV0pt1ExperimentBundle(
            models=[(config_gen, 0)],
            outer_experiments=True,
        )
        return bundle.build_experiments(time_limit=time_limit)
    elif benchmark == "beyondarena":
        from tabarena.benchmark.experiment import BeyondArenaExperimentBundle
        bundle = BeyondArenaExperimentBundle(
            models=[(config_gen, 0)],
            outer_experiments=True,
        )
        return bundle.build_experiments(time_limit=time_limit)
    else:
        raise ValueError(f"Unknown benchmark: {benchmark}")


# ============================================================================
#  结果聚合
# ============================================================================

def aggregate_results(
    all_results: list[dict],
) -> tuple[list[dict], dict[str, dict]]:
    """将原始结果列表聚合为 per-split 明细和 per-dataset 汇总.

    Args:
        all_results: 每个元素是 Experiment.run() 返回的 dict，
                     包含 dataset, fold, repeat, metric 等字段.

    Returns:
        (per_split_list, per_dataset_dict)
        - per_split_list: 每个 split 的明细结果列表
        - per_dataset_dict: {dataset_name: {metric_name: {"mean": ..., "std": ..., "splits": [...]}}}
    """
    # 按数据集分组
    by_dataset: dict[str, list[dict]] = {}
    for r in all_results:
        if r is None:
            continue
        ds = r.get("dataset", r.get("task", "unknown"))
        if ds not in by_dataset:
            by_dataset[ds] = []
        by_dataset[ds].append(r)

    # 构建 per-split 列表
    per_split_list = []
    for ds, results in by_dataset.items():
        for r in results:
            per_split_list.append({
                "dataset": ds,
                "fold": r.get("fold"),
                "repeat": r.get("repeat"),
                "metric": r.get("metric"),
                "metric_error": r.get("metric_error"),
                "loss": r.get("loss"),
                **{k: v for k, v in r.items()
                   if k not in ("dataset", "task", "fold", "repeat",
                                "metric", "metric_error", "loss")},
            })

    # 构建 per-dataset 汇总
    per_dataset = {}
    for ds, results in by_dataset.items():
        # metric field is the metric NAME (e.g. "roc_auc"),
        # metric_error field is the actual numeric error value
        metric_name = results[0].get("metric", "unknown") if results else "unknown"
        metric_errors: list[float] = []
        for r in results:
            metric_err = r.get("metric_error")
            if metric_err is not None:
                try:
                    metric_errors.append(float(metric_err))
                except (ValueError, TypeError):
                    pass

        summary = {}
        if metric_errors:
            summary[metric_name] = {
                "mean": float(np.mean(metric_errors)),
                "std": float(np.std(metric_errors, ddof=1)) if len(metric_errors) > 1 else 0.0,
                "n_splits": len(metric_errors),
                "values": metric_errors,
            }

        # 统计数据集基本信息
        summary["n_splits"] = len(results)
        summary["problem_type"] = results[0].get("problem_type", "unknown") if results else "unknown"

        per_dataset[ds] = summary

    return per_split_list, per_dataset


# ============================================================================
#  Worker 进程
# ============================================================================

def _worker_run_jobs(
    gpu_id: int,
    job_dicts: list[dict],
    data_dir: str,
    output_dir: str,
    benchmark: str,
    result_queue: mp.Queue,
) -> None:
    """Worker 进程：在指定 GPU 上运行分配给它的 jobs.

    此函数在独立的子进程中运行，通过 CUDA_VISIBLE_DEVICES 隔离 GPU。
    """
    # --- GPU 隔离 ---
    os.environ["CUDA_VISIBLE_DEVICES"] = str(gpu_id)

    # 验证 GPU 可用性
    try:
        import torch
        if torch.cuda.is_available():
            print(f"[GPU {gpu_id}] CUDA 可用，设备: {torch.cuda.get_device_name(0)}")
        else:
            print(f"[GPU {gpu_id}] 警告: CUDA 不可用，将使用 CPU")
    except ImportError:
        print(f"[GPU {gpu_id}] 警告: torch 未安装")

    worker_start = time.time()
    results: list[dict] = []
    failed: list[dict] = []

    try:
        # --- 反序列化 jobs ---
        from tabarena.benchmark.experiment.job import Job
        jobs = []
        for jd in job_dicts:
            try:
                jobs.append(Job.from_dict(jd))
            except Exception as e:
                print(f"[GPU {gpu_id}] 反序列化 job 失败: {e}")
                failed.append({"job_dict": jd, "error": str(e)})

        if not jobs:
            print(f"[GPU {gpu_id}] 没有有效 job，跳过")
            result_queue.put({"gpu_id": gpu_id, "results": [], "failed": failed})
            return

        print(f"[GPU {gpu_id}] 分配了 {len(jobs)} 个 job，开始执行...")

        # --- 构建 context ---
        from tabarena.caching import CacheConfig
        from tabarena.contexts import BeyondArenaContext, TabArenaContext

        cache_config = CacheConfig(openml=data_dir)
        if benchmark == "tabarena":
            context = TabArenaContext(cache_config=cache_config)
        elif benchmark == "beyondarena":
            context = BeyondArenaContext(cache_config=cache_config)
        else:
            raise ValueError(f"Unknown benchmark: {benchmark}")

        # --- 运行每个 job ---
        worker_expname = str(Path(output_dir) / f"_worker_gpu{gpu_id}")
        for idx, job in enumerate(jobs):
            t0 = time.time()
            try:
                job_results = context.run_job(
                    job,
                    expname=worker_expname,
                    register=False,
                )
                if job_results:
                    # run_job returns list[dict] (one per job)
                    results.extend(job_results)
                elapsed = time.time() - t0
                print(f"[GPU {gpu_id}] [{idx + 1}/{len(jobs)}] "
                      f"{job.task.dataset} fold={job.task.fold} "
                      f"完成 ({elapsed:.1f}s)")
            except Exception as e:
                elapsed = time.time() - t0
                err_msg = (
                    f"[GPU {gpu_id}] [{idx + 1}/{len(jobs)}] "
                    f"{job.task.dataset} fold={job.task.fold} "
                    f"失败 ({elapsed:.1f}s): {e}"
                )
                print(err_msg)
                traceback.print_exc()
                failed.append({
                    "dataset": job.task.dataset,
                    "fold": job.task.fold,
                    "repeat": job.task.repeat,
                    "error": str(e),
                })

    except Exception as e:
        print(f"[GPU {gpu_id}] Worker 致命错误: {e}")
        traceback.print_exc()
    finally:
        worker_elapsed = time.time() - worker_start
        print(f"[GPU {gpu_id}] Worker 完成: {len(results)} 成功, "
              f"{len(failed)} 失败, 耗时 {worker_elapsed:.1f}s")
        result_queue.put({
            "gpu_id": gpu_id,
            "results": results,
            "failed": failed,
            "elapsed": worker_elapsed,
        })


# ============================================================================
#  主流程
# ============================================================================

def run_benchmark(
    args: argparse.Namespace,
    benchmark: str,
    model_name: str,
    output_dir: Path,
) -> dict:
    """在指定 benchmark 上运行分类评测（GPU 分布式）."""
    print("\n" + "=" * 60)
    print(f"  {benchmark.upper()} 分类评测 (GPU 分布式)")
    print(f"  模型: {args.model}")
    print(f"  Checkpoint: {args.checkpoint}")
    print(f"  数据目录: {args.data_dir}")
    print(f"  GPU 数量: {args.num_gpus}")
    print("=" * 60)

    bench_dir = output_dir / benchmark
    bench_dir.mkdir(parents=True, exist_ok=True)

    # --- Step 1: 构建 context 和实验 ---
    print("\n[1/5] 构建 context 和实验...")
    context = build_context(benchmark, args.data_dir)
    config_gen = build_config_generator(args.model, args.checkpoint)
    experiments = build_experiments_for_benchmark(benchmark, config_gen, args.time_limit)

    # --- Step 2: 构建 jobs ---
    print("[2/5] 构建 job 列表...")
    if benchmark == "tabarena":
        subset = args.tabarena_subset
    else:
        subset = [s.strip() for s in args.beyondarena_subset.split(",")]

    # 对于 TabArena，subset 是表达式字符串（支持 | 组合）
    # 对于 BeyondArena，subset 是字符串列表
    if benchmark == "tabarena":
        jobs = context.build_jobs(experiments, subset=subset)
    else:
        jobs = context.build_jobs(experiments, subset=subset)

    # Debug 模式：限制数据集数量
    if args.debug:
        # 收集所有唯一数据集
        unique_datasets = list(dict.fromkeys(j.task.dataset for j in jobs))
        debug_datasets = set(unique_datasets[:args.debug_datasets])
        jobs = [j for j in jobs if j.task.dataset in debug_datasets]
        print(f"  [DEBUG] 限制到 {len(debug_datasets)} 个数据集: {debug_datasets}")
        print(f"  [DEBUG] 共 {len(jobs)} 个 job")

    print(f"  共 {len(jobs)} 个 job "
          f"({len(set(j.task.dataset for j in jobs))} 个数据集)")

    if not jobs:
        print("  没有 job 需要运行，跳过")
        return {"benchmark": benchmark, "num_jobs": 0, "error": "No jobs"}

    # --- Step 3: 预物化数据 ---
    print("[3/5] 预加载数据到本地缓存...")
    t0 = time.time()
    context.task_metadata_collection.subset_to_jobs(jobs).materialize()
    print(f"  数据就绪，耗时 {time.time() - t0:.1f}s")

    # --- Step 4: GPU 分布式执行 ---
    print(f"[4/5] 启动 {args.num_gpus} 个 GPU worker 并行执行...")

    # 将 jobs 序列化为 dict（方便跨进程传递）
    job_dicts = [j.to_dict() for j in jobs]

    # 将 jobs 按 round-robin 分配到各 GPU
    gpu_job_dicts: list[list[dict]] = [[] for _ in range(args.num_gpus)]
    for i, jd in enumerate(job_dicts):
        gpu_job_dicts[i % args.num_gpus].append(jd)

    print("  各 GPU job 分配:")
    for gid, jds in enumerate(gpu_job_dicts):
        datasets_in_gpu = set(jd["dataset"] for jd in jds)
        print(f"    GPU {gid}: {len(jds)} jobs, {len(datasets_in_gpu)} 个数据集")

    # 使用 spawn 方式启动 worker 进程（确保 CUDA 初始化正确）
    mp.set_start_method("spawn", force=True)
    result_queue: mp.Queue = mp.Queue()
    processes = []

    for gpu_id in range(args.num_gpus):
        if not gpu_job_dicts[gpu_id]:
            continue
        p = mp.Process(
            target=_worker_run_jobs,
            args=(
                gpu_id,
                gpu_job_dicts[gpu_id],
                args.data_dir,
                str(output_dir),
                benchmark,
                result_queue,
            ),
        )
        p.start()
        processes.append(p)

    # 收集结果
    all_results: list[dict] = []
    all_failed: list[dict] = []
    for _ in processes:
        worker_result = result_queue.get()
        all_results.extend(worker_result.get("results", []))
        all_failed.extend(worker_result.get("failed", []))

    # 等待所有进程结束
    for p in processes:
        p.join()

    t_total = time.time() - t0
    print(f"\n  GPU 分布式执行完成: {len(all_results)} 成功, "
          f"{len(all_failed)} 失败, 总耗时 {t_total:.1f}s")

    # --- Step 5: 聚合结果 ---
    print("[5/5] 聚合结果...")
    per_split_list, per_dataset = aggregate_results(all_results)

    # 保存结果
    save_json(per_split_list, bench_dir / "per_split_results.json")
    save_json(per_dataset, bench_dir / "per_dataset_results.json")

    # 构建摘要
    summary = {
        "benchmark": benchmark,
        "model": model_name,
        "model_type": args.model,
        "checkpoint": args.checkpoint,
        "num_gpus": args.num_gpus,
        "num_jobs": len(jobs),
        "num_success": len(all_results),
        "num_failed": len(all_failed),
        "num_datasets": len(per_dataset),
        "elapsed_seconds": t_total,
    }

    # 计算全局平均指标
    all_metric_values = []
    for ds_info in per_dataset.values():
        if "metric" in ds_info:
            all_metric_values.extend(ds_info["metric"]["values"])
    if all_metric_values:
        summary["avg_metric"] = float(np.mean(all_metric_values))
        summary["std_metric"] = float(np.std(all_metric_values, ddof=1))

    save_json(summary, bench_dir / "summary.json")

    # 打印摘要
    print(f"\n  {benchmark.upper()} 分类评测结果:")
    print(f"    数据集数: {summary['num_datasets']}")
    print(f"    成功/失败: {summary['num_success']}/{summary['num_failed']}")
    if "avg_metric" in summary:
        print(f"    平均指标: {summary['avg_metric']:.4f} ± {summary['std_metric']:.4f}")
    print(f"    总耗时: {t_total:.1f}s")

    return summary


# ============================================================================
#  入口
# ============================================================================

def main() -> None:
    args = parse_args()

    model_name = get_model_display_name(args)
    output_dir = Path(args.output_dir) / model_name
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print(f"  TabArena / BeyondArena 分类任务 GPU 分布式评测")
    print(f"  模型: {args.model}")
    print(f"  Checkpoint: {args.checkpoint}")
    print(f"  名称: {model_name}")
    print(f"  数据目录: {args.data_dir}")
    print(f"  输出目录: {output_dir}")
    print(f"  GPU 数量: {args.num_gpus}")
    print(f"  Benchmark: {args.benchmark}")
    print("=" * 60)

    overall = {
        "model": model_name,
        "model_type": args.model,
        "checkpoint": args.checkpoint,
        "data_dir": args.data_dir,
        "num_gpus": args.num_gpus,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "benchmarks": {},
    }

    benchmarks_to_run = []
    if args.benchmark in ("tabarena", "both"):
        benchmarks_to_run.append("tabarena")
    if args.benchmark in ("beyondarena", "both"):
        benchmarks_to_run.append("beyondarena")

    for benchmark in benchmarks_to_run:
        try:
            overall["benchmarks"][benchmark] = run_benchmark(
                args, benchmark, model_name, output_dir,
            )
        except Exception as e:
            print(f"\n  [ERROR] {benchmark.upper()} 评测失败: {e}")
            if args.debug:
                traceback.print_exc()
            overall["benchmarks"][benchmark] = {"error": str(e)}

    # 保存综合汇总
    save_json(overall, output_dir / "overall_summary.json")

    print("\n" + "=" * 60)
    print("  所有分类评测完成!")
    print(f"  结果保存在: {output_dir}")
    print("=" * 60)

    # 打印最终摘要
    for bench_name, bench_info in overall["benchmarks"].items():
        if "error" in bench_info:
            print(f"  {bench_name}: ERROR - {bench_info['error']}")
        else:
            ds = bench_info.get("num_datasets", "?")
            ok = bench_info.get("num_success", "?")
            fail = bench_info.get("num_failed", "?")
            ela = bench_info.get("elapsed_seconds", 0)
            avg = bench_info.get("avg_metric")
            print(f"  {bench_name}: {ds} 数据集, "
                  f"{ok}/{fail} 成功/失败, "
                  f"耗时 {ela:.1f}s"
                  + (f", 平均指标 {avg:.4f}" if avg is not None else ""))


if __name__ == "__main__":
    main()
