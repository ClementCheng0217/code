#!/usr/bin/env python3
"""
全量 Benchmark 编排：自动发现本地 TabPFN / TabICL / LimiX / TabFM，
一键运行 TabArena + BeyondArena + TALENT（分类+回归）。

- 使用分布式推理框架，每个 split 分到不同 GPU
- TabArena / BeyondArena 使用各自的 split；TALENT 使用官方固定
  train/val/test split，并把不同 seed 作为 per-split 明细
- 跳过 /ssd/lamdatfm/chengzj/datasets 中不存在的数据集并记录原因
- 每个 benchmark 生成两个 CSV：
  CSV 1: per-split（数据集名、split 编号、任务类型、各模型性能）
  CSV 2: per-dataset（数据集名、split 总数、任务类型、各模型性能）
- 不存在的数据集在 CSV 中备注
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import multiprocessing as mp
import os
import re
import signal
import time
import traceback
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from benchmark_model_registry import (
    DEFAULT_MODELS_DIR,
    ModelSpec,
    discover_models,
    registry_inventory,
    select_models,
)
from talent_benchmark import (
    TALENT_EVALUATION_PROTOCOL,
    TALENT_EXAMPLE_DATA,
    generate_talent_csvs,
    parse_talent_dataset_selection,
    run_talent_benchmark,
)

# ============================================================================
#  环境设置
# ============================================================================
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TABPFN_CACHE_DIR", "/ssd/lamdatfm/.cache/tabpfn")
os.environ.setdefault("DATA_FOUNDRY_CACHE", "/ssd/lamdatfm/chengzj/datasets")
os.environ.setdefault(
    "OPENML_CACHE_DIR",
    "/ssd/lamdatfm/chengzj/datasets/openml_cache",
)
os.environ.setdefault(
    "XDG_CONFIG_HOME",
    "/ssd/lamdatfm/chengzj/.config",
)

import tabpfn.browser_auth as ba
ba.ensure_license_accepted = lambda hf_repo_id: True

# ============================================================================
#  路径常量
# ============================================================================
MODELS_DIR = DEFAULT_MODELS_DIR
DATASETS_BASE = Path("/ssd/lamdatfm/chengzj/datasets")
DATA_DIR = "/ssd/lamdatfm/chengzj/datasets/openml_cache"
TALENT_DATA_DIR = DATASETS_BASE / "talent"
RUNNER_SCHEMA_VERSION = 1

# ============================================================================
#  数据集存在性检查
# ============================================================================

# 预扫描可用的 BeyondArena 数据集目录
# 只包含确实有 dataset.parquet 文件的目录，排除下载不完整的数据集
_BA_AVAILABLE_DIRS: set[str] = set()
_ba_path = DATASETS_BASE / "beyondarena"
if _ba_path.is_dir():
    for d in _ba_path.iterdir():
        if not d.is_dir():
            continue
        # 跳过 HF 缓存目录
        if d.name.startswith("datasets--"):
            continue
        # 检查是否有 dataset.parquet 文件（任意深度）
        has_parquet = any(p.name == "dataset.parquet" for p in d.rglob("dataset.parquet"))
        if has_parquet:
            _BA_AVAILABLE_DIRS.add(d.name)


def check_dataset_exists(benchmark: str, dataset_name: str) -> bool:
    """检查数据集是否存在于本地缓存。

    BeyondArena 的 job 中 dataset_name 格式为 "数据集名-12位hex"（如
    "amazon_employee_access-4417c4c952bc"），而文件系统目录只有纯数据集名。
    部分长名称会被截断（如 "predict_students_dropout_and_academic_su"）。
    因此需要剥离 UUID 后缀后进行最长前缀匹配。
    """
    if benchmark == "beyondarena":
        # 1) 尝试直接匹配
        ds_dir = DATASETS_BASE / "beyondarena" / dataset_name
        if ds_dir.is_dir() and any(ds_dir.iterdir()):
            return True

        # 2) 剥离 UUID 后缀（最后一段 "-12位hex"）
        parts = dataset_name.rsplit("-", 1)
        base_name = dataset_name
        if len(parts) == 2 and len(parts[1]) == 12:
            base_name = parts[0]

        # 3) 在已扫描目录中匹配：精确匹配或双向前缀匹配
        #     - avail_dir.startswith(base_name): 处理截断名称（如 "intention_dat" vs "intention_dataset"）
        #     - base_name.startswith(avail_dir): 处理 _1m 后缀（如 "mercari_price_suggestion_1m" vs "mercari_price_suggestion"）
        for avail_dir in _BA_AVAILABLE_DIRS:
            if avail_dir == base_name or avail_dir.startswith(base_name) or base_name.startswith(avail_dir):
                return True
        return False

    elif benchmark == "tabarena":
        # TabArena 数据缓存在 openml_cache 中
        cache_dir = Path(DATA_DIR) / "tabarena_tasks"
        if cache_dir.is_dir():
            for f in cache_dir.iterdir():
                if f.name.startswith(dataset_name):
                    return True
        # 也检查 tabarena 原始数据目录
        ta_dir = DATASETS_BASE / "tabarena"
        return ta_dir.is_dir()
    return True


def filter_jobs_by_data_availability(
    benchmark: str,
    jobs: list,
) -> tuple[list, dict[str, str]]:
    """过滤 jobs：移除本地无数据的数据集，返回 (valid_jobs, missing_dataset_notes)。"""
    missing_notes: dict[str, str] = {}

    # 收集所有数据集名
    dataset_names = list(dict.fromkeys(j.task.dataset for j in jobs))

    for ds_name in dataset_names:
        if not check_dataset_exists(benchmark, ds_name):
            missing_notes[ds_name] = "数据集不存在于本地缓存"

    valid_jobs = [j for j in jobs if j.task.dataset not in missing_notes]

    if missing_notes:
        print(f"  ⚠ 跳过 {len(missing_notes)} 个不存在的数据集: {list(missing_notes.keys())}")

    return valid_jobs, missing_notes


# ============================================================================
#  模型配置构建与 Worker
# ============================================================================

def build_config_generator(
    arena_adapter: str,
    checkpoint_path: str,
    task_type: str,
    n_estimators: int | None = None,
):
    """构建模型 ConfigGenerator。task_type: 'classification' 或 'regression'。"""
    from tabarena.utils.config_utils import ConfigGenerator

    if arena_adapter == "tabpfn":
        from tabarena.models.tabpfn_3.model import TabPFN3Model
        model_cls = TabPFN3Model
        # TabPFN uses checkpoint_per_problem_type dict
        manual_config: dict[str, Any] = {
            "checkpoint_per_problem_type": {
                task_type: checkpoint_path,
            },
        }
    elif arena_adapter == "tabpfn_v2_legacy":
        from legacy_tabpfn_v2_model import LocalLegacyTabPFNV2Model
        model_cls = LocalLegacyTabPFNV2Model
        manual_config = {"checkpoint_path": checkpoint_path}
    elif arena_adapter in {"tabicl_v1", "tabicl_v2"}:
        _force_local_wrapper = (
            os.environ.get("TABICL_FORCE_LOCAL_WRAPPER", "0") == "1"
        )
        if arena_adapter == "tabicl_v1" or (
            "/models/self/" not in checkpoint_path and not _force_local_wrapper
        ):
            from tabarena.models.tabicl.model import TabICLModel, TabICLv2Model
            model_cls = (
                TabICLModel
                if arena_adapter == "tabicl_v1"
                else TabICLv2Model
            )
        else:
            # 自训练 TabICL v2 ckpt：用本地包装类，preprocess 后数值化所有列
            # （beyondarena 部分数据集含 string 列，tabicl X_encoder 内部
            # isnan 检查会崩溃；ag_name 保持 TA-TabICLv2 以统一 framework 名）。
            from local_tabicl_model import LocalTabICLv2Model
            model_cls = LocalTabICLv2Model
        # TabICL 的 _load_model:
        #   - classifier 先验证 checkpoint_version 必须是已知短名称（如
        #     "tabicl-classifier-v2-20260212.ckpt"），再检查 model_path
        #   - regressor 不验证 checkpoint_version
        # 因此：checkpoint_version 用短名称，model_path 用绝对路径
        ckpt_filename = Path(checkpoint_path).name
        # 自训练 checkpoint：checkpoint_version 置换为官方白名单名称，
        # 以通过 classifier _load_model 的版本校验；实际权重始终从 model_path 加载。
        _OFFICIAL_TABICL = frozenset({
            "tabicl-classifier-v1-20250208.ckpt",
            "tabicl-classifier-v1.1-20250506.ckpt",
            "tabicl-classifier-v2-20260212.ckpt",
            "tabicl-regressor-v1-20250208.ckpt",
            "tabicl-regressor-v1.1-20250506.ckpt",
            "tabicl-regressor-v2-20260212.ckpt",
        })
        if ckpt_filename not in _OFFICIAL_TABICL:
            ckpt_filename = (
                "tabicl-classifier-v2-20260212.ckpt"
                if task_type == "classification"
                else "tabicl-regressor-v2-20260212.ckpt"
            )
        manual_config = {
            "checkpoint_version": ckpt_filename,
            "model_path": checkpoint_path,
        }
    elif arena_adapter == "limix":
        from tabarena.models.limix.model import LimiXModel
        model_cls = LimiXModel
        manual_config = {"model_path": checkpoint_path}
    elif arena_adapter == "tabfm":
        from tabfm_model import LocalTabFMModel
        model_cls = LocalTabFMModel
        manual_config = {"checkpoint_path": checkpoint_path}
    elif arena_adapter == "exaone_tabular":
        from exaone_model import LocalEXAONETabularModel
        model_cls = LocalEXAONETabularModel
        manual_config = {"checkpoint_path": checkpoint_path}
    elif arena_adapter == "tabswift":
        from tabswift_model import LocalTabSwiftModel
        model_cls = LocalTabSwiftModel
        manual_config = {"checkpoint_path": checkpoint_path}
    elif arena_adapter == "mitra":
        # Mitra v2: AutoGluon 内置 MitraModel（TabArena 官方 adapter 同款），
        # hf_model 指向本地 checkpoint 目录（Tab2D.from_pretrained 支持）。
        from autogluon.tabular.models import MitraModel
        model_cls = MitraModel
        manual_config = {"hf_model": checkpoint_path}
        if os.environ.get("RELAX_MITRA_AG_LIMITS", "0") == "1":
            # [RELAX] 强制补测：放开 AutoGluon 模型自身的能力上限
            # （MitraModel 默认 max_rows=10000 / max_features=500 / max_classes=10）。
            # ag.ignore_constraints 直接跳过 validate_fit_args 的全部检查；
            # ag.max_* 显式置 None 作双保险（覆盖 _get_default_auxiliary_params）。
            # ag.max_memory_usage_ratio 抬高内存校验阈值：MitraModel 的保守估算公式
            # （1.3*(100*rows*features+1e6) KB）在大 rows*features 时给出 TB 级假阳性，
            # 会被 _validate_fit_memory_usage 以 NotEnoughMemoryError 拒绝（如 APSFailure）。
            manual_config.update({
                "ag.ignore_constraints": True,
                "ag.max_rows": None,
                "ag.max_features": None,
                "ag.max_classes": None,
                "ag.max_memory_usage_ratio": 1e9,
            })
    elif arena_adapter == "tabldm":
        from tabldm_model import LocalTabLDMModel
        model_cls = LocalTabLDMModel
        manual_config = {"model_path": checkpoint_path}
    else:
        raise ValueError(f"Unknown arena adapter: {arena_adapter}")

    if n_estimators is not None and arena_adapter != "limix":
        manual_config["n_estimators"] = n_estimators

    return ConfigGenerator(
        search_space={},
        model_cls=model_cls,
        manual_configs=[manual_config],
    )


def build_context(benchmark: str, data_dir: str):
    """构建 benchmark context。"""
    from tabarena.caching import CacheConfig
    from tabarena.contexts import BeyondArenaContext, TabArenaContext

    cache_config = CacheConfig(openml=data_dir)
    if benchmark == "tabarena":
        return TabArenaContext(cache_config=cache_config)
    elif benchmark == "beyondarena":
        return BeyondArenaContext(cache_config=cache_config)
    else:
        raise ValueError(f"Unknown benchmark: {benchmark}")


def build_experiments(benchmark: str, config_gen, time_limit: int):
    """构建实验列表。"""
    # [RELAX] env 门控：覆盖 bundle 的默认模型约束（如 "MITRA" -> 空 ModelConstraints()），
    # 用于被约束过滤掉的 job 的强制补测。不影响未设置该 env 的一切现有行为。
    _extra_kwargs: dict = {}
    _relax_constraints = os.environ.get("RELAX_MODEL_CONSTRAINTS", "").strip()
    if _relax_constraints:
        from tabarena.benchmark.experiment import ModelConstraints
        _keys = [k.strip() for k in _relax_constraints.split(",") if k.strip()]
        _extra_kwargs["custom_model_constraints"] = {
            k: ModelConstraints() for k in _keys
        }
        print(f"  [RELAX] 放开模型约束: {_keys} -> 空 ModelConstraints()")
    if benchmark == "tabarena":
        from tabarena.benchmark.experiment import TabArenaV0pt1ExperimentBundle
        bundle = TabArenaV0pt1ExperimentBundle(
            models=[(config_gen, 0)],
            outer_experiments=True,
            **_extra_kwargs,
        )
        return bundle.build_experiments(time_limit=time_limit)
    elif benchmark == "beyondarena":
        from tabarena.benchmark.experiment import BeyondArenaExperimentBundle
        bundle = BeyondArenaExperimentBundle(
            models=[(config_gen, 0)],
            outer_experiments=True,
            **_extra_kwargs,
        )
        return bundle.build_experiments(time_limit=time_limit)
    raise ValueError(f"Unknown benchmark: {benchmark}")


class _JobTimeoutError(Exception):
    """单个 job 超时异常。"""
    pass


def _job_timeout_handler(signum, frame):
    raise _JobTimeoutError("Job execution timed out")


def _patch_limix_worker_resources() -> None:
    """Clamp an experiment's host GPU count to the worker-visible device."""
    _patch_limix_flash_attn_batch()
    _patch_limix_linear_chunk()
    from autogluon.common.utils.resource_utils import ResourceManager
    from tabarena.models.limix.model import LimiXModel

    if getattr(LimiXModel._fit, "_unified_runner_patch", False):
        return
    original_fit = LimiXModel._fit

    def patched_fit(self, X, y, num_gpus=0, **kwargs):
        available = ResourceManager.get_gpu_count_torch(cuda_only=True)
        requested = min(num_gpus, available) if available else 0
        return original_fit(
            self,
            X,
            y,
            num_gpus=requested,
            **kwargs,
        )

    patched_fit._unified_runner_patch = True
    LimiXModel._fit = patched_fit


def _patch_limix_flash_attn_batch() -> None:
    """flash_attn varlen 的 batch 上限是 65535（CUDA gridDim.z 限制）。

    LimiX 在 qkv_combined（sequence attention）阶段把 train+eval 全部样本
    作为 varlen 的 batch，当样本数 > 65535 时内核启动报
    CUDA error: invalid configuration argument。

    这里 monkey-patch layer 模块的 flash_attn 函数：batch 超限时按
    cu_seqlens 切块分别调用（flash_attn 对每个序列独立计算，分块结果
    与全量完全一致），不修改任何模型/库文件。
    """
    try:
        import torch
        import tabarena.models.limix._vendor.model.layer as layer_mod
    except ImportError:
        return
    if getattr(layer_mod, "_fa_batch_patch_done", False):
        return
    orig_packed = layer_mod.flash_attn_varlen_qkvpacked_func
    orig_kv = layer_mod.flash_attn_varlen_kvpacked_func
    MAX_BATCH = 60000  # flash_attn varlen batch 硬上限 65535，留余量

    def safe_packed(qkv, cu, max_s, **kwargs):
        B = cu.numel() - 1
        if B <= MAX_BATCH:
            return orig_packed(qkv, cu, max_s, **kwargs)
        outs = []
        i = 0
        while i < B:
            j = min(i + MAX_BATCH, B)
            s, e = int(cu[i]), int(cu[j])
            cu_c = cu[i:j + 1] - cu[i]
            outs.append(orig_packed(qkv[s:e], cu_c, max_s, **kwargs))
            i = j
        return torch.cat(outs, dim=0)

    def safe_kv(q, kv, cu_q, cu_k, max_q, max_k, **kwargs):
        Bq = cu_q.numel() - 1
        if Bq <= MAX_BATCH:
            return orig_kv(q, kv, cu_q, cu_k, max_q, max_k, **kwargs)
        outs = []
        i = 0
        while i < Bq:
            j = min(i + MAX_BATCH, Bq)
            s, e = int(cu_q[i]), int(cu_q[j])
            cu_qc = cu_q[i:j + 1] - cu_q[i]
            outs.append(orig_kv(q[s:e], kv, cu_qc, cu_k, max_q, max_k, **kwargs))
            i = j
        return torch.cat(outs, dim=0)

    layer_mod.flash_attn_varlen_qkvpacked_func = safe_packed
    layer_mod.flash_attn_varlen_kvpacked_func = safe_kv
    layer_mod._fa_batch_patch_done = True
    print("[LimiX] flash_attn batch 分块 patch 已安装 (MAX_BATCH=60000)")


def _patch_limix_linear_chunk() -> None:
    """cublasLt fp16 对单次 matmul 的行数有限制。

    LimiX 的 gate_mlp 等 Linear 层会把 (S, F) 展平为 (S*F) 行参与
    matmul，特征多的数据集（如 Bioresponse 1776 特征、hiva 1518 特征）
    或样本大的数据集（APSFailure 76000×170、kddcup 50000×212）行数
    可达 500 万以上，触发
    CUDA error: CUBLAS_STATUS_NOT_SUPPORTED (cublasLtMatmul)。

    这里 monkey-patch nn.Linear.forward：输入行数超过阈值时按行分块
    分别执行（每行独立计算，分块结果与全量完全一致），不修改任何
    模型/库文件。
    """
    try:
        import torch
        import torch.nn as nn
    except ImportError:
        return
    if getattr(nn.Linear, "_chunk_patch_done", False):
        return
    orig_fwd = nn.Linear.forward
    CHUNK_ROWS = 2_000_000  # 保守阈值：5g(62075×21≈130万) 可正常跑

    def chunked_fwd(self, input):
        if (
            input.dim() >= 2
            and getattr(input, "is_cuda", False)
        ):
            rows = input.numel() // input.shape[-1]
            if rows > CHUNK_ROWS:
                leading = input.shape[:-1]
                flat = input.reshape(-1, input.shape[-1])
                parts = [
                    orig_fwd(self, c)
                    for c in flat.split(CHUNK_ROWS, dim=0)
                ]
                out = torch.cat(parts, dim=0)
                return out.reshape(*leading, -1)
        return orig_fwd(self, input)

    nn.Linear.forward = chunked_fwd
    nn.Linear._chunk_patch_done = True
    print("[LimiX] nn.Linear 大行数分块 patch 已安装 (CHUNK_ROWS=2M)")


def _worker_run_jobs(
    gpu_id: int,
    job_dicts: list[dict],
    data_dir: str,
    output_dir: str,
    benchmark: str,
    arena_adapter: str,
    result_queue: mp.Queue,
    job_timeout: int = 1800,
    tid_of: dict | None = None,  # 默认 30 分钟
) -> None:
    """GPU worker 进程。每个 job 有超时限制，超时则跳过。"""
    if arena_adapter == "limix":
        _patch_limix_worker_resources()

    try:
        import torch
        if torch.cuda.is_available():
            print(
                f"[GPU {gpu_id}] CUDA_VISIBLE_DEVICES="
                f"{os.environ.get('CUDA_VISIBLE_DEVICES')}; "
                f"torch可见卡数={torch.cuda.device_count()}; "
                f"设备={torch.cuda.get_device_name(0)}"
            )
    except ImportError:
        pass

    worker_start = time.time()
    results: list[dict] = []
    failed: list[dict] = []

    try:
        from tabarena.benchmark.experiment.job import Job
        jobs = []
        for jd in job_dicts:
            try:
                jobs.append(Job.from_dict(jd))
            except Exception as e:
                failed.append({"job_dict": jd, "error": str(e)})

        if not jobs:
            result_queue.put({"gpu_id": gpu_id, "results": [], "failed": failed})
            return

        print(f"[GPU {gpu_id}] 分配了 {len(jobs)} 个 job，开始执行...")

        from tabarena.caching import CacheConfig
        from tabarena.contexts import BeyondArenaContext, TabArenaContext
        cache_config = CacheConfig(openml=data_dir)
        context = (TabArenaContext if benchmark == "tabarena" else BeyondArenaContext)(cache_config=cache_config)

        worker_expname = str(Path(output_dir) / f"_worker_gpu{gpu_id}")
        # tabicl offload 目录（model.py 内 mkdtemp(prefix=f"tabicl_{os.getpid()}_")）
        # 在 fit 完成后不会自删，会持续膨胀打满 /tmp（曾一次积累 800G+）。
        # 每个 job 的 fit+predict 结束后删除本 job 新建的目录；目录名带 PID，
        # 多 worker 进程互不干扰。
        _offload_glob = f"/tmp/tabicl_{os.getpid()}_*"

        def _cleanup_offload(prev: set) -> None:
            try:
                import glob as _glob
                import shutil as _shutil
                for d in set(_glob.glob(_offload_glob)) - prev:
                    _shutil.rmtree(d, ignore_errors=True)
            except Exception:
                pass

        _cleanup_offload(set())  # 清掉 PID 复用可能遗留的旧目录
        for idx, job in enumerate(jobs):
            t0 = time.time()
            # 记录本 job 开始前的自身 offload 目录（上轮 job 残留属正常）
            _offload_prev = set()
            try:
                import glob as _glob
                _offload_prev = set(_glob.glob(_offload_glob))
            except Exception:
                pass
            # 已有缓存 (results.pkl) 的 job 直接跳过，避免重放时触发 openml 下载卡住
            _tid = (tid_of or {}).get(str(job.task.dataset))
            if _tid:
                _cache_pkl = (
                    Path(worker_expname) / "data" / job.experiment.name / _tid
                    / f"{job.task.repeat}_{job.task.fold}" / "results.pkl"
                )
                if _cache_pkl.exists():
                    print(f"[GPU {gpu_id}] [{idx + 1}/{len(jobs)}] "
                          f"{job.task.dataset} fold={job.task.fold} 已有缓存，跳过")
                    continue
            try:
                # 为每个 job 设置超时 alarm（仅 Unix）
                if hasattr(signal, "SIGALRM"):
                    old_handler = signal.signal(signal.SIGALRM, _job_timeout_handler)
                    signal.alarm(job_timeout)
                try:
                    job_results = context.run_job(job, expname=worker_expname, register=False)
                finally:
                    if hasattr(signal, "SIGALRM"):
                        signal.alarm(0)
                        signal.signal(signal.SIGALRM, old_handler)
                if job_results:
                    results.extend(job_results)
                elapsed = time.time() - t0
                print(f"[GPU {gpu_id}] [{idx + 1}/{len(jobs)}] "
                      f"{job.task.dataset} fold={job.task.fold} 完成 ({elapsed:.1f}s)")
            except _JobTimeoutError:
                elapsed = time.time() - t0
                print(f"[GPU {gpu_id}] [{idx + 1}/{len(jobs)}] "
                      f"{job.task.dataset} fold={job.task.fold} ⏰超时 ({elapsed:.1f}s > {job_timeout}s)，跳过")
                failed.append({
                    "dataset": job.task.dataset,
                    "fold": job.task.fold,
                    "repeat": job.task.repeat,
                    "error": f"Job timed out after {elapsed:.1f}s (limit: {job_timeout}s)",
                })
            except Exception as e:
                elapsed = time.time() - t0
                print(f"[GPU {gpu_id}] [{idx + 1}/{len(jobs)}] "
                      f"{job.task.dataset} fold={job.task.fold} 失败 ({elapsed:.1f}s): {e}")
                traceback.print_exc()
                failed.append({
                    "dataset": job.task.dataset,
                    "fold": job.task.fold,
                    "repeat": job.task.repeat,
                    "error": str(e),
                })
            finally:
                # 无论成功/超时/失败，fit+predict 均已结束，清理本 job 的 offload 目录
                _cleanup_offload(_offload_prev)
    except Exception as e:
        print(f"[GPU {gpu_id}] Worker 致命错误: {e}")
        traceback.print_exc()
    finally:
        worker_elapsed = time.time() - worker_start
        print(f"[GPU {gpu_id}] Worker 完成: {len(results)} 成功, "
              f"{len(failed)} 失败, 耗时 {worker_elapsed:.1f}s")
        result_queue.put({
            "gpu_id": gpu_id,
            "results": results,
            "failed": failed,
            "elapsed": worker_elapsed,
        })


# ============================================================================
#  单项运行
# ============================================================================

def run_single(
    model_name: str,
    arena_adapter: str,
    checkpoint_path: str,
    benchmark: str,           # "beyondarena" | "tabarena"
    task_type: str,           # "classification" | "regression"
    num_gpus: int,
    output_dir: Path,
    time_limit: int = 3600,
    debug: bool = False,
    debug_datasets: int = 2,
    debug_splits_per_dataset: int = 1,
    beyondarena_subset: str = "all",
    ba_max_train_rows: int | None = None,
    ba_max_cols: int | None = None,
    n_estimators: int | None = None,
    datasets: list[str] | None = None,
) -> dict:
    """运行单个模型×benchmark×任务组合，返回结果摘要。"""
    checkpoint_path = str(Path(checkpoint_path).expanduser().resolve())
    model_tag = f"{model_name}_{task_type[:3]}"
    run_name = f"{benchmark}_{model_tag}"
    print(f"\n{'=' * 70}")
    print(f"  {run_name.upper()}")
    print(f"  Model: {model_name} | Task: {task_type} | Benchmark: {benchmark}")
    print(f"  Adapter: {arena_adapter}")
    print(f"  Checkpoint: {checkpoint_path}")
    print(f"  GPUs: {num_gpus}")
    print(f"{'=' * 70}")

    out_dir = output_dir / benchmark / model_tag
    out_dir.mkdir(parents=True, exist_ok=True)

    run_config = {
        "runner_schema_version": RUNNER_SCHEMA_VERSION,
        "benchmark": benchmark,
        "task_type": task_type,
        "model_name": model_name,
        "arena_adapter": arena_adapter,
        "checkpoint": checkpoint_path,
        "n_estimators": n_estimators,
        "time_limit": time_limit,
        "debug": debug,
        "debug_datasets": debug_datasets if debug else None,
        "debug_splits_per_dataset": (
            debug_splits_per_dataset if debug else None
        ),
        "beyondarena_subset": (
            beyondarena_subset
            if benchmark == "beyondarena"
            else None
        ),
        "ba_max_train_rows": (
            ba_max_train_rows
            if benchmark == "beyondarena"
            else None
        ),
        "ba_max_cols": (
            ba_max_cols
            if benchmark == "beyondarena"
            else None
        ),
        "datasets": datasets,
        "data_dir": DATA_DIR,
    }
    run_cache_key = hashlib.sha256(
        json.dumps(
            run_config,
            ensure_ascii=True,
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()[:16]

    # 恢复能力：如果 raw_results.json 已存在，跳过运行
    raw_results_path = out_dir / "raw_results.json"
    if raw_results_path.exists():
        # 加载已有 summary
        summary_path = out_dir / "summary.json"
        if summary_path.exists():
            cached_summary = load_json(summary_path)
            if (
                cached_summary.get("run_config") == run_config
                and cached_summary.get("num_failed", 0) == 0
                and cached_summary.get("num_success")
                == cached_summary.get("num_jobs")
            ):
                print(f"  ✅ 已有匹配结果 {raw_results_path}，跳过运行")
                return cached_summary
            print("  ⚠ 已有结果配置与本次不同，将重新运行")
        # 如果 summary 不存在，从 raw_results 重建
        elif raw_results_path.exists():
            print("  ⚠ raw_results 缺少可校验的 summary，将重新运行")

    # Step 1: 构建 context, config, experiments
    print("[1/5] 构建 context 和实验...")
    context = build_context(benchmark, DATA_DIR)
    config_gen = build_config_generator(
        arena_adapter,
        checkpoint_path,
        task_type,
        n_estimators=n_estimators,
    )
    experiments = build_experiments(benchmark, config_gen, time_limit)

    # Step 2: 构建 jobs + 子集过滤
    print("[2/5] 构建 job 列表...")
    if benchmark == "tabarena":
        subset = task_type  # "classification" or "regression"
    else:
        # BeyondArena: 使用 beyondarena_subset 参数（逗号分隔多个谓词，AND），
        # 如 "tiny,small,medium,low-dim"；默认 "all"
        subset = [
            s.strip()
            for s in beyondarena_subset.split(",")
            if s.strip()
        ] + [task_type]

    build_kwargs: dict = {"subset": subset}
    if benchmark == "beyondarena" and (
        ba_max_train_rows is not None or ba_max_cols is not None
    ):
        # 输入规模过滤（split 级）：训练样本数 <= ba_max_train_rows、
        # 预处理后特征数 < ba_max_cols，用于 EXAONE-Tabular 等有输入规模
        # 限制的模型（support_row_limit=100000 / feature_limit=100）
        if ba_max_cols is not None:
            from tabarena.benchmark.task.subset_predicate import SubsetPredicate

            preds = dict(context.subset_predicates)
            preds["exaone_cols_ok"] = SubsetPredicate(
                lambda df, lim=ba_max_cols: (
                    df["num_cols_after_preprocessing"] < lim
                ),
                ("num_cols_after_preprocessing",),
            )
            build_kwargs["predicates"] = preds
            build_kwargs["subset"] = [*subset, "exaone_cols_ok"]
        if ba_max_train_rows is not None:
            build_kwargs["n_train_samples"] = (0, ba_max_train_rows)
        print(
            f"  规模过滤: 训练样本 <= {ba_max_train_rows} 行, "
            f"特征 < {ba_max_cols} 列"
        )

    jobs = context.build_jobs(experiments, **build_kwargs)

    # 过滤本地不存在的数据集
    jobs, missing_notes = filter_jobs_by_data_availability(benchmark, jobs)

    # 按数据集名过滤（子串匹配，如 "5g_energy" / "sepsis"）
    if datasets:
        before = len(jobs)
        jobs = [
            j for j in jobs
            if any(ds in str(j.task.dataset) for ds in datasets)
        ]
        print(f"  --datasets 过滤: {before} -> {len(jobs)} 个 job")

    # Debug 模式限制
    if debug:
        unique_datasets = list(dict.fromkeys(j.task.dataset for j in jobs))
        debug_datasets_set = set(unique_datasets[:debug_datasets])
        jobs = [j for j in jobs if j.task.dataset in debug_datasets_set]
        if debug_splits_per_dataset > 0:
            split_counts: dict[str, int] = defaultdict(int)
            limited_jobs = []
            for job in jobs:
                dataset = job.task.dataset
                if split_counts[dataset] >= debug_splits_per_dataset:
                    continue
                limited_jobs.append(job)
                split_counts[dataset] += 1
            jobs = limited_jobs
        print(
            f"  [DEBUG] 限制到 {len(debug_datasets_set)} 个数据集、"
            "每数据集 "
            f"{debug_splits_per_dataset or '全部'} 个 split: "
            f"{debug_datasets_set}"
        )

    n_datasets = len(set(j.task.dataset for j in jobs))
    print(f"  共 {len(jobs)} 个 job ({n_datasets} 个数据集)")

    if not jobs:
        print("  没有有效 job，跳过")
        return {
            "benchmark": benchmark, "model_type": model_name, "task_type": task_type,
            "arena_adapter": arena_adapter,
            "num_jobs": 0, "num_datasets": 0, "error": "No valid jobs",
            "missing_datasets": missing_notes,
        }

    # Step 3: 预加载数据
    print("[3/5] 预加载数据到本地缓存...")
    t0 = time.time()
    context.task_metadata_collection.subset_to_jobs(jobs).materialize()
    print(f"  数据就绪，耗时 {time.time() - t0:.1f}s")

    # Step 4: GPU 分布式执行
    print(f"[4/5] 启动 {num_gpus} 个 GPU worker 并行执行...")
    job_dicts = [j.to_dict() for j in jobs]
    gpu_job_dicts: list[list[dict]] = [[] for _ in range(num_gpus)]
    for i, jd in enumerate(job_dicts):
        gpu_job_dicts[i % num_gpus].append(jd)

    print("  各 GPU job 分配:")
    for gid, jds in enumerate(gpu_job_dicts):
        if jds:
            datasets_in_gpu = set(jd["dataset"] for jd in jds)
            print(f"    GPU {gid}: {len(jds)} jobs, {len(datasets_in_gpu)} 个数据集")

    mp.set_start_method("spawn", force=True)
    result_queue: mp.Queue = mp.Queue()
    processes = []

    original_visible_devices = os.environ.get("CUDA_VISIBLE_DEVICES")
    visible_device_pool = (
        [
            item.strip()
            for item in original_visible_devices.split(",")
            if item.strip()
        ]
        if original_visible_devices
        else [str(index) for index in range(num_gpus)]
    )
    if len(visible_device_pool) < num_gpus:
        raise ValueError(
            f"--num_gpus={num_gpus}，但 CUDA_VISIBLE_DEVICES 仅包含 "
            f"{visible_device_pool}"
        )
    try:
        for gpu_id in range(num_gpus):
            if not gpu_job_dicts[gpu_id]:
                continue
            # ``spawn`` imports this module before entering the worker target.
            # Set visibility before ``start`` so CUDA is never initialized with
            # all GPUs and every child sees exactly one logical ``cuda:0``.
            os.environ["CUDA_VISIBLE_DEVICES"] = visible_device_pool[gpu_id]
            p = mp.Process(
                target=_worker_run_jobs,
                args=(
                    gpu_id,
                    gpu_job_dicts[gpu_id],
                    DATA_DIR,
                    str(out_dir / "_runs" / run_cache_key),
                    benchmark,
                    arena_adapter,
                    result_queue,
                    time_limit,
                ),
            )
            p.start()
            processes.append(p)
    finally:
        if original_visible_devices is None:
            os.environ.pop("CUDA_VISIBLE_DEVICES", None)
        else:
            os.environ["CUDA_VISIBLE_DEVICES"] = original_visible_devices

    import queue
    all_results: list[dict] = []
    all_failed: list[dict] = []
    # A full Arena model/task can contain hundreds of sequential jobs per
    # worker.  Scale the parent watchdog with that workload instead of
    # truncating every run at a fixed eight hours.
    max_jobs_per_worker = max(
        (len(job_group) for job_group in gpu_job_dicts),
        default=0,
    )
    total_timeout = (
        max(28_800, (time_limit + 60) * max_jobs_per_worker)
        if time_limit > 0
        else None
    )
    deadline = (
        time.time() + total_timeout
        if total_timeout is not None
        else None
    )
    completed = 0
    while completed < len(processes):
        remaining = (
            deadline - time.time()
            if deadline is not None
            else None
        )
        if remaining is not None and remaining <= 0:
            print(f"  总超时 ({total_timeout}s)，已收集 {completed}/{len(processes)}，跳过剩余")
            break
        # 每 30 秒轮询一次，同时检查 worker 是否还活着
        try:
            queue_timeout = (
                min(remaining, 30)
                if remaining is not None
                else 30
            )
            wr = result_queue.get(timeout=queue_timeout)
            all_results.extend(wr.get("results", []))
            all_failed.extend(wr.get("failed", []))
            completed += 1
        except queue.Empty:
            # 检查剩余 worker 是否都死了
            alive_count = sum(1 for p in processes if p.is_alive())
            if alive_count == 0:
                print(f"  所有 Worker 已退出（崩溃），已收集 {completed}/{len(processes)}，跳过剩余")
                # 非阻塞捞一下可能遗漏的结果
                while True:
                    try:
                        wr = result_queue.get_nowait()
                        all_results.extend(wr.get("results", []))
                        all_failed.extend(wr.get("failed", []))
                        completed += 1
                    except queue.Empty:
                        break
                break
            continue
    print(f"  共收集 {completed}/{len(processes)} 个 Worker 结果")

    for p in processes:
        p.join(timeout=30)
        if p.is_alive():
            p.terminate()
            p.join(timeout=5)

    t_total = time.time() - t0
    print(f"\n  GPU 分布式执行完成: {len(all_results)} 成功, "
          f"{len(all_failed)} 失败, 总耗时 {t_total:.1f}s")

    # Step 5: 保存原始结果
    print("[5/5] 保存结果...")
    save_json(all_results, out_dir / "raw_results.json")
    save_json({"failed": all_failed, "missing_datasets": missing_notes},
              out_dir / "errors.json")

    summary = {
        "benchmark": benchmark, "model_type": model_name, "task_type": task_type,
        "arena_adapter": arena_adapter,
        "checkpoint": checkpoint_path, "num_gpus": num_gpus,
        "n_estimators": n_estimators,
        "run_config": run_config,
        "run_cache_key": run_cache_key,
        "num_jobs": len(jobs), "num_datasets": n_datasets,
        "num_success": len(all_results), "num_failed": len(all_failed),
        "elapsed_seconds": t_total,
        "missing_datasets": missing_notes,
    }
    save_json(summary, out_dir / "summary.json")
    return summary


# ============================================================================
#  直传 ckpt 模式（绕过模型注册表扫描，单个 ckpt 直接运行）
# ============================================================================

_ADAPTER_META = {
    "tabpfn": ("tabpfn", "tabpfn_v3"),
    "tabpfn_v2_legacy": ("tabpfn", "tabpfn_v2"),
    "tabicl_v1": ("tabicl", "tabicl"),
    "tabicl_v2": ("tabicl", "tabicl_v2"),
    "limix": ("limix", "limix"),
    "tabfm": ("tabfm", "tabfm"),
    "tabswift": ("tabswift", "tabswift"),
    "exaone_tabular": ("exaone-tabular", "exaone_tabular"),
    "mitra": ("mitra", "mitra"),
    "tabldm": ("tabldm", "tabldm"),
}

_TALENT_OFFICIAL_N_ESTIMATORS = {
    "exaone_tabular": 8,
    "tabswift": 16,
}


def resolve_talent_n_estimators(
    talent_method: str,
    override: int | None,
) -> int:
    """Return an explicit override or the method's official TALENT default."""
    if override is not None:
        return override
    return _TALENT_OFFICIAL_N_ESTIMATORS.get(talent_method, 32)

_STEP_CHECKPOINT_PATTERNS = (
    re.compile(r"^step-(?P<step>\d+)\.ckpt$"),
    re.compile(
        r"^step_(?P<step>\d+)_(?P<variant>ema|lawa_\d+)\.ckpt$"
    ),
)


def _parse_step_checkpoint(path: Path) -> tuple[int, str] | None:
    for pattern in _STEP_CHECKPOINT_PATTERNS:
        match = pattern.fullmatch(path.name)
        if match is not None:
            return int(match.group("step")), match.groupdict().get("variant") or "default"
    return None


def resolve_direct_checkpoint(path: Path) -> tuple[Path, dict[str, Any]]:
    """Resolve a file directly or select the numerically latest ckpt in a dir."""
    requested = path.expanduser().resolve()
    if requested.is_file():
        return requested, {
            "selection_mode": "explicit_checkpoint_file",
            "requested_path": str(requested),
            "selected_checkpoint": str(requested),
            "checkpoint_step": None,
        }
    if not requested.is_dir():
        raise ValueError(
            f"--direct_ckpt 不存在，或不是 ckpt 文件/目录: {requested}"
        )

    candidates: list[tuple[int, str, Path]] = []
    for candidate in requested.rglob("*.ckpt"):
        parsed = _parse_step_checkpoint(candidate)
        if parsed is not None and candidate.is_file():
            step, variant = parsed
            candidates.append((step, variant, candidate.resolve()))
    if not candidates:
        raise ValueError(f"目录中没有可识别的 step checkpoint: {requested}")
    candidates.sort(key=lambda item: (item[0], item[1], str(item[2])))
    max_step = candidates[-1][0]
    latest = [item for item in candidates if item[0] == max_step]
    selected_row = None
    for preferred_variant in ("ema", "default"):
        preferred = [item for item in latest if item[1] == preferred_variant]
        if len(preferred) == 1:
            selected_row = preferred[0]
            break
        if len(preferred) > 1:
            raise ValueError(
                f"目录内最大 step={max_step} 对应多个 {preferred_variant} ckpt: "
                f"{[item[2] for item in preferred]}"
            )
    if selected_row is None and len(latest) == 1:
        selected_row = latest[0]
    if selected_row is None:
        raise ValueError(
            f"目录内最大 step={max_step} 没有唯一的 EMA/default ckpt，请改传具体文件: "
            f"{[item[2] for item in latest]}"
        )
    _, selected_variant, selected = selected_row
    return selected, {
        "selection_mode": "latest_checkpoint",
        "selection_rule": (
            "maximum numeric step from recognized checkpoints; prefer EMA "
            "when multiple variants share that step"
        ),
        "requested_path": str(requested),
        "available_checkpoint_count": len(candidates),
        "selected_checkpoint": str(selected),
        "checkpoint_step": max_step,
        "checkpoint_variant": selected_variant,
    }


def build_direct_spec(
    ckpt_path: Path,
    adapter: str,
    model_name: str,
    task_types: list[str],
) -> ModelSpec:
    """由单个 ckpt 路径直接构造 ModelSpec，不经过目录扫描。

    TabICL 分类模型的 checkpoint_version 白名单校验已由
    build_config_generator 自动替换处理，任意路径均可直接使用。
    """
    if adapter not in _ADAPTER_META:
        raise ValueError(
            f"未知 adapter: {adapter}。可选: {sorted(_ADAPTER_META)}"
        )
    family, talent_method = _ADAPTER_META[adapter]
    return ModelSpec(
        name=model_name,
        family=family,
        arena_adapter=adapter,
        talent_method=talent_method,
        checkpoints={task: ckpt_path for task in task_types},
        artifacts=(ckpt_path,),
    )


# ============================================================================
#  CSV 生成
# ============================================================================

def _metric_name_for_task(task_type: str) -> str:
    # Arena persists a normalized error rather than the scorer's raw value.
    # For ROC-AUC that is 1 - AUC; RMSE is already error-oriented.
    return "1-ROC-AUC" if task_type == "classification" else "RMSE"


def _format_value(mean: float | None, std: float | None) -> str:
    """格式化为 "mean ± std" 保留三位小数。"""
    if mean is None:
        return "N/A"
    if std is None or std == 0.0:
        return f"{mean:.3f}"
    return f"{mean:.3f}±{std:.3f}"


def _extract_dataset_name(result: dict) -> str:
    """从原始结果中提取数据集名称。

    结果格式为嵌套结构：task_metadata.name 包含完整数据集名（含 UUID），
    也可能有顶层 dataset 字段。
    """
    task_meta = result.get("task_metadata", {})
    if isinstance(task_meta, dict) and task_meta.get("name"):
        return task_meta["name"]
    return result.get("dataset", result.get("task", "unknown"))


def _extract_fold(result: dict) -> int | None:
    """从原始结果中提取 fold 编号。"""
    task_meta = result.get("task_metadata", {})
    if isinstance(task_meta, dict) and "fold" in task_meta:
        return task_meta["fold"]
    return result.get("fold")


def collect_split_results(all_raw_results: list[dict], task_type: str) -> dict:
    """从原始结果列表收集 per-split 结果。

    Returns: {dataset_name: {split_identifier: metric_value}}
    split_identifier = f"r{repeat}_f{fold}" 以区分不同 repeat 的同一 fold。
    """
    split_map: dict[str, dict[str, float]] = defaultdict(dict)
    for r in all_raw_results:
        if r is None:
            continue
        ds = _extract_dataset_name(r)
        fold = _extract_fold(r)
        if fold is None:
            continue
        task_meta = r.get("task_metadata", {})
        repeat = task_meta.get("repeat", 0) if isinstance(task_meta, dict) else 0
        split_key = f"r{repeat}_f{fold}"

        # 获取 metric_error 值（分类用 metric_error，回归可能也用 metric_error）
        metric_err = r.get("metric_error")
        if metric_err is not None:
            try:
                split_map[ds][split_key] = float(metric_err)
            except (ValueError, TypeError):
                pass
    return dict(split_map)


def generate_csvs(
    benchmark: str,
    results: dict[tuple[str, str], list[dict]],
    notes: dict[str, dict[str, str]],
    output_dir: Path,
    model_names: list[str] | None = None,
) -> None:
    """为任意数量的本地模型生成动态宽表 CSV。"""
    bench_dir = output_dir / benchmark
    bench_dir.mkdir(parents=True, exist_ok=True)

    if model_names is None:
        ordered_models = sorted({model for _, model in results})
    else:
        ordered_models = list(dict.fromkeys(model_names))
    split_results = {
        key: collect_split_results(raw, key[0])
        for key, raw in results.items()
    }
    task_labels = {"classification": "分类", "regression": "回归"}
    per_split_rows: list[dict[str, Any]] = []
    per_dataset_rows: list[dict[str, Any]] = []

    for task_type in ("classification", "regression"):
        metric_name = _metric_name_for_task(task_type)
        task_models = [
            model
            for model in ordered_models
            if (task_type, model) in split_results
        ]
        splits_by_model = {
            model: split_results[(task_type, model)]
            for model in task_models
        }
        task_notes = notes.get(task_type, {})
        datasets = sorted(
            set(task_notes).union(
                *(
                    set(dataset_map)
                    for dataset_map in splits_by_model.values()
                )
            )
        )

        for dataset in datasets:
            model_splits = {
                model: splits_by_model[model].get(dataset, {})
                for model in task_models
            }
            split_ids = sorted(
                set().union(
                    *(set(values) for values in model_splits.values())
                )
            )
            note = task_notes.get(dataset, "")
            if not split_ids:
                row: dict[str, Any] = {
                    "数据集名字": dataset,
                    "split编号": "N/A",
                    "分类/回归": task_labels[task_type],
                    "指标（越低越好）": metric_name,
                    "备注": note or "无成功结果",
                }
                row.update(
                    {
                        f"{model}性能": "N/A"
                        for model in ordered_models
                    }
                )
                per_split_rows.append(row)
            else:
                for split_id in split_ids:
                    row = {
                        "数据集名字": dataset,
                        "split编号": split_id,
                        "分类/回归": task_labels[task_type],
                        "指标（越低越好）": metric_name,
                        "备注": note,
                    }
                    row.update(
                        {
                            f"{model}性能": (
                                _format_value(
                                    model_splits[model].get(split_id),
                                    None,
                                )
                                if model in model_splits
                                else "N/A"
                            )
                            for model in ordered_models
                        }
                    )
                    if not row["备注"] and any(
                        split_id not in model_splits[model]
                        for model in task_models
                    ):
                        row["备注"] = "部分模型缺失"
                    per_split_rows.append(row)

            row = {
                "数据集名字": dataset,
                "split总数": max(
                    (len(values) for values in model_splits.values()),
                    default=0,
                ),
                "分类/回归": task_labels[task_type],
                "指标（越低越好）": metric_name,
                "备注": note,
            }
            for model in ordered_models:
                values = list(model_splits.get(model, {}).values())
                mean = float(np.mean(values)) if values else None
                std = (
                    float(np.std(values, ddof=1))
                    if len(values) > 1
                    else None
                )
                row[f"{model}性能"] = _format_value(mean, std)
            if not row["备注"] and any(
                not model_splits[model]
                for model in task_models
            ):
                row["备注"] = "部分模型缺失"
            per_dataset_rows.append(row)

    model_fields = [f"{model}性能" for model in ordered_models]
    split_fields = [
        "数据集名字",
        "split编号",
        "分类/回归",
        "指标（越低越好）",
        *model_fields,
        "备注",
    ]
    dataset_fields = [
        "数据集名字",
        "split总数",
        "分类/回归",
        "指标（越低越好）",
        *model_fields,
        "备注",
    ]
    split_path = bench_dir / "per_split_results.csv"
    dataset_path = bench_dir / "per_dataset_results.csv"
    with split_path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=split_fields)
        writer.writeheader()
        writer.writerows(per_split_rows)
    with dataset_path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=dataset_fields)
        writer.writeheader()
        writer.writerows(per_dataset_rows)
    print(f"  ✅ {split_path}: {len(per_split_rows)} 行")
    print(f"  ✅ {dataset_path}: {len(per_dataset_rows)} 行")


# ============================================================================
#  JSON 工具
# ============================================================================

def _numpy_converter(obj: Any) -> Any:
    if isinstance(obj, (np.integer,)): return int(obj)
    if isinstance(obj, (np.floating,)): return float(obj)
    if isinstance(obj, np.ndarray): return obj.tolist()
    if isinstance(obj, pd.Timestamp): return str(obj)
    return obj


def save_json(data: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, default=_numpy_converter)


def load_json(path: Path) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# ============================================================================
#  主流程
# ============================================================================

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="全量 Benchmark 编排")
    p.add_argument("--output_dir", type=str, default="benchmark_results")
    p.add_argument(
        "--models_dir",
        type=str,
        default=str(MODELS_DIR),
        help=f"本地模型根目录（默认: {MODELS_DIR}）",
    )
    p.add_argument(
        "--models",
        type=str,
        default="all",
        help=(
            "逗号分隔的模型名或模型族（tabpfn/tabicl/limix/tabfm）；"
            "默认 all"
        ),
    )
    p.add_argument(
        "--list_models",
        action="store_true",
        help="列出自动发现的模型、任务与 checkpoint 后退出",
    )
    p.add_argument("--num_gpus", type=int, default=8)
    p.add_argument("--time_limit", type=int, default=3600)
    p.add_argument("--benchmarks", type=str, default="tabarena,beyondarena,talent",
                   help="逗号分隔: tabarena,beyondarena,talent（默认全部）")
    p.add_argument("--debug", action="store_true", default=False)
    p.add_argument("--debug_datasets", type=int, default=2)
    p.add_argument(
        "--debug_splits_per_dataset",
        type=int,
        default=1,
        help="Debug 时每个 Arena 数据集最多运行的 split 数；0 表示全部",
    )
    p.add_argument("--skip_tabpfn", action="store_true", default=False)
    p.add_argument("--skip_tabicl", action="store_true", default=False)
    p.add_argument("--skip_limix", action="store_true", default=False)
    p.add_argument("--skip_tabfm", action="store_true", default=False)
    p.add_argument(
        "--model_n_estimators",
        type=int,
        default=None,
        help="覆盖 TabArena/BeyondArena 模型 ensemble 数；默认使用模型配置",
    )
    p.add_argument("--cls_only", action="store_true", default=False)
    p.add_argument("--reg_only", action="store_true", default=False)
    p.add_argument("--beyondarena_subset", type=str, default="all",
                   help="BeyondArena subset 谓词名，逗号分隔多个谓词（AND 交集），"
                        "如 tiny,small,medium,low-dim；支持 ! 取反；默认: all")
    p.add_argument(
        "--ba_max_train_rows",
        type=int,
        default=None,
        help="BeyondArena 训练样本数上限（split 级过滤，含边界）；默认不限制",
    )
    p.add_argument(
        "--ba_max_cols",
        type=int,
        default=None,
        help="BeyondArena 预处理后特征数上限（split 级过滤，不含边界）；"
             "默认不限制",
    )
    p.add_argument(
        "--datasets",
        type=str,
        default=None,
        help="逗号分隔的数据集名子串过滤（如 '5g_energy,sepsis'）；默认不限制",
    )
    p.add_argument(
        "--talent_data_path",
        type=str,
        default=None,
        help=(
            "TALENT 300 数据集根目录（每个子目录包含 info.json 和 *.npy）；"
            f"默认 {TALENT_DATA_DIR}，debug 且默认目录不存在时使用内置示例"
        ),
    )
    p.add_argument(
        "--talent_datasets",
        type=str,
        default=None,
        help="TALENT 数据集名，逗号分隔；默认使用官方 300 数据集列表",
    )
    p.add_argument(
        "--talent_seed_num",
        type=int,
        default=1,
        help="TALENT 每个数据集运行的随机种子数（默认: 1）",
    )
    p.add_argument(
        "--talent_n_estimators",
        type=int,
        default=None,
        help=(
            "覆盖 TALENT ensemble 数量；默认按方法官方配置选择 "
            "（EXAONE=8、TabSwift=16、其余现有 ICL 适配器=32，LimiX 忽略）"
        ),
    )
    p.add_argument(
        "--talent_time_limit",
        type=int,
        default=3600,
        help="TALENT 单个数据集/模型的超时秒数，0 表示不限制（默认: 3600）",
    )
    p.add_argument(
        "--exaone_source_path",
        type=str,
        default=None,
        help=(
            "EXAONE-Tabular 官方源码 checkout 根目录或 src 目录；"
            "显式指定后 TALENT 会校验实际导入路径"
        ),
    )
    p.add_argument(
        "--exaone_max_vram_gib",
        type=float,
        default=None,
        help=(
            "EXAONE-Tabular 每个 TALENT worker 的显存预算（GiB）；"
            "只控制官方运行时的等价分块，不改变 ensemble_count"
        ),
    )
    p.add_argument(
        "--direct_ckpt",
        type=str,
        default=None,
        help=(
            "直传单个 ckpt 文件或 checkpoint 目录，绕过模型注册表扫描；"
            "传目录时默认选择数值 step 最大的 checkpoint（同 step 优先 EMA），确保 "
            "TabArena/BeyondArena/TALENT 共用同一权重。配合 "
            "--direct_adapter / --model_name / --cls_only / --reg_only 使用"
        ),
    )
    p.add_argument(
        "--direct_adapter",
        type=str,
        default="tabicl_v2",
        help="直传模式使用的 arena adapter: tabpfn/tabpfn_v2_legacy/"
             "tabicl_v1/tabicl_v2/limix/tabfm/tabswift/exaone_tabular"
             "（默认: tabicl_v2）",
    )
    p.add_argument(
        "--model_name",
        type=str,
        default=None,
        help="直传模式的输出模型名（默认: ckpt-<文件名>）",
    )
    return p.parse_args()


def _append_note(
    notes: dict[str, str],
    dataset: str,
    message: str,
) -> None:
    previous = notes.get(dataset)
    if previous and message not in previous:
        notes[dataset] = f"{previous}; {message}"
    elif not previous:
        notes[dataset] = message


def _print_model_inventory(registry: dict[str, ModelSpec]) -> None:
    inventory = registry_inventory(registry)
    print(
        f"发现 {inventory['num_models']} 个逻辑模型，"
        f"覆盖 {inventory['num_artifacts']} 个权重文件"
    )
    print("模型名\t任务\tArena适配器\tTALENT方法\tcheckpoint")
    for spec in registry.values():
        checkpoints = "; ".join(
            f"{task}={path}"
            for task, path in spec.checkpoints.items()
        )
        print(
            f"{spec.name}\t{','.join(spec.task_types)}\t"
            f"{spec.arena_adapter}\t{spec.talent_method}\t{checkpoints}"
        )


def main() -> None:
    args = parse_args()
    direct_selection: dict[str, Any] | None = None
    if args.direct_ckpt is not None:
        # ---- 直传模式：单个 ckpt 直接运行，不扫描模型目录 ----
        requested_ckpt = Path(args.direct_ckpt)
        ckpt_path, direct_selection = resolve_direct_checkpoint(requested_ckpt)
        direct_task_types = []
        if not args.reg_only:
            direct_task_types.append("classification")
        if not args.cls_only:
            direct_task_types.append("regression")
        if not direct_task_types:
            raise ValueError("--cls_only 与 --reg_only 不能同时指定")
        default_name_source = (
            requested_ckpt.expanduser().resolve().name
            if requested_ckpt.expanduser().resolve().is_dir()
            else ckpt_path.stem
        )
        model_name = args.model_name or f"ckpt-{default_name_source}"
        direct_selection["model_name"] = model_name
        direct_selection["adapter"] = args.direct_adapter
        direct_selection["task_types"] = direct_task_types
        registry = {
            model_name: build_direct_spec(
                ckpt_path,
                args.direct_adapter,
                model_name,
                direct_task_types,
            )
        }
        print(
            f"直传 ckpt 模式（绕过模型注册表）: {ckpt_path}\n"
            f"  -> 模型名 {model_name} | adapter {args.direct_adapter} | "
            f"任务 {direct_task_types}"
        )
        if args.list_models:
            _print_model_inventory(registry)
            return
        models = list(registry.values())
    else:
        registry = discover_models(args.models_dir)
        if args.list_models:
            _print_model_inventory(registry)
            return
        skipped_families = {
            family
            for family, skipped in (
                ("tabpfn", args.skip_tabpfn),
                ("tabicl", args.skip_tabicl),
                ("limix", args.skip_limix),
                ("tabfm", args.skip_tabfm),
            )
            if skipped
        }
        models = select_models(
            args.models,
            registry,
            skipped_families=skipped_families,
        )
    if not models:
        raise ValueError("模型筛选后为空")
    if args.model_n_estimators is not None and args.model_n_estimators < 1:
        raise ValueError("--model_n_estimators 必须至少为 1")
    if args.debug_datasets < 1:
        raise ValueError("--debug_datasets 必须至少为 1")
    if args.debug_splits_per_dataset < 0:
        raise ValueError("--debug_splits_per_dataset 不能小于 0")

    output_root = Path(args.output_dir)
    output_root.mkdir(parents=True, exist_ok=True)
    if direct_selection is not None:
        direct_selection["benchmarks"] = [
            benchmark.strip()
            for benchmark in args.benchmarks.split(",")
            if benchmark.strip()
        ]
        save_json(
            direct_selection,
            output_root / "checkpoint_selection.json",
        )

    benchmarks = list(
        dict.fromkeys(
            b.strip()
            for b in args.benchmarks.split(",")
            if b.strip()
        )
    )
    unknown_benchmarks = sorted(set(benchmarks) - {"tabarena", "beyondarena", "talent"})
    if unknown_benchmarks:
        raise ValueError(f"未知 benchmark: {unknown_benchmarks}")
    if args.num_gpus < 1:
        raise ValueError("--num_gpus 必须至少为 1")
    if args.talent_n_estimators is not None and args.talent_n_estimators < 1:
        raise ValueError("--talent_n_estimators 必须至少为 1")
    if args.exaone_max_vram_gib is not None and args.exaone_max_vram_gib <= 0:
        raise ValueError("--exaone_max_vram_gib 必须大于 0")
    exaone_max_vram_bytes = (
        int(args.exaone_max_vram_gib * 1024**3)
        if args.exaone_max_vram_gib is not None
        else None
    )
    talent_dataset_names = parse_talent_dataset_selection(args.talent_datasets)
    if args.talent_data_path:
        talent_data_path = Path(args.talent_data_path).expanduser().resolve()
    else:
        talent_data_path = TALENT_DATA_DIR
        has_default_talent_data = (
            talent_data_path.is_dir()
            and any(talent_data_path.glob("*/info.json"))
        )
        if args.debug and not has_default_talent_data:
            talent_data_path = TALENT_EXAMPLE_DATA

    task_types = []
    if not args.reg_only:
        task_types.append("classification")
    if not args.cls_only:
        task_types.append("regression")
    if not task_types:
        task_types = ["classification", "regression"]

    print("=" * 70)
    print("  全量 Benchmark 编排")
    print(f"  Benchmarks: {benchmarks}")
    print(f"  Task types: {task_types}")
    print(f"  Models ({len(models)}): {[spec.name for spec in models]}")
    print(
        "  Weight files: "
        f"{len({path for spec in models for path in spec.artifacts})}"
    )
    print(f"  GPUs: {args.num_gpus}")
    print(f"  Debug: {args.debug}")
    if "talent" in benchmarks:
        print(f"  TALENT data: {talent_data_path}")
        estimator_description = (
            str(args.talent_n_estimators)
            if args.talent_n_estimators is not None
            else "per-method official default"
        )
        print(
            f"  TALENT seeds/estimators: "
            f"{args.talent_seed_num}/{estimator_description}"
        )
        print(f"  TALENT evaluation: {TALENT_EVALUATION_PROTOCOL}")
        if args.exaone_source_path is not None:
            print(f"  EXAONE source: {Path(args.exaone_source_path).expanduser().resolve()}")
        if exaone_max_vram_bytes is not None:
            print(f"  EXAONE max VRAM: {args.exaone_max_vram_gib:g} GiB")
    print("=" * 70)

    overall_start = time.time()
    all_summaries: list[dict] = []

    for benchmark in benchmarks:
        print(f"\n{'#' * 70}")
        print(f"#  BENCHMARK: {benchmark.upper()}")
        print(f"{'#' * 70}")

        # 存储该 benchmark 的所有原始结果
        bench_results: dict[tuple[str, str], list[dict]] = {}
        bench_missing: dict[str, dict[str, str]] = {}

        for task_type in task_types:
            for model in models:
                checkpoint = model.checkpoint_for(task_type)
                if checkpoint is None:
                    print(
                        f"  ↷ 跳过 {model.name}/{task_type}: "
                        "该权重不支持此任务"
                    )
                    continue
                checkpoint_string = str(checkpoint)
                if not checkpoint.exists():
                    print(
                        f"  ⚠ 跳过 {model.name}/{task_type}: "
                        f"checkpoint 不存在 ({checkpoint})"
                    )
                    continue

                try:
                    if benchmark == "talent":
                        summary = run_talent_benchmark(
                            model_name=model.name,
                            talent_method=model.talent_method,
                            checkpoint_path=checkpoint,
                            task_type=task_type,
                            num_gpus=args.num_gpus,
                            output_dir=output_root,
                            data_path=talent_data_path,
                            dataset_names=talent_dataset_names,
                            seed_num=args.talent_seed_num,
                            n_estimators=resolve_talent_n_estimators(
                                model.talent_method,
                                args.talent_n_estimators,
                            ),
                            source_path=(
                                args.exaone_source_path
                                if model.talent_method == "exaone_tabular"
                                else None
                            ),
                            max_vram_bytes=(
                                exaone_max_vram_bytes
                                if model.talent_method == "exaone_tabular"
                                else None
                            ),
                            time_limit=args.talent_time_limit,
                            debug=args.debug,
                            debug_datasets=args.debug_datasets,
                        )
                    else:
                        summary = run_single(
                            model_name=model.name,
                            arena_adapter=model.arena_adapter,
                            checkpoint_path=checkpoint_string,
                            benchmark=benchmark,
                            task_type=task_type,
                            num_gpus=args.num_gpus,
                            output_dir=output_root,
                            time_limit=args.time_limit,
                            debug=args.debug,
                            debug_datasets=args.debug_datasets,
                            debug_splits_per_dataset=(
                                args.debug_splits_per_dataset
                            ),
                            beyondarena_subset=args.beyondarena_subset,
                            ba_max_train_rows=args.ba_max_train_rows,
                            ba_max_cols=args.ba_max_cols,
                            n_estimators=args.model_n_estimators,
                            datasets=(
                                [d.strip() for d in args.datasets.split(",") if d.strip()]
                                if args.datasets else None
                            ),
                        )
                    all_summaries.append(summary)

                    # 加载原始结果用于 CSV 合并
                    out_dir = (
                        output_root
                        / benchmark
                        / f"{model.name}_{task_type[:3]}"
                    )
                    raw_path = out_dir / "raw_results.json"
                    if raw_path.exists():
                        bench_results[(task_type, model.name)] = load_json(raw_path)
                    else:
                        bench_results[(task_type, model.name)] = []

                    # 记录缺失数据集
                    if "missing_datasets" in summary:
                        task_notes = bench_missing.setdefault(task_type, {})
                        for dataset, reason in summary["missing_datasets"].items():
                            _append_note(
                                task_notes,
                                str(dataset),
                                str(reason),
                            )
                    if "failed_datasets" in summary:
                        task_notes = bench_missing.setdefault(task_type, {})
                        for dataset, error in summary["failed_datasets"].items():
                            _append_note(
                                task_notes,
                                str(dataset),
                                f"{model.name} 运行失败: {error}",
                            )

                except Exception as e:
                    print(
                        f"\n  ❌ {benchmark}/{task_type}/{model.name} "
                        f"失败: {e}"
                    )
                    traceback.print_exc()
                    all_summaries.append({
                        "benchmark": benchmark,
                        "task_type": task_type,
                        "model_type": model.name,
                        "error": str(e),
                    })
                    bench_results[(task_type, model.name)] = []

        # 生成 CSV
        print(f"\n{'─' * 50}")
        print(f"  生成 {benchmark.upper()} CSV...")
        print(f"{'─' * 50}")

        # 汇总本次所选模型此前落盘的结果，支持断点续跑与分任务执行。
        for saved_task_type in ("classification", "regression"):
            for saved_model in models:
                if saved_model.checkpoint_for(saved_task_type) is None:
                    continue
                saved_key = (saved_task_type, saved_model.name)
                saved_dir = (
                    output_root
                    / benchmark
                    / f"{saved_model.name}_{saved_task_type[:3]}"
                )
                saved_raw_path = saved_dir / "raw_results.json"
                if saved_key not in bench_results and saved_raw_path.exists():
                    bench_results[saved_key] = load_json(saved_raw_path)

                saved_errors_path = saved_dir / "errors.json"
                if saved_errors_path.exists():
                    saved_errors = load_json(saved_errors_path)
                    task_notes = bench_missing.setdefault(saved_task_type, {})
                    for dataset, reason in saved_errors.get(
                        "missing_datasets",
                        {},
                    ).items():
                        _append_note(
                            task_notes,
                            str(dataset),
                            str(reason),
                        )
                    saved_failures = saved_errors.get("failed", [])
                    if isinstance(saved_failures, dict):
                        for dataset, error in saved_failures.items():
                            _append_note(
                                task_notes,
                                str(dataset),
                                f"{saved_model.name} 运行失败: {error}",
                            )
                    else:
                        for item in saved_failures:
                            if not isinstance(item, dict):
                                continue
                            _append_note(
                                task_notes,
                                str(item.get("dataset", "unknown")),
                                (
                                    f"{saved_model.name} 运行失败: "
                                    f"{item.get('error', 'unknown')}"
                                ),
                            )

        selected_model_names = [model.name for model in models]
        if benchmark == "talent":
            generate_talent_csvs(
                results=bench_results,
                notes=bench_missing,
                output_dir=output_root,
                model_names=selected_model_names,
            )
        else:
            generate_csvs(
                benchmark=benchmark,
                results=bench_results,
                notes=bench_missing,
                output_dir=output_root,
                model_names=selected_model_names,
            )

    # 保存总体摘要
    total_elapsed = time.time() - overall_start
    overall = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "benchmarks": benchmarks,
        "task_types": task_types,
        "models": [model.to_dict() for model in models],
        "models_dir": str(Path(args.models_dir).expanduser().resolve()),
        "num_gpus": args.num_gpus,
        "talent_data_path": str(talent_data_path) if "talent" in benchmarks else None,
        "talent_seed_num": args.talent_seed_num if "talent" in benchmarks else None,
        "talent_n_estimators": args.talent_n_estimators if "talent" in benchmarks else None,
        "exaone_source_path": (
            str(Path(args.exaone_source_path).expanduser().resolve())
            if "talent" in benchmarks and args.exaone_source_path is not None
            else None
        ),
        "exaone_max_vram_bytes": (
            exaone_max_vram_bytes if "talent" in benchmarks else None
        ),
        "talent_evaluation_protocol": (
            TALENT_EVALUATION_PROTOCOL if "talent" in benchmarks else None
        ),
        "total_elapsed_seconds": total_elapsed,
        "summaries": all_summaries,
    }
    save_json(overall, output_root / "overall_summary.json")

    print(f"\n{'=' * 70}")
    print(f"  全部完成！总耗时: {total_elapsed:.1f}s")
    print(f"  结果目录: {output_root}")
    for bench in benchmarks:
        bench_dir = output_root / bench
        for csv_name in ["per_split_results.csv", "per_dataset_results.csv"]:
            csv_path = bench_dir / csv_name
            if csv_path.exists():
                print(f"    {csv_path}")
    print(f"{'=' * 70}")


if __name__ == "__main__":
    main()
