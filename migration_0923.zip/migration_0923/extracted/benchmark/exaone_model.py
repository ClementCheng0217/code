"""AutoGluon/TabArena adapter for the local EXAONE-Tabular checkpoint.

EXAONE-Tabular is an in-context tabular foundation model (no gradient training):
fit() stores the labeled rows as a support set, and predict_proba() performs a
single forward pass over (support + query).  This wrapper exposes it to TabArena
through AutoGluon's AbstractTorchModel, mirroring LocalTabFMModel.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import pandas as pd
from autogluon.common.utils.resource_utils import ResourceManager
from autogluon.tabular.models.abstract.abstract_torch_model import (
    AbstractTorchModel,
)

if TYPE_CHECKING:
    import pandas as pd


# ---------------------------------------------------------------------------
# exaonetabular 兼容性 patch
# ---------------------------------------------------------------------------
# exaonetabular 的 attention.py 只对 FLASH_ATTENTION 后端执行 batch 分块
# （FLASH_ATTENTION_BATCH_LIMIT=65535），但 seqlen<=64 时它选择
# mem_efficient 后端——mem_efficient 的 batch 上限同样是 65535，却不受分块
# 逻辑保护。大表（如 32769 行）的 feature self-attention 的
# flat_batch = ensemble × rows 可达 26 万，直接触发
# CUDA error: invalid configuration argument。
# 这里包装 F.scaled_dot_product_attention：batch 轴各样本独立，
# 超过 65535 时按行分块，结果与整体调用完全一致，对两种后端均生效。
_SDPA_PATCH_DONE = False


def _patch_exaone_sdpa() -> None:
    global _SDPA_PATCH_DONE
    if _SDPA_PATCH_DONE:
        return
    import torch
    import torch.nn.functional as F

    _orig = F.scaled_dot_product_attention

    def _chunked(q, k, v, *args, **kwargs):
        if (
            q.is_cuda
            and q.dim() == 4
            and q.shape[0] > 65_535
        ):
            parts = [
                _orig(q[s : s + 65_535], k[s : s + 65_535], v[s : s + 65_535], *args, **kwargs)
                for s in range(0, q.shape[0], 65_535)
            ]
            return torch.cat(parts, dim=0)
        return _orig(q, k, v, *args, **kwargs)

    F.scaled_dot_product_attention = _chunked
    _SDPA_PATCH_DONE = True
    print("[EXAONE] SDPA 大 batch 分块 patch 已安装 (BATCH_LIMIT=65535)")


_patch_exaone_sdpa()


class LocalEXAONETabularModel(AbstractTorchModel):
    """Expose EXAONE-Tabular's sklearn-style API to TabArena (classification + regression)."""

    ag_key = "LOCAL-EXAONE-TABULAR"
    ag_name = "Local-EXAONE-Tabular"
    ag_priority = 100
    seed_name = "random_state"

    @staticmethod
    def _to_numeric_df(df: pd.DataFrame) -> pd.DataFrame:
        """EXAONE-Tabular 要求纯数值输入。

        AutoGluon 的 preprocess 对部分数据集（如 splice 的 DNA 特征）输出
        CategoricalDtype 列，np.asarray 后成为 object 数组，fit 报
        "features must have a real numeric dtype"。这里统一转换：
        category -> codes（fit/predict 使用同一套类别映射，结果一致），
        其他非数值列 -> pd.to_numeric（无法转换的置 NaN）。
        """
        df = df.copy()
        for col in df.columns:
            if pd.api.types.is_categorical_dtype(df[col].dtype):
                df[col] = df[col].cat.codes
            elif not pd.api.types.is_numeric_dtype(df[col].dtype):
                df[col] = pd.to_numeric(df[col], errors="coerce")
        return df

    def _fit(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        num_cpus: int = 1,
        num_gpus: int = 0,
        **kwargs,
    ) -> None:
        del kwargs
        import torch
        if self.problem_type == "regression":
            from exaonetabular import EXAONETabularRegressor
        else:
            from exaonetabular import EXAONETabularClassifier

        if num_gpus and not torch.cuda.is_available():
            raise AssertionError(
                "EXAONE-Tabular 请求了 GPU，但当前 worker 看不到 CUDA 设备"
            )
        device = "cuda" if num_gpus else "cpu"
        hps = dict(self._get_model_params())
        checkpoint_path = hps.pop("checkpoint_path", None)
        if checkpoint_path is None:
            checkpoint_path = hps.pop("model_path", None)
        if checkpoint_path is None:
            raise ValueError("LocalEXAONETabularModel 需要 checkpoint_path")
        random_state = int(hps.pop(self.seed_name, 0))
        hps.pop("n_estimators", None)
        hps.pop("n_jobs", None)

        # from_pretrained(weights=...) loads the local safetensors; the released
        # checkpoint pin (SHA-256) is skipped for user-supplied weights.
        # 回归任务加载 EXAONETabularRegressor，分类任务加载 Classifier。
        if self.problem_type == "regression":
            self.model = EXAONETabularRegressor.from_pretrained(
                weights=str(checkpoint_path),
                device=device,
                seed=random_state,
            )
        else:
            self.model = EXAONETabularClassifier.from_pretrained(
                weights=str(checkpoint_path),
                device=device,
                seed=random_state,
            )
        X_processed = self.preprocess(X, y=y, is_train=True)
        X_processed = self._to_numeric_df(X_processed)
        self.model.fit(np.asarray(X_processed), np.asarray(y))

    def _predict(
        self,
        X: pd.DataFrame,
        **kwargs,
    ) -> np.ndarray:
        """回归预测：返回连续值（分类仍走 _predict_proba）。"""
        del kwargs
        X_processed = self.preprocess(X)
        X_processed = self._to_numeric_df(X_processed)
        return np.asarray(self.model.predict(np.asarray(X_processed)))

    def _predict_proba(
        self,
        X: pd.DataFrame,
        **kwargs,
    ) -> np.ndarray:
        del kwargs
        X_processed = self.preprocess(X)
        X_processed = self._to_numeric_df(X_processed)
        if self.problem_type == "regression":
            # AutoGluon 的 predict/predict_proba 统一走 _predict_proba;
            # 回归器没有 predict_proba, 直接用 predict(quantile 取中位数)。
            return np.asarray(self.model.predict(np.asarray(X_processed)))
        prediction = self.model.predict_proba(np.asarray(X_processed))
        return self._convert_proba_to_unified_form(np.asarray(prediction))

    @classmethod
    def supported_problem_types(cls) -> list[str]:
        return ["binary", "multiclass", "regression"]

    def _get_default_resources(self) -> tuple[int, int]:
        num_cpus = ResourceManager.get_cpu_count(only_physical_cores=True)
        num_gpus = min(
            1,
            ResourceManager.get_gpu_count_torch(cuda_only=True),
        )
        return num_cpus, num_gpus

    def get_minimum_resources(
        self,
        is_gpu_available: bool = False,
    ) -> dict[str, int | float]:
        return {
            "num_cpus": 1,
            "num_gpus": 1 if is_gpu_available else 0,
        }

    def get_device(self) -> str:
        if self.model is None:
            return "cpu"
        return str(self.model.device)

    def _set_device(self, device: str) -> None:
        if self.model is not None:
            self.model.device = device

    def _more_tags(self) -> dict:
        return {"can_refit_full": True}
