#!/usr/bin/env python3
"""resume_official17.py - 补跑 run_official17 中失败的 job（超时类）。

只对指定方法×任务类型构建 job 列表，并只执行 errors.json 中记录的失败 job
（dataset/fold/repeat），用更大的 time_limit 重试。成功后 merge 回原
raw_results.json（按 dataset/fold/repeat 去重），更新 errors.json / summary.json。

用法：
  python resume_official17.py --methods "ExplainableBM,NeuralNetTorch" \
      --task_type classification --num_gpus 8 --time_limit 10800
"""
from __future__ import annotations

import argparse
import hashlib
import json
import multiprocessing as mp
import os
import signal
import sys
import time
import traceback
from copy import deepcopy
from pathlib import Path

# ---- 环境（与 run_official17.py 保持一致）----
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TABPFN_CACHE_DIR", "/ssd/lamdatfm/.cache/tabpfn")
os.environ.setdefault("DATA_FOUNDRY_CACHE", "/ssd/lamdatfm/chengzj/datasets")
os.environ.setdefault(
    "OPENML_CACHE_DIR", "/ssd/lamdatfm/chengzj/datasets/openml_cache"
)
os.environ.setdefault("XDG_CONFIG_HOME", "/ssd/lamdatfm/chengzj/.config")

import tabpfn.browser_auth as ba  # noqa: E402

ba.ensure_license_accepted = lambda hf_repo_id: True

_THIS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(_THIS_DIR))
sys.path.insert(0, str(_THIS_DIR / "tabarena/packages/tabarena/src"))

from run_all_benchmarks import (  # noqa: E402
    RUNNER_SCHEMA_VERSION,
    _worker_run_jobs,
    build_context,
    filter_jobs_by_data_availability,
    load_json,
    save_json,
)
from run_official17 import (  # noqa: E402
    METHODS,
    _BENCHMARK,
    DATA_DIR,
)

_CLS = "classification"
_TASK_SHORT = {_CLS: "cla", "regression": "reg"}


def _job_key(job) -> tuple:
    return (job.task.dataset, job.task.fold, job.task.repeat)


def run_resume(
    method_name: str,
    task_type: str,
    num_gpus: int,
    output_dir: Path,
    time_limit: int = 10800,
) -> dict | None:
    """补跑单个方法×任务的失败 job，结果 merge 回原目录。"""
    from tabarena.benchmark.experiment import TabArenaV0pt1ExperimentBundle
    from tabarena.models._registry import get_model_registry

    registry_key, task_types, manual_config_fn = METHODS[method_name]
    manual_config = manual_config_fn(task_type) if manual_config_fn else None
    model_tag = f"{method_name}_{task_type[:3]}"
    out_dir = output_dir / _BENCHMARK / model_tag

    print(f"\n{'=' * 70}")
    print(f"  RESUME {model_tag.upper()} | time_limit={time_limit}s")
    print(f"{'=' * 70}")

    old_summary = load_json(out_dir / "summary.json")
    old_errors = load_json(out_dir / "errors.json")
    old_raw = load_json(out_dir / "raw_results.json")
    old_failed = old_errors.get("failed", [])
    if not old_failed:
        print(f"  {model_tag}: errors.json 无失败 job，跳过")
        return None
    failed_keys = {(_f["dataset"], _f["fold"], _f["repeat"]) for _f in old_failed}
    print(f"  待补跑 job: {len(failed_keys)} 个")
    for k in sorted(failed_keys):
        print(f"    {k[0]} fold={k[1]} repeat={k[2]}")

    # Step 1: 构建 context + experiments（与 run_method 相同）
    print("[1/4] 构建 context 和实验...")
    context = build_context(_BENCHMARK, DATA_DIR)
    reg = get_model_registry()
    if registry_key not in reg:
        raise ValueError(f"registry 中找不到方法 {registry_key}")
    info = reg[registry_key]
    config_gen = deepcopy(info.search_space)
    config_gen.manual_configs = [manual_config] if manual_config is not None else [{}]
    bundle = TabArenaV0pt1ExperimentBundle(
        models=[(config_gen, 0)],
        outer_experiments=True,
    )
    experiments = bundle.build_experiments(time_limit=time_limit)

    # Step 2: 构建 jobs + 数据可用性过滤 + 失败过滤
    print("[2/4] 构建 job 列表...")
    jobs = context.build_jobs(experiments, subset=task_type)
    jobs, missing_notes = filter_jobs_by_data_availability(_BENCHMARK, jobs)
    total_jobs = len(jobs)
    total_datasets = len(set(j.task.dataset for j in jobs))
    jobs = [j for j in jobs if _job_key(j) in failed_keys]
    print(f"  全量 {total_jobs} 个 job，过滤后待补跑 {len(jobs)} 个")
    if not jobs:
        print("  无待补跑 job，跳过")
        return None

    # Step 3: 预加载数据
    print("[3/4] 预加载数据到本地缓存...")
    t0 = time.time()
    context.task_metadata_collection.subset_to_jobs(jobs).materialize()
    print(f"  数据就绪，耗时 {time.time() - t0:.1f}s")

    # Step 4: GPU 分布式执行
    print(f"[4/4] 启动 {num_gpus} 个 GPU worker 并行执行...")
    job_dicts = [j.to_dict() for j in jobs]
    gpu_job_dicts: list[list[dict]] = [[] for _ in range(num_gpus)]
    for i, jd in enumerate(job_dicts):
        gpu_job_dicts[i % num_gpus].append(jd)
    for gid, jds in enumerate(gpu_job_dicts):
        if jds:
            datasets_in_gpu = set(jd["dataset"] for jd in jds)
            print(f"    GPU {gid}: {len(jds)} jobs, {len(datasets_in_gpu)} 个数据集")

    mp.set_start_method("spawn", force=True)
    result_queue: mp.Queue = mp.Queue()
    processes = []

    original_visible_devices = os.environ.get("CUDA_VISIBLE_DEVICES")
    visible_device_pool = (
        [item.strip() for item in original_visible_devices.split(",") if item.strip()]
        if original_visible_devices
        else [str(index) for index in range(num_gpus)]
    )
    if len(visible_device_pool) < num_gpus:
        raise ValueError(
            f"--num_gpus={num_gpus}，但 CUDA_VISIBLE_DEVICES 仅包含 {visible_device_pool}"
        )
    run_cache_key = hashlib.sha256(
        json.dumps(
            {
                "benchmark": _BENCHMARK,
                "task_type": task_type,
                "model_name": method_name,
                "time_limit": time_limit,
                "resume": True,
            },
            ensure_ascii=True,
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()[:16]
    worker_out = str(out_dir / "_runs" / run_cache_key)

    try:
        for gpu_id in range(num_gpus):
            if not gpu_job_dicts[gpu_id]:
                continue
            os.environ["CUDA_VISIBLE_DEVICES"] = visible_device_pool[gpu_id]
            p = mp.Process(
                target=_worker_run_jobs,
                args=(
                    gpu_id,
                    gpu_job_dicts[gpu_id],
                    DATA_DIR,
                    worker_out,
                    _BENCHMARK,
                    "none",
                    result_queue,
                    time_limit,
                ),
            )
            p.start()
            processes.append(p)
    finally:
        if original_visible_devices is None:
            os.environ.pop("CUDA_VISIBLE_DEVICES", None)
        else:
            os.environ["CUDA_VISIBLE_DEVICES"] = original_visible_devices

    import queue

    all_results: list[dict] = []
    all_failed: list[dict] = []
    max_jobs_per_worker = max((len(g) for g in gpu_job_dicts), default=0)
    total_timeout = max(28_800, (time_limit + 60) * max_jobs_per_worker)
    deadline = time.time() + total_timeout
    completed = 0
    while completed < len(processes):
        remaining = deadline - time.time()
        if remaining <= 0:
            print(f"  总超时({total_timeout}s)，已收集 {completed}/{len(processes)}，跳过剩余")
            break
        try:
            wr = result_queue.get(timeout=min(remaining, 30))
            all_results.extend(wr.get("results", []))
            all_failed.extend(wr.get("failed", []))
            completed += 1
        except queue.Empty:
            alive_count = sum(1 for p in processes if p.is_alive())
            if alive_count == 0:
                print(f"  所有 Worker 已退出（崩溃），已收集 {completed}/{len(processes)}")
                while True:
                    try:
                        wr = result_queue.get_nowait()
                        all_results.extend(wr.get("results", []))
                        all_failed.extend(wr.get("failed", []))
                        completed += 1
                    except queue.Empty:
                        break
                break
            continue
    print(f"  共收集 {completed}/{len(processes)} 个 Worker 结果")

    for p in processes:
        p.join(timeout=30)
        if p.is_alive():
            p.terminate()
            p.join(timeout=5)

    t_total = time.time() - t0
    print(f"  补跑完成: 新成功 {len(all_results)}, 仍失败 {len(all_failed)}, 耗时 {t_total:.1f}s")

    # Step 5: merge 回原结果
    merged: dict[tuple, dict] = {}
    for r in old_raw:
        tm = r.get("task_metadata", {})
        key = (tm.get("name"), tm.get("fold"), tm.get("repeat"))
        if key[0] is not None:
            merged[key] = r
    for r in all_results:
        tm = r.get("task_metadata", {})
        key = (tm.get("name"), tm.get("fold"), tm.get("repeat"))
        if key[0] is not None:
            merged[key] = r
    merged_list = list(merged.values())
    print(f"  merge 后 raw_results.json: {len(old_raw)} → {len(merged_list)}")

    save_json(merged_list, out_dir / "raw_results.json")
    save_json(
        {"failed": all_failed, "missing_datasets": missing_notes},
        out_dir / "errors.json",
    )
    summary = {
        "benchmark": _BENCHMARK,
        "model_type": method_name,
        "task_type": task_type,
        "registry_key": registry_key,
        "manual_config": manual_config,
        "num_gpus": num_gpus,
        "time_limit": time_limit,
        "num_jobs": total_jobs,
        "num_datasets": total_datasets,
        "num_success": len(merged_list),
        "num_failed": len(all_failed),
        "elapsed_seconds": t_total,
        "missing_datasets": missing_notes,
        "resume": True,
        "resume_of_elapsed": old_summary.get("elapsed_seconds"),
    }
    save_json(summary, out_dir / "summary.json")
    print(f"  ✓ {model_tag} 最终: {len(merged_list)}/{total_jobs} jobs, fail={len(all_failed)}")
    return summary


def main() -> None:
    p = argparse.ArgumentParser(description="补跑 TabArena 失败的 job")
    p.add_argument("--methods", type=str, required=True,
                   help="逗号分隔的方法名，如 ExplainableBM,NeuralNetTorch")
    p.add_argument("--task_type", type=str, default="classification",
                   choices=[_CLS, "regression"])
    p.add_argument("--num_gpus", type=int, default=8)
    p.add_argument("--time_limit", type=int, default=10800,
                   help="每个 job 的 fit 时间限制（秒）")
    p.add_argument("--output_dir", type=str, default="benchmark_results")
    args = p.parse_args()

    output_dir = Path(args.output_dir)
    selected = [m.strip() for m in args.methods.split(",") if m.strip()]
    unknown = [m for m in selected if m not in METHODS]
    if unknown:
        raise SystemExit(f"未知方法: {unknown}")

    for name in selected:
        try:
            run_resume(
                name, args.task_type,
                num_gpus=args.num_gpus,
                output_dir=output_dir,
                time_limit=args.time_limit,
            )
        except Exception as e:
            print(f"\n[ERROR] {name} × {args.task_type} 补跑失败: {e}")
            traceback.print_exc()


if __name__ == "__main__":
    main()
