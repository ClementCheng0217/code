#!/bin/bash
# 1) 复制 exaonetabular 包到 lamdatfm 可写的 pylib 目录
# 2) patch 副本的 load_regressor_checkpoint: 忽略官方权重多余的 head_scale key
# 3) 验证 PYTHONPATH 优先加载 + 权重加载 + 回归预测
set -e
SRC=/ssd/lamdatfm/chengzj/miniconda3/envs/arena/lib/python3.12/site-packages/exaonetabular
DST=/ssd/lamdatfm/chengzj/pylib/exaonetabular

mkdir -p /ssd/lamdatfm/chengzj/pylib
if [ ! -d "$DST" ]; then
  cp -r "$SRC" "$DST"
  echo "copied -> $DST"
else
  echo "already exists: $DST"
fi

CP=$DST/checkpoint.py
/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python - "$CP" <<'EOF'
import sys
p = sys.argv[1]
src = open(p, encoding="utf-8").read()

old_check = """    targets = model.state_dict()
    if any(not isinstance(k, str) or not isinstance(v, torch.Tensor) for k, v in checkpoint.items()):
        raise TypeError("checkpoint must map string keys to tensors")
    if set(checkpoint) != set(targets):
        raise ValueError("checkpoint state keys do not match the model")"""

new_check = """    targets = model.state_dict()
    if any(not isinstance(k, str) or not isinstance(v, torch.Tensor) for k, v in checkpoint.items()):
        raise TypeError("checkpoint must map string keys to tensors")
    missing = set(targets) - set(checkpoint)
    if missing:
        raise ValueError("checkpoint state keys do not match the model")
    # 官方回归权重含 72 个 head_scale 参数(值全部等于 fixed_head_scale=0.43),
    # 本模型以常量使用该值、不保存参数: 忽略 checkpoint 中多余的 key。
    extra = sorted(set(checkpoint) - set(targets))
    if extra:
        _logger.warning("ignoring %d extra checkpoint keys: %s", len(extra), extra[:3])"""

old_loop = """    backups = {key: value.detach().clone() for key, value in targets.items()}
    try:
        with torch.no_grad():
            for key, value in checkpoint.items():
                targets[key].copy_(value)"""

new_loop = """    backups = {key: value.detach().clone() for key, value in targets.items()}
    try:
        with torch.no_grad():
            for key in targets:
                targets[key].copy_(checkpoint[key])"""

assert old_check in src, "old_check pattern not found"
assert old_loop in src, "old_loop pattern not found"
src = src.replace(old_check, new_check).replace(old_loop, new_loop)
open(p, "w", encoding="utf-8").write(src)
print("PATCH OK")
EOF

echo "===== 验证: PYTHONPATH 优先加载 + 权重加载 + 预测 ====="
cd /ssd/lamdatfm/chengzj/benchmark
PYTHONPATH=/ssd/lamdatfm/chengzj/pylib /ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python - <<'EOF'
import exaonetabular, os
print("loaded from:", os.path.dirname(exaonetabular.__file__))

import numpy as np
from exaonetabular import EXAONETabularRegressor

CKPT = "/ssd/lamdatfm/chengzj/models/exaone-tabular-regressor-v1_default.safetensors"
m = EXAONETabularRegressor.from_pretrained(weights=CKPT, device="cpu", seed=0)
print("LOAD OK, is_fitted =", m.is_fitted)

rng = np.random.default_rng(0)
Xtr = rng.normal(size=(200, 5)).astype(np.float32)
ytr = (Xtr[:, 0] * 2 + Xtr[:, 1] - Xtr[:, 2]).astype(np.float32)
Xte = rng.normal(size=(10, 5)).astype(np.float32)
m.fit(Xtr, ytr)
p = m.predict(Xte)
print("predict OK, shape:", p.shape, "sample:", np.round(p[:5], 4))
assert np.isfinite(p).all()
print("ALL GOOD")
EOF
