#!/bin/bash
# 检查 regressor 权重中 head_scale 的实际值
/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python - <<'EOF'
import safetensors.torch as st
p = "/ssd/lamdatfm/chengzj/models/exaone-tabular-regressor-v1_default.safetensors"
sd = st.load_file(p)
hs = {k: v for k, v in sd.items() if k.endswith("head_scale")}
print("head_scale keys:", len(hs))
vals = []
for k, v in hs.items():
    vals.extend(v.tolist())
import statistics
print("min:", min(vals), "max:", max(vals), "mean:", statistics.mean(vals))
print("unique values:", sorted(set(round(x, 4) for x in vals))[:20])
# 与固定值 0.43 的对比
diff = [v for v in vals if abs(v - 0.43) > 1e-6]
print("不等于 0.43 的数量:", len(diff), "样例:", diff[:10])
EOF
