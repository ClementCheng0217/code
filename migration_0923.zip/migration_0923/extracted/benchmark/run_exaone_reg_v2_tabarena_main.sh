#!/bin/bash
# EXAONE-Tabular regressor v1 + exaonetabular main 版回归评测 (TabArena)
# 目的: 用官方 main(2026-09-09 拷入)的回归机制重跑 TabArena 回归
#   main 版默认 RegressionConfig: n_svd=16, svd_split=True(双 pass 16 成员),
#   member_weighting=nnls(support>=10000 生效), point_estimate=trimmed
# 权重: 官方 release v1 regressor safetensors(main 版直接兼容加载, 已 smoke 验证)
# 全新 output_dir -> 强制全量重跑, 不命中旧 raw_results.json 缓存
export TMPDIR=/ssd/lamdatfm/chengzj/tmp
mkdir -p $TMPDIR
cd /ssd/lamdatfm/chengzj/benchmark
PY=/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python
LOG=/tmp/exaone_reg_v2_tabarena_main.log
rm -f $LOG
setsid nohup env PYTHONPATH=/ssd/lamdatfm/chengzj/models/EXAONE-Tabular-main/src \
  CUDA_VISIBLE_DEVICES=3 $PY -u run_all_benchmarks.py \
  --direct_ckpt /ssd/lamdatfm/chengzj/models/exaone-tabular-regressor-v1_default.safetensors \
  --direct_adapter exaone_tabular --model_name exaone-tabular-v1 \
  --benchmarks tabarena --reg_only --num_gpus 1 --time_limit 14400 \
  --output_dir benchmark_results/exaone_reg_v2_tabarena_main > $LOG 2>&1 &
echo "STARTED PID $!  LOG=$LOG"
sleep 25
echo "===== 日志开头 ====="
head -50 $LOG
