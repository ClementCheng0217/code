#!/bin/bash
# 查看 4 个 reg 模型 + 260814 的 beyondarena 目录结构,找 CSV 实际位置
BASE=/ssd/lamdatfm/chengzj/benchmark/benchmark_results
for d in \
  beyondarena_reg_s1_260808_float32 \
  beyondarena_reg_s1_260813_muon \
  beyondarena_reg_s2_260815_float32 \
  beyondarena_reg_s3_260820_float32 \
  beyondarena_260814_s3amp ; do
  echo "=== $d ==="
  ls -la $BASE/$d/beyondarena/ 2>/dev/null | head -20
  echo "--- model 子目录内容 ---"
  ls $BASE/$d/beyondarena/*/ 2>/dev/null | head -20
  echo
done
