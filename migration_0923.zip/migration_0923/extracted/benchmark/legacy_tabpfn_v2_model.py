"""AutoGluon adapter for pre-conversion TabPFN v2 checkpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from autogluon.common.utils.resource_utils import ResourceManager
from autogluon.features.generators import LabelEncoderFeatureGenerator
from autogluon.tabular.models.abstract.abstract_torch_model import (
    AbstractTorchModel,
)

if TYPE_CHECKING:
    import pandas as pd


class LocalLegacyTabPFNV2Model(AbstractTorchModel):
    """Use TALENT's vendored v2 runtime for early attention-key layouts."""

    ag_key = "LOCAL-TABPFN-V2-LEGACY"
    ag_name = "Local-TabPFN-v2-Legacy"
    ag_priority = 100
    seed_name = "random_state"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._feature_generator = None
        self._cat_indices: list[int] = []

    def _preprocess(
        self,
        X: pd.DataFrame,
        *,
        is_train: bool = False,
        **kwargs,
    ) -> pd.DataFrame:
        X = super()._preprocess(X, **kwargs)
        if is_train:
            self._feature_generator = LabelEncoderFeatureGenerator(verbosity=0)
            self._feature_generator.fit(X=X)
        if self._feature_generator.features_in:
            X = X.copy()
            X[self._feature_generator.features_in] = (
                self._feature_generator.transform(X=X)
            )
            if is_train:
                self._cat_indices = [
                    X.columns.get_loc(column)
                    for column in self._feature_generator.features_in
                ]
        return X

    def _fit(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        num_cpus: int = 1,
        num_gpus: int = 0,
        **kwargs,
    ) -> None:
        del kwargs
        import torch
        from TALENT.model.models.tabpfn_v2 import (
            TabPFNClassifier,
            TabPFNRegressor,
        )

        if num_gpus and not torch.cuda.is_available():
            raise AssertionError(
                "Legacy TabPFN v2 请求了 GPU，但 worker 看不到 CUDA"
            )
        hps = dict(self._get_model_params())
        checkpoint_path = hps.pop("checkpoint_path", None)
        if checkpoint_path is None:
            checkpoint_path = hps.pop("model_path", None)
        if checkpoint_path is None:
            raise ValueError(
                "LocalLegacyTabPFNV2Model 需要 checkpoint_path"
            )
        sample_size = int(hps.pop("sample_size", 10_000))
        hps.setdefault("n_estimators", 8)
        hps.setdefault("ignore_pretraining_limits", True)
        hps.setdefault(self.seed_name, 0)
        hps["model_path"] = checkpoint_path
        hps["device"] = "cuda" if num_gpus else "cpu"
        hps["n_jobs"] = num_cpus
        X_processed = self.preprocess(X, y=y, is_train=True)
        hps["categorical_features_indices"] = self._cat_indices

        is_classification = self.problem_type in {"binary", "multiclass"}
        estimator_cls = (
            TabPFNClassifier
            if is_classification
            else TabPFNRegressor
        )
        self.model = estimator_cls(**hps)
        self.model.fit(X_processed, np.asarray(y), sample_size)

    def _predict_proba(
        self,
        X: pd.DataFrame,
        **kwargs,
    ) -> np.ndarray:
        del kwargs
        X_processed = self.preprocess(X)
        if self.problem_type in {"binary", "multiclass"}:
            prediction = self.model.predict_proba(X_processed)
        else:
            prediction = self.model.predict(X_processed)
        return self._convert_proba_to_unified_form(np.asarray(prediction))

    @classmethod
    def supported_problem_types(cls) -> list[str]:
        return ["binary", "multiclass", "regression"]

    def _get_default_resources(self) -> tuple[int, int]:
        return (
            ResourceManager.get_cpu_count(only_physical_cores=True),
            min(
                1,
                ResourceManager.get_gpu_count_torch(cuda_only=True),
            ),
        )

    def get_minimum_resources(
        self,
        is_gpu_available: bool = False,
    ) -> dict[str, int | float]:
        return {
            "num_cpus": 1,
            "num_gpus": 1 if is_gpu_available else 0,
        }

    def get_device(self) -> str:
        return str(getattr(self.model, "device_", "cpu"))

    def _more_tags(self) -> dict:
        return {"can_refit_full": True}
