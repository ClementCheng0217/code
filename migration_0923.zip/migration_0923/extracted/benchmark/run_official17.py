#!/usr/bin/env python3
"""
run_official17.py - 在 TabArena 上用官方注册表方式直接运行 17 个可直接运行的方法。

与 run_all_benchmarks.py 的区别：
- 不走本地模型目录扫描（benchmark_model_registry），而是直接使用 tabarena 官方
  get_model_registry() 的 ModelInfo.search_space（官方默认超参 manual_configs=[{}]）。
- 预训练模型通过 per-model manual config 注入本地 checkpoint。
- 复用 run_all_benchmarks.py 的 context 构建 / 数据过滤 / GPU worker 分发 / 断点恢复。

用法示例：
  python run_official17.py --num_gpus 8 --time_limit 3600
  python run_official17.py --methods "LightGBM,RealMLP_GPU" --num_gpus 4
  python run_official17.py --debug --debug_datasets 2 --debug_splits_per_dataset 1
"""

from __future__ import annotations

import argparse
import hashlib
import json
import multiprocessing as mp
import os
import signal
import time
import traceback
from collections import defaultdict
from copy import deepcopy
from pathlib import Path
from typing import Any, Callable

# ============================================================================
#  环境设置（与 run_all_benchmarks.py 保持一致）
# ============================================================================
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TABPFN_CACHE_DIR", "/ssd/lamdatfm/.cache/tabpfn")
os.environ.setdefault("DATA_FOUNDRY_CACHE", "/ssd/lamdatfm/chengzj/datasets")
os.environ.setdefault(
    "OPENML_CACHE_DIR",
    "/ssd/lamdatfm/chengzj/datasets/openml_cache",
)
os.environ.setdefault(
    "XDG_CONFIG_HOME",
    "/ssd/lamdatfm/chengzj/.config",
)

import tabpfn.browser_auth as ba  # noqa: E402

ba.ensure_license_accepted = lambda hf_repo_id: True

# ============================================================================
#  复用 run_all_benchmarks.py 的公共设施
# ============================================================================
_THIS_DIR = Path(__file__).resolve().parent
import sys  # noqa: E402

sys.path.insert(0, str(_THIS_DIR))
sys.path.insert(0, str(_THIS_DIR / "tabarena/packages/tabarena/src"))

from run_all_benchmarks import (  # noqa: E402
    DATA_DIR,
    RUNNER_SCHEMA_VERSION,
    build_context,
    filter_jobs_by_data_availability,
    load_json,
    save_json,
    _worker_run_jobs,
)

# ============================================================================
#  CPU 核数限制（关键修复）
#  机器 112 核，autogluon 的 LGBModel 默认 num_cpus=0 → lightgbm num_threads=0
#  → OpenMP 使用全部核。小数据集 + 过多线程时 lightgbm 每轮迭代慢到 4s+
#  （诊断：1500 行数据 120s 仅 27 轮；设置 OMP_NUM_THREADS=14 后 1.4s 完成）。
#  这里统一把 worker 线程数限制为每 worker 14：
#   1) OMP/MKL 环境变量（lightgbm/EBM 等 OpenMP 库）
#   2) ResourceManager.get_cpu_count → 14（RF/NN 等 autogluon 资源分配）
#  8 × 14 = 112 恰好不超卖。spawn worker 继承环境变量 + 重新 import 本模块。
# ============================================================================
_WORKER_CPU_COUNT = int(os.environ.get("OFFICIAL17_WORKER_CPU", "14"))
os.environ["OMP_NUM_THREADS"] = str(_WORKER_CPU_COUNT)
os.environ["OMP_DYNAMIC"] = "FALSE"
os.environ["MKL_NUM_THREADS"] = str(_WORKER_CPU_COUNT)

try:
    from autogluon.common.utils.resource_utils import ResourceManager

    def _bounded_cpu_count(*args, **kwargs) -> int:
        return _WORKER_CPU_COUNT

    ResourceManager.get_cpu_count = staticmethod(_bounded_cpu_count)
    _CPU_PATCH_APPLIED = True
except Exception as _e:  # pragma: no cover
    _CPU_PATCH_APPLIED = False

# LGBModel._fit 默认 num_cpus=0 → lightgbm num_threads=0 → OpenMP 用全部核
# （实测 OMP_NUM_THREADS 环境变量对该路径无效）。直接强制 num_cpus=14。
try:
    from autogluon.tabular.models.lgb.lgb_model import LGBModel

    _orig_lgb_fit = LGBModel._fit

    def _patched_lgb_fit(
        self,
        X,
        y,
        X_val=None,
        y_val=None,
        time_limit=None,
        num_gpus=0,
        num_cpus=0,
        sample_weight=None,
        sample_weight_val=None,
        verbosity=2,
        **kwargs,
    ):
        return _orig_lgb_fit(
            self,
            X,
            y,
            X_val,
            y_val,
            time_limit,
            num_gpus,
            _WORKER_CPU_COUNT,
            sample_weight,
            sample_weight_val,
            verbosity,
            **kwargs,
        )

    LGBModel._fit = _patched_lgb_fit
    _LGB_PATCH_APPLIED = True
except Exception as _e:  # pragma: no cover
    _LGB_PATCH_APPLIED = False

# ============================================================================
#  17 个可直接运行的方法定义
# ============================================================================
MODELS_DIR = Path("/ssd/lamdatfm/chengzj/models")

_CLS = "classification"
_REG = "regression"


def _tabicl_ckpt(tt: str, version: str) -> dict:
    role = "classifier" if tt == _CLS else "regressor"
    return {
        "checkpoint_version": f"tabicl-{role}-{version}.ckpt",
        "model_path": str(MODELS_DIR / f"tabicl/tabicl-{role}-{version}.ckpt"),
    }


def _tabpfn_per_problem(tt: str, name: str) -> dict:
    role = "classifier" if tt == _CLS else "regressor"
    return {
        "checkpoint_per_problem_type": {
            tt: str(MODELS_DIR / f"tabpfn/{name}-{role}-{name.split('-')[-1]}_default.ckpt"),
        },
    }


# method 名 -> (registry key, task_types, manual_config_fn(task_type) | None)
METHODS: dict[str, tuple[str, tuple[str, ...], Callable[[str], dict] | None]] = {
    # ---------- 训练型：官方默认超参（gen_xxx manual_configs=[{}]） ----------
    "LinearModel": ("LinearModel", (_CLS, _REG), None),
    "RandomForest": ("RandomForest", (_CLS, _REG), None),
    "ExtraTrees": ("ExtraTrees", (_CLS, _REG), None),
    "LightGBM": ("LightGBM", (_CLS, _REG), None),
    "KNeighbors": ("KNeighbors", (_CLS, _REG), None),
    "ExplainableBM": ("ExplainableBM", (_CLS, _REG), None),
    "NeuralNetTorch": ("NeuralNetTorch", (_CLS, _REG), None),
    "ModernNCA": ("ModernNCA", (_CLS, _REG), None),
    "ModernNCA_GPU": ("ModernNCA_GPU", (_CLS, _REG), None),
    "RealMLP": ("RealMLP", (_CLS, _REG), None),
    "RealMLP_GPU": ("RealMLP_GPU", (_CLS, _REG), None),
    # ---------- 预训练型：注入本地 checkpoint ----------
    # LimiX-16M（本地权重）
    "LimiX": (
        "LimiX",
        (_CLS, _REG),
        lambda tt: {"model_path": str(MODELS_DIR / "limix/LimiX-16M/LimiX-16M.ckpt")},
    ),
    # RealTabPFN-v2.5：zip_model_path 传绝对路径（model_dir / 绝对路径 = 绝对路径），
    # 否则默认相对名会落到空的 TABPFN_CACHE_DIR；custom_model_dir 是类属性无法经
    # hyperparameter 注入。
    "RealTabPFN-v2.5": (
        "RealTabPFN-v2.5",
        (_CLS, _REG),
        lambda tt: {
            "zip_model_path": [
                str(MODELS_DIR / "tabpfn/tabpfn-v2.5/tabpfn-v2.5-classifier-v2.5_default.ckpt"),
                str(MODELS_DIR / "tabpfn/tabpfn-v2.5/tabpfn-v2.5-regressor-v2.5_default.ckpt"),
            ],
        },
    ),
    # TabICL v1：官方仅分类权重
    "TabICL_GPU": (
        "TabICL_GPU",
        (_CLS,),
        lambda tt: _tabicl_ckpt(tt, "v1-20250208"),
    ),
    # TabICL v2：分类 + 回归
    "TabICLv2": (
        "TabICLv2",
        (_CLS, _REG),
        lambda tt: _tabicl_ckpt(tt, "v2-20260212"),
    ),
    # TabPFN-3：checkpoint_per_problem_type
    "TabPFN-3": (
        "TabPFN-3",
        (_CLS, _REG),
        lambda tt: _tabpfn_per_problem(tt, "tabpfn-v3"),
    ),
    # TabPFN-v2.6：同样用 zip_model_path 绝对路径注入（不支持 checkpoint_per_problem_type；
    # custom_model_dir 是类属性无法经 hyperparameter 注入）
    "TabPFN-v2.6": (
        "TabPFN-v2.6",
        (_CLS, _REG),
        lambda tt: {
            "zip_model_path": [
                str(MODELS_DIR / "tabpfn/tabpfn-v2.6-classifier-v2.6_default.ckpt"),
                str(MODELS_DIR / "tabpfn/tabpfn-v2.6-regressor-v2.6_default.ckpt"),
            ],
        },
    ),
}

_BENCHMARK = "tabarena"


# ============================================================================
#  单方法 × 任务类型运行
# ============================================================================

class _JobTimeoutError(Exception):
    pass


def _job_timeout_handler(signum, frame):
    raise _JobTimeoutError("Job execution timed out")


def run_method(
    method_name: str,
    task_type: str,
    num_gpus: int,
    output_dir: Path,
    time_limit: int = 3600,
    debug: bool = False,
    debug_datasets: int = 2,
    debug_splits_per_dataset: int = 1,
) -> dict:
    """运行单个官方方法 × TabArena × 任务类型，返回结果摘要。"""
    from tabarena.models._registry import get_model_registry
    from tabarena.benchmark.experiment import TabArenaV0pt1ExperimentBundle

    registry_key, task_types, manual_config_fn = METHODS[method_name]
    manual_config = manual_config_fn(task_type) if manual_config_fn else None

    model_tag = f"{method_name}_{task_type[:3]}"
    run_name = f"{_BENCHMARK}_{model_tag}"
    print(f"\n{'=' * 70}")
    print(f"  {run_name.upper()}")
    print(f"  Method: {method_name} | Registry: {registry_key} | Task: {task_type}")
    print(f"  Manual config: {manual_config}")
    print(f"  GPUs: {num_gpus} | Time limit/job: {time_limit}s")
    print(
        f"  CPU patch: {'ON (每 worker ' + str(_WORKER_CPU_COUNT) + ' 核)' if _CPU_PATCH_APPLIED else 'OFF'} "
        f"| LGB patch: {'ON' if _LGB_PATCH_APPLIED else 'OFF'}"
    )
    print(f"{'=' * 70}")

    out_dir = output_dir / _BENCHMARK / model_tag
    out_dir.mkdir(parents=True, exist_ok=True)

    run_config = {
        "runner_schema_version": RUNNER_SCHEMA_VERSION,
        "benchmark": _BENCHMARK,
        "task_type": task_type,
        "model_name": method_name,
        "registry_key": registry_key,
        "manual_config": manual_config,
        "time_limit": time_limit,
        "debug": debug,
        "debug_datasets": debug_datasets if debug else None,
        "debug_splits_per_dataset": (
            debug_splits_per_dataset if debug else None
        ),
        "data_dir": DATA_DIR,
    }
    run_cache_key = hashlib.sha256(
        json.dumps(run_config, ensure_ascii=True, sort_keys=True).encode("utf-8")
    ).hexdigest()[:16]

    # 断点恢复：raw_results.json + summary.json 均存在且配置匹配则跳过
    raw_results_path = out_dir / "raw_results.json"
    summary_path = out_dir / "summary.json"
    if raw_results_path.exists() and summary_path.exists():
        cached_summary = load_json(summary_path)
        if (
            cached_summary.get("run_config") == run_config
            and cached_summary.get("num_failed", 0) == 0
            and cached_summary.get("num_success") == cached_summary.get("num_jobs")
        ):
            print(f"  ✓ 已有匹配结果 {raw_results_path}，跳过运行")
            return cached_summary
        print("  ↻ 已有结果配置与本次不同，将重新运行")

    # Step 1: 构建 context + config generator + experiments
    print("[1/5] 构建 context 和实验...")
    context = build_context(_BENCHMARK, DATA_DIR)

    reg = get_model_registry()
    if registry_key not in reg:
        raise ValueError(f"registry 中找不到方法 {registry_key}")
    info = reg[registry_key]
    config_gen = deepcopy(info.search_space)
    if manual_config is not None:
        config_gen.manual_configs = [manual_config]
    else:
        config_gen.manual_configs = [{}]

    bundle = TabArenaV0pt1ExperimentBundle(
        models=[(config_gen, 0)],
        outer_experiments=True,
    )
    experiments = bundle.build_experiments(time_limit=time_limit)

    # Step 2: 构建 jobs + 数据可用性过滤
    print("[2/5] 构建 job 列表...")
    jobs = context.build_jobs(experiments, subset=task_type)
    jobs, missing_notes = filter_jobs_by_data_availability(_BENCHMARK, jobs)

    # Debug 限制
    if debug:
        unique_datasets = list(dict.fromkeys(j.task.dataset for j in jobs))
        debug_datasets_set = set(unique_datasets[:debug_datasets])
        jobs = [j for j in jobs if j.task.dataset in debug_datasets_set]
        if debug_splits_per_dataset > 0:
            split_counts: dict[str, int] = defaultdict(int)
            limited_jobs = []
            for job in jobs:
                dataset = job.task.dataset
                if split_counts[dataset] >= debug_splits_per_dataset:
                    continue
                limited_jobs.append(job)
                split_counts[dataset] += 1
            jobs = limited_jobs
        print(
            f"  [DEBUG] 限制到 {len(debug_datasets_set)} 个数据集、"
            f"每数据集 {debug_splits_per_dataset or '全部'} 个 split: "
            f"{debug_datasets_set}"
        )

    n_datasets = len(set(j.task.dataset for j in jobs))
    print(f"  → {len(jobs)} 个 job ({n_datasets} 个数据集)")

    if not jobs:
        print("  没有有效 job，跳过")
        return {
            "benchmark": _BENCHMARK, "model_type": method_name, "task_type": task_type,
            "registry_key": registry_key,
            "num_jobs": 0, "num_datasets": 0, "error": "No valid jobs",
            "missing_datasets": missing_notes,
        }

    # Step 3: 预加载数据
    print("[3/5] 预加载数据到本地缓存...")
    t0 = time.time()
    context.task_metadata_collection.subset_to_jobs(jobs).materialize()
    print(f"  数据就绪，耗时 {time.time() - t0:.1f}s")

    # Step 4: GPU 分布式执行
    print(f"[4/5] 启动 {num_gpus} 个 GPU worker 并行执行...")
    job_dicts = [j.to_dict() for j in jobs]
    gpu_job_dicts: list[list[dict]] = [[] for _ in range(num_gpus)]
    for i, jd in enumerate(job_dicts):
        gpu_job_dicts[i % num_gpus].append(jd)

    print("  → GPU job 分配:")
    for gid, jds in enumerate(gpu_job_dicts):
        if jds:
            datasets_in_gpu = set(jd["dataset"] for jd in jds)
            print(f"    GPU {gid}: {len(jds)} jobs, {len(datasets_in_gpu)} 个数据集")

    mp.set_start_method("spawn", force=True)
    result_queue: mp.Queue = mp.Queue()
    processes = []

    original_visible_devices = os.environ.get("CUDA_VISIBLE_DEVICES")
    visible_device_pool = (
        [
            item.strip()
            for item in original_visible_devices.split(",")
            if item.strip()
        ]
        if original_visible_devices
        else [str(index) for index in range(num_gpus)]
    )
    if len(visible_device_pool) < num_gpus:
        raise ValueError(
            f"--num_gpus={num_gpus}，但 CUDA_VISIBLE_DEVICES 仅包含 "
            f"{visible_device_pool}"
        )
    arena_adapter_for_worker = "limix" if method_name == "LimiX" else "none"
    try:
        for gpu_id in range(num_gpus):
            if not gpu_job_dicts[gpu_id]:
                continue
            os.environ["CUDA_VISIBLE_DEVICES"] = visible_device_pool[gpu_id]
            p = mp.Process(
                target=_worker_run_jobs,
                args=(
                    gpu_id,
                    gpu_job_dicts[gpu_id],
                    DATA_DIR,
                    str(out_dir / "_runs" / run_cache_key),
                    _BENCHMARK,
                    arena_adapter_for_worker,
                    result_queue,
                    time_limit,
                ),
            )
            p.start()
            processes.append(p)
    finally:
        if original_visible_devices is None:
            os.environ.pop("CUDA_VISIBLE_DEVICES", None)
        else:
            os.environ["CUDA_VISIBLE_DEVICES"] = original_visible_devices

    import queue

    all_results: list[dict] = []
    all_failed: list[dict] = []
    max_jobs_per_worker = max(
        (len(job_group) for job_group in gpu_job_dicts),
        default=0,
    )
    total_timeout = (
        max(28_800, (time_limit + 60) * max_jobs_per_worker)
        if time_limit > 0
        else None
    )
    deadline = (
        time.time() + total_timeout
        if total_timeout is not None
        else None
    )
    completed = 0
    while completed < len(processes):
        remaining = (
            deadline - time.time()
            if deadline is not None
            else None
        )
        if remaining is not None and remaining <= 0:
            print(f"  总超时({total_timeout}s)，已收集 {completed}/{len(processes)}，跳过剩余")
            break
        try:
            queue_timeout = (
                min(remaining, 30)
                if remaining is not None
                else 30
            )
            wr = result_queue.get(timeout=queue_timeout)
            all_results.extend(wr.get("results", []))
            all_failed.extend(wr.get("failed", []))
            completed += 1
        except queue.Empty:
            alive_count = sum(1 for p in processes if p.is_alive())
            if alive_count == 0:
                print(f"  所有 Worker 已退出（崩溃），已收集 {completed}/{len(processes)}，跳过剩余")
                while True:
                    try:
                        wr = result_queue.get_nowait()
                        all_results.extend(wr.get("results", []))
                        all_failed.extend(wr.get("failed", []))
                        completed += 1
                    except queue.Empty:
                        break
                break
            continue
    print(f"  共收集 {completed}/{len(processes)} 个 Worker 结果")

    for p in processes:
        p.join(timeout=30)
        if p.is_alive():
            p.terminate()
            p.join(timeout=5)

    t_total = time.time() - t0
    print(f"\n  GPU 分布式执行完成: {len(all_results)} 成功, "
          f"{len(all_failed)} 失败, 总耗时 {t_total:.1f}s")

    # Step 5: 保存结果
    print("[5/5] 保存结果...")
    save_json(all_results, out_dir / "raw_results.json")
    save_json({"failed": all_failed, "missing_datasets": missing_notes},
              out_dir / "errors.json")

    summary = {
        "benchmark": _BENCHMARK, "model_type": method_name, "task_type": task_type,
        "registry_key": registry_key,
        "manual_config": manual_config,
        "num_gpus": num_gpus,
        "time_limit": time_limit,
        "run_config": run_config,
        "run_cache_key": run_cache_key,
        "num_jobs": len(jobs), "num_datasets": n_datasets,
        "num_success": len(all_results), "num_failed": len(all_failed),
        "elapsed_seconds": t_total,
        "missing_datasets": missing_notes,
    }
    save_json(summary, out_dir / "summary.json")
    return summary


# ============================================================================
#  main
# ============================================================================

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="TabArena 官方 17 方法直接运行")
    p.add_argument("--methods", type=str, default="all",
                   help=f"逗号分隔的方法名；默认全部: {','.join(METHODS)}")
    p.add_argument("--num_gpus", type=int, default=8)
    p.add_argument("--time_limit", type=int, default=3600,
                   help="每个 job 的 fit 时间限制（秒）")
    p.add_argument("--output_dir", type=str, default="benchmark_results")
    p.add_argument("--task_type", type=str, default=None,
                   help="仅跑指定任务类型: classification / regression")
    p.add_argument("--debug", action="store_true", default=False)
    p.add_argument("--debug_datasets", type=int, default=2)
    p.add_argument("--debug_splits_per_dataset", type=int, default=1)
    p.add_argument("--list_methods", action="store_true",
                   help="列出可运行方法并退出")
    return p.parse_args()


def main() -> None:
    args = parse_args()

    if args.list_methods:
        print(f"共 {len(METHODS)} 个可直接运行的方法：")
        for name, (key, task_types, fn) in METHODS.items():
            print(f"  {name}  (registry={key}, tasks={task_types}, "
                  f"checkpoint={'本地' if fn else '无'})")
        return

    if args.methods.strip().lower() == "all":
        selected = list(METHODS.keys())
    else:
        selected = [m.strip() for m in args.methods.split(",") if m.strip()]
        unknown = [m for m in selected if m not in METHODS]
        if unknown:
            raise SystemExit(f"未知方法: {unknown}；可选: {sorted(METHODS)}")

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 校验 checkpoint 存在性
    for name in selected:
        _, task_types, manual_fn = METHODS[name]
        for tt in task_types:
            if args.task_type and tt != args.task_type:
                continue
            if manual_fn is None:
                continue
            cfg = manual_fn(tt)
            for v in cfg.values():
                # 只校验绝对路径（checkpoint_version 等相对短名跳过）
                if isinstance(v, str) and v.startswith("/") and not Path(v).exists():
                    raise SystemExit(f"[{name}] checkpoint 不存在: {v}")
                if isinstance(v, dict):
                    for vv in v.values():
                        if not Path(vv).exists():
                            raise SystemExit(f"[{name}] checkpoint 不存在: {vv}")
                if isinstance(v, list):
                    for vv in v:
                        if isinstance(vv, str) and vv.startswith("/"):
                            if not Path(vv).exists():
                                raise SystemExit(f"[{name}] checkpoint 不存在: {vv}")
                        else:
                            p = Path(cfg.get("custom_model_dir", ".")) / vv
                            if not p.exists():
                                raise SystemExit(f"[{name}] checkpoint 不存在: {p}")

    summaries = []
    for name in selected:
        _, _, _ = METHODS[name]
        task_types = [tt for tt in METHODS[name][1]]
        if args.task_type:
            task_types = [tt for tt in task_types if tt == args.task_type]
        for tt in task_types:
            try:
                s = run_method(
                    name, tt,
                    num_gpus=args.num_gpus,
                    output_dir=output_dir,
                    time_limit=args.time_limit,
                    debug=args.debug,
                    debug_datasets=args.debug_datasets,
                    debug_splits_per_dataset=args.debug_splits_per_dataset,
                )
                summaries.append(s)
            except KeyboardInterrupt:
                print(f"\n用户中断，停止后续方法。已完成的 {len(summaries)} 项结果已保存。")
                raise SystemExit(1)
            except Exception as e:
                print(f"\n[ERROR] {name} × {tt} 运行失败: {e}")
                traceback.print_exc()
                summaries.append({
                    "model_type": name, "task_type": tt, "error": str(e),
                })

    print("\n" + "=" * 70)
    print("全部完成，结果摘要：")
    print("=" * 70)
    for s in summaries:
        err = s.get("error")
        if err:
            print(f"  {s.get('model_type')}_{s.get('task_type','')[:3]}: FAILED ({err})")
        else:
            print(f"  {s.get('model_type')}_{s.get('task_type','')[:3]}: "
                  f"{s.get('num_success')}/{s.get('num_jobs')} jobs, "
                  f"fail={s.get('num_failed')}")


if __name__ == "__main__":
    main()
