#!/bin/bash
# xiaomi-tabldm × beyondarena × reg(回归)
# 用法: 可覆盖环境变量 OUT_DIR / GPU_IDS / TIME_LIMIT / DEBUG_ARGS
#   例: GPU_IDS=4,5 bash run_xiaomi_beyondarena_reg.sh
# 说明: xiaomi-tabldm 无 TabArena 模型约束, 无需 RELAX; 大数据集可能超时/OOM,
#   单 config 上限 TIME_LIMIT。
set -u
cd /ssd/lamdatfm/chengzj/benchmark || exit 1
PY=/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python
OUT_DIR=${OUT_DIR:-/ssd/lamdatfm/chengzj/benchmark/benchmark_results_mitra_tabldm}
GPU_IDS=${GPU_IDS:-0,1,2,3,4,5,6,7}
TIME_LIMIT=${TIME_LIMIT:-14400}
N_GPU=$(echo "$GPU_IDS" | tr ',' '\n' | grep -c .)
LOGDIR=$OUT_DIR/logs
mkdir -p "$LOGDIR"
export CUDA_VISIBLE_DEVICES=$GPU_IDS
export TMPDIR=${TMPDIR:-/ssd/lamdatfm/chengzj/tmp}
mkdir -p "$TMPDIR"
echo "===== [${LOGNAME}] START $(date '+%F %T') model=xiaomi-tabldm bench=beyondarena task=reg gpus=$N_GPU ====="
$PY -u run_all_benchmarks.py \
  --models xiaomi-tabldm \
  --benchmarks beyondarena \
  --reg_only \
  --output_dir "$OUT_DIR" \
  --num_gpus "$N_GPU" \
  --time_limit "$TIME_LIMIT" \
  ${DEBUG_ARGS:-} \
  > "$LOGDIR/xiaomi_beyondarena_reg.log" 2>&1
RC=$?
echo "===== [${LOGNAME}] END $(date '+%F %T') exit=$RC ====="
exit $RC
