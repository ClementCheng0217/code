#!/bin/bash
# mitra-tabular × beyondarena × reg(回归)
# 用法: 可覆盖环境变量 OUT_DIR / GPU_IDS / TIME_LIMIT / DEBUG_ARGS / RELAX
#   例: GPU_IDS=4,5 bash run_mitra_beyondarena_reg.sh
#   例: RELAX=0 bash run_mitra_beyondarena_reg.sh   # 关闭约束解除, 仅跑 mitra 能力范围内任务
# RELAX=1(默认): 解除 mitra 双层约束(TABPFNV2 约束过滤 + AutoGluon 行数/特征上限),
#   与 tabarena 全量补测口径一致。注意: 约束外数据集(>10k 行)属"强行"补测,
#   大数据集可能超时/OOM(单 config 上限 TIME_LIMIT), 属预期风险。
set -u
cd /ssd/lamdatfm/chengzj/benchmark || exit 1
PY=/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python
OUT_DIR=${OUT_DIR:-/ssd/lamdatfm/chengzj/benchmark/benchmark_results_mitra_tabldm}
GPU_IDS=${GPU_IDS:-0,1,2,3,4,5,6,7}
TIME_LIMIT=${TIME_LIMIT:-14400}
RELAX=${RELAX:-1}
N_GPU=$(echo "$GPU_IDS" | tr ',' '\n' | grep -c .)
LOGDIR=$OUT_DIR/logs
mkdir -p "$LOGDIR"
export CUDA_VISIBLE_DEVICES=$GPU_IDS
export TMPDIR=${TMPDIR:-/ssd/lamdatfm/chengzj/tmp}
mkdir -p "$TMPDIR"
if [ "$RELAX" = "1" ]; then
  export RELAX_MODEL_CONSTRAINTS=MITRA
  export RELAX_MITRA_AG_LIMITS=1
  echo "[relax] 已解除 mitra 约束: RELAX_MODEL_CONSTRAINTS=MITRA RELAX_MITRA_AG_LIMITS=1"
fi
echo "===== [${LOGNAME}] START $(date '+%F %T') model=mitra-tabular bench=beyondarena task=reg gpus=$N_GPU relax=$RELAX ====="
$PY -u run_all_benchmarks.py \
  --models mitra-tabular \
  --benchmarks beyondarena \
  --reg_only \
  --output_dir "$OUT_DIR" \
  --num_gpus "$N_GPU" \
  --time_limit "$TIME_LIMIT" \
  ${DEBUG_ARGS:-} \
  > "$LOGDIR/mitra_beyondarena_reg.log" 2>&1
RC=$?
echo "===== [${LOGNAME}] END $(date '+%F %T') exit=$RC ====="
exit $RC
