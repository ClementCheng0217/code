#!/bin/bash
# mitra-tabular × tabarena × reg(回归)
# 用法: 可覆盖环境变量 OUT_DIR / GPU_IDS / TIME_LIMIT / DEBUG_ARGS
#   例: GPU_IDS=4,5 bash run_mitra_tabarena_reg.sh
set -u
cd /ssd/lamdatfm/chengzj/benchmark || exit 1
PY=/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python
OUT_DIR=${OUT_DIR:-/ssd/lamdatfm/chengzj/benchmark/benchmark_results_mitra_tabldm}
GPU_IDS=${GPU_IDS:-0,1,2,3,4,5,6,7}
TIME_LIMIT=${TIME_LIMIT:-14400}
N_GPU=$(echo "$GPU_IDS" | tr ',' '\n' | grep -c .)
LOGDIR=$OUT_DIR/logs
mkdir -p "$LOGDIR"
export CUDA_VISIBLE_DEVICES=$GPU_IDS
echo "===== [${LOGNAME}] START $(date '+%F %T') model=mitra-tabular bench=tabarena task=reg gpus=$N_GPU ====="
$PY -u run_all_benchmarks.py \
  --models mitra-tabular \
  --benchmarks tabarena \
  --reg_only \
  --output_dir "$OUT_DIR" \
  --num_gpus "$N_GPU" \
  --time_limit "$TIME_LIMIT" \
  ${DEBUG_ARGS:-} \
  > "$LOGDIR/mitra_tabarena_reg.log" 2>&1
RC=$?
echo "===== [${LOGNAME}] END $(date '+%F %T') exit=$RC ====="
exit $RC
