#!/bin/bash
# EXAONE-Tabular regressor v1 TabArena 回归完整评测
# 前置修复:
#   1) /ssd/lamdatfm/chengzj/pylib/exaonetabular (patch 后副本, 忽略 head_scale 多余 key)
#   2) exaone_model.py _predict_proba 回归分发到 predict
# 只跑 tabarena 回归任务 (--reg_only)
export TMPDIR=/ssd/lamdatfm/chengzj/tmp
mkdir -p $TMPDIR
cd /ssd/lamdatfm/chengzj/benchmark
PY=/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python
LOG=/tmp/exaone_reg_tabarena.log
rm -f $LOG
setsid nohup env PYTHONPATH=/ssd/lamdatfm/chengzj/pylib \
  CUDA_VISIBLE_DEVICES=2,3,4 $PY -u run_all_benchmarks.py \
  --direct_ckpt /ssd/lamdatfm/chengzj/models/exaone-tabular-regressor-v1_default.safetensors \
  --direct_adapter exaone_tabular --model_name exaone-tabular-v1 \
  --benchmarks tabarena --reg_only --num_gpus 3 --time_limit 14400 \
  --output_dir benchmark_results/exaone_reg_v1_tabarena > $LOG 2>&1 &
echo "STARTED PID $!  LOG=$LOG"
sleep 25
echo "===== 日志开头 ====="
head -50 $LOG
