
<div align="center">

<div id="user-content-toc">
  <ul align="center" style="list-style: none;">
    <summary>
      <img src="https://avatars.githubusercontent.com/u/210855230" width="175" alt="TabArena Logo"/>
    </summary>
  </ul>
</div>

## 表格数据机器学习的活体基准 💫

---

| 🚀 [排行榜](https://tabarena.ai/) | 📂 [示例脚本](https://tabarena.ai/code-examples) | 📊 [数据集策展](https://tabarena.github.io/data-foundry/) | 📄 论文: [TabArena-v0.1](https://arxiv.org/abs/2506.16791) · [BeyondArena](https://arxiv.org/abs/2606.30410) |
|:--------------------------------------:|:----------------------------------------------------------------------------------------:|:----------------------------------------------------------------------------------------:|:--------------------------------------------------------------------------------------------------------------:|

---
</div>

TabArena 是一个活体基准测试系统，旨在让表格机器学习模型的基准测试变得可靠。TabArena 实施了一系列最佳实践，确保每个方法都能发挥其最大潜力，包括交叉验证集成、由方法作者贡献的强大超参数搜索空间、早停、模型重拟合、并行 bagging、内存使用量估算等。欢迎在[在线排行榜](https://huggingface.co/spaces/TabArena/leaderboard)上查看最新结果。

本代码库支撑着**两个互补的基准**，它们共享相同的拟合、运行和评估代码：

- 🏟️ **TabArena-v0.1** — 基于**策展后的 IID** 表格数据集的活体基准。
- 🌍 **BeyondArena** — 一个全面的***超越 IID*** 基准，涵盖**IID、时序和分组**
  任务，覆盖广泛的数据集规模和特征维度。
  **BeyondArena 未来将取代 TabArena-v0.1。**

> [!TIP]
> **新来的？从 TabArena 开始，然后进阶到 BeyondArena。** 先让你的模型在 TabArena 策展后的 IID 数据集上顺利运行并具有竞争力；一旦在那里站稳脚跟，再用**相同**的代码在 BeyondArena 上进行压力测试，看看它超越 IID 的泛化能力如何。

**TabArena** 涵盖 51 个策展数据集（每个 9–30 折）和 27+ 种方法，包括 10+ 种表格基础模型——超过 5000 万次模型训练，所有验证和测试预测结果均已缓存，用于调优和事后集成。**BeyondArena** 将其扩展到 **[142 个数据集](https://huggingface.co/datasets/TabArena/BeyondArena)**，涵盖 IID、时序和分组任务类型，覆盖从微型到百万行规模的数据集，以及从低维到高维特征。


## ⚡ 快速开始

> [!TIP]
> 最快的端到端体验 TabArena 的方式：

```bash
pip install uv
git clone https://github.com/autogluon/tabarena.git && cd tabarena
uv venv --seed --python 3.12 && source .venv/bin/activate
uv pip install --prerelease=allow -e "./packages/tabarena[benchmark]"
python examples/benchmarking/run_quickstart_tabarena.py
```

其他安装方式（仅评估、可编辑 AutoGluon 版本、依赖项）请参见下方的[安装](#-安装)部分。
如果想尝试 **BeyondArena**，使用相同的安装方式，运行 `python examples/beyondarena/run_quickstart_beyondarena.py` 即可。

## 🕹️ 使用场景

我们在[示例](examples)中详细介绍了 TabArena 的各种使用场景：

* 🌍 **超越 IID 的基准测试 (BeyondArena)**：请参考 [examples/beyondarena](examples/beyondarena)。
* 📊 **预测性机器学习模型基准测试**：请参考 [examples/benchmarking](examples/benchmarking)。
* 🚀 **使用 TabArena 基准测试的 SOTA 表格模型**：请参考 [examples/running_tabarena_models](examples/running_tabarena_models)。
* 🧪 **高级和专业化使用**：请参考 [examples/advanced](examples/advanced)。
* 🗃️ **分析元数据和元学习**：请参考 [examples/meta](examples/meta)。
* 📈 **生成图表和排行榜**：请参考 [examples/plots](examples/plots)。
* 🔁 **可复现性**：我们在[示例](examples)中提供了可复现性相关说明。

### 数据集

请参考我们的[数据集策展仓库](https://github.com/TabArena/tabarena_dataset_curation)了解更多关于我们贡献的数据！

### 更多文档

TabArena 代码目前正在打磨中。TabArena 的详细文档即将推出。

# 🪄 安装

> [!IMPORTANT]
> 需要 Python **3.11–3.13** 和 [uv](https://docs.astral.sh/uv/getting-started/installation/)。

TabArena 是一个 [uv 工作空间](https://docs.astral.sh/uv/concepts/projects/workspaces/)；其可安装的包位于 `packages/` 目录下（`tabarena`、`bencheval`、`tabflow_slurm`）。根据你需要的附加功能，直接从 `packages/tabarena` 安装 `tabarena` 包。`--prerelease=allow` 标志是必需的，以便 uv 解析预发布版本的依赖项。

首先克隆仓库并创建虚拟环境（一次性操作）：

```bash
git clone https://github.com/autogluon/tabarena.git
cd tabarena
uv venv --seed --python 3.12
source .venv/bin/activate
```

然后选择适合你需求的安装方式：

<details>
<summary><b>📊 仅评估</b> — 排行榜、指标和图表，无需模型拟合</summary>

加载缓存结果并计算/绘制排行榜和指标（ELO、胜率、排名）。依赖 `autogluon.tabular`（而非完整的 AutoGluon 元包）——不包含模型拟合库和 torch。

```bash
uv pip install --prerelease=allow -e "./packages/tabarena[plot]"
```
</details>

<details>
<summary><b>🚀 基准测试</b> — 用于基准测试的核心模型集</summary>

安装用于标准基准测试的核心模型：`tabpfn`、`tabicl`、`ebm`、`search_spaces`、`realmlp`、`tabdpt`、`tabm`。

```bash
uv pip install --prerelease=allow -e "./packages/tabarena[benchmark]"
```
</details>

<details>
<summary><b>➕ 基准测试 + 扩展</b> — 核心模型加上扩展模型集</summary>

> `extended` 附加功能是**实验性**的，可能因各模型依赖项的版本要求不兼容而导致安装失败。
> 仅在确实需要在单一环境中使用所有模型时才使用它；
> 否则建议使用 `benchmark` 或 `benchmark` 加上单个特定模型。

在核心基准测试集之上叠加扩展模型集（`modernnca`、`xrfm`、`sap-rpt-oss` 等）。

```bash
uv pip install --prerelease=allow -e "./packages/tabarena[benchmark,extended]"
```

如果只需要在 `benchmark` 之上安装一个扩展模型（当你只需要单一额外模型时，推荐使用此方式而非 `extended`），可以通过其附加功能名称单独安装——例如，只安装 `xrfm`：

```bash
uv pip install --prerelease=allow -e "./packages/tabarena[benchmark,xrfm]"
```
</details>

<details>
<summary><b>🛠️ 开发者</b> — 可编辑版 AutoGluon + 可编辑版 TabArena</summary>

在你的工作空间目录中创建虚拟环境（它会横跨下方克隆的两个仓库，因此 `.venv` 位于工作空间根目录而非任一仓库内部）：

```bash
uv venv --seed --python 3.12 .venv
source .venv/bin/activate
```

安装可编辑版 AutoGluon 和 TabArena：

```bash
git clone https://github.com/autogluon/autogluon.git
./autogluon/full_install.sh

git clone https://github.com/autogluon/tabarena.git
uv pip install --prerelease=allow -e "./tabarena/packages/tabarena[benchmark]"
```

> 在 PyCharm 中，将 `packages/tabarena/src/` 和每个 `autogluon/src/` 子目录标记为**源码根目录 (Sources Root)**，以便导入正确解析。

</details>

<details>
<summary><b>📦 将 TabArena 作为依赖项使用</b></summary>

将以下内容添加到你的项目依赖中：

```toml
# TabArena 依赖 AutoGluon 的预发布版本，因此安装时需要允许预发布版本
# （例如 `uv pip install --prerelease=allow ...` 或 `pip install --pre ...`）。
# 或者，将 AutoGluon 钉在特定的预发布版本上（使用精确的 `==` 版本钉定无需标志即可解析预发布版本），
# 例如添加 `"autogluon.tabular==1.5.1b20260626"`。
"tabarena @ git+https://github.com/autogluon/tabarena.git#subdirectory=packages/tabarena"
```

</details>

# 📦 TabArena 制品

TabArena 将预测结果、运行结果和排行榜缓存为可下载的制品，让你无需重新运行基准测试即可复现或扩展任何分析。

<details>
<summary><b>制品层级、大小和示例</b></summary>

> 制品默认下载到 `~/.cache/tabarena/`。可以通过 `TABARENA_CACHE` 环境变量覆盖该位置。
> 
> 原始数据约为**每种方法类型 100 GB**。下载之前请将 `TABARENA_CACHE` 指向一个大容量磁盘。

| 层级 | 内容 | 每种方法大小 | 示例 |
|---|---|---|---|
| **原始数据** | 每个子模型的测试预测、完整元数据、系统信息 | 约 100 GB | [`inspect_raw_data_and_verify_splits.py`](examples/meta/inspect_raw_data_and_verify_splits.py) |
| **处理后数据** | 用于 HPO 模拟、投资组合、排行榜的最小数据 | 约 10 GB | [`inspect_processed_data.py`](examples/meta/inspect_processed_data.py) |
| **结果** | 每个配置 / HPO 的 DataFrame（测试误差、验证误差、训练时间、推理时间） | < 1 MB | [`run_generate_main_leaderboard.py`](examples/plots/run_generate_main_leaderboard.py) |
| **排行榜** | 聚合的 ELO、胜率、平均排名、可改进性 | < 1 MB | — |
| **图表** | 从结果和排行榜生成的图表 | — | — |

</details>


# 📄 引用

> 如果你在科学出版物中使用了本代码，请引用相应的论文：**TabArena** 对应活体 IID 基准，**BeyondArena** 对应超越 IID 基准。

### TabArena

**TabArena: A Living Benchmark for Machine Learning on Tabular Data**
Nick Erickson, Lennart Purucker, Andrej Tschalzev, David Holzmüller, Prateek Mutalik Desai, David Salinas, Frank Hutter
*NeurIPS 2025, Datasets and Benchmarks Track*

📄 [arXiv](https://arxiv.org/abs/2506.16791) · 🎤 [NeurIPS 海报和视频](https://neurips.cc/virtual/2025/loc/san-diego/poster/121499)

<details>
<summary><b>BibTeX</b></summary>

> 该条目使用 `year=2026`，因为 NeurIPS'25 论文集于 2026 年出版。

```bibtex
@article{erickson2026tabarena,
  title   = {TabArena: A Living Benchmark for Machine Learning on Tabular Data},
  author  = {Erickson, Nick and Purucker, Lennart and Tschalzev, Andrej and Holzm{\"u}ller, David and Desai, Prateek and Salinas, David and Hutter, Frank},
  journal = {Advances in Neural Information Processing Systems},
  volume  = {38},
  year    = {2026}
}
```

</details>

### BeyondArena

**Beyond IID: How General Are Tabular Foundation Models, Really?**
Lennart Purucker, Andrej Tschalzev, Nick Erickson, Gioia Blayer, David Holzmüller, Alan Arazi, Alexander Pfefferle, Mustafa Tajjar, Gaël Varoquaux, Frank Hutter

📄 [arXiv](https://arxiv.org/abs/2606.30410)

<details>
<summary><b>BibTeX</b></summary>

```bibtex
@misc{purucker2026beyondiid,
  title         = {Beyond IID: How General Are Tabular Foundation Models, Really?},
  author        = {Purucker, Lennart and Tschalzev, Andrej and Erickson, Nick and Blayer, Gioia and Holzm{\"u}ller, David and Arazi, Alan and Pfefferle, Alexander and Tajjar, Mustafa and Varoquaux, Ga{\"e}l and Hutter, Frank},
  year          = {2026},
  eprint        = {2606.30410},
  archivePrefix = {arXiv},
  primaryClass  = {cs.LG},
  url           = {https://arxiv.org/abs/2606.30410}
}
```

</details>


--- 
## 与 TabRepo 的关系

TabArena 建立在 [TabRepo](https://arxiv.org/pdf/2311.02971) 之上，现已取代它。有关 TabRepo（投资组合模拟仓库）的详细信息，请参阅 [tabrepo.md](tabrepo.md)。
