"""TabICL GPU BeyondArena 全数据集评测脚本 — 在所有 BeyondArena 分类数据集上顺序运行。

- 每个 (dataset, fold, repeat) 在独立子进程中运行，GPU OOM 不影响其他任务
- 自动跳过回归数据集（TabICL 仅支持分类）
- 最后汇总各数据集成功/失败状态

用法:
    python run_tabicl_beyondarena.py
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

# 修复 KMP 重复加载 libiomp5md.dll 的问题
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

from tabarena.benchmark.experiment import BeyondArenaExperimentBundle
from tabarena.benchmark.task.metadata import TaskSubset
from tabarena.contexts import BeyondArenaContext
from tabflow_slurm import (
    BeyondArenaResourcesSetup,
    LocalSequentialSetup,
    ModelJob,
    PathSetup,
    TabArenaBenchmarkPlan,
)

# ── 配置 ──
BENCHMARK_NAME = "beyondarena_tabicl"
WORKSPACE = str(Path.home() / "beyondarena_tabicl_results")
PYTHON_PATH = sys.executable


def _parse_job_command(cmd: str) -> str | None:
    """从运行命令中提取数据集名."""
    import re

    m = re.search(r"--dataset\s+(\S+)", cmd)
    return m.group(1) if m else None


def main() -> None:
    print("=" * 70)
    print("  TabICL GPU BeyondArena 全数据集评测")
    print(f"  启动时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  Python:    {PYTHON_PATH}")
    print(f"  工作目录:  {WORKSPACE}")
    print("=" * 70)

    # 1. 创建 Benchmark Plan（只跑分类任务）
    #    BeyondArena 的 subset 谓词: "core" 是推荐评测协议, "classification" = binary + multiclass
    plan = TabArenaBenchmarkPlan(
        benchmark_name=BENCHMARK_NAME,
        model_jobs=[
            ModelJob(
                models=("TabICL_GPU", 0),
                name="gpu",
                resources={"num_gpus": 1},
            ),
        ],
        context=BeyondArenaContext(),
        task_subset=TaskSubset(subset=["core", "classification"]),
        experiment_bundle=BeyondArenaExperimentBundle(
            preprocessing_pipelines=["default"],
            adapt_num_folds_to_n_classes=False,
        ),
        path_setup=PathSetup(workspace=WORKSPACE, python_path=PYTHON_PATH),
        resources_setup=BeyondArenaResourcesSetup(
            num_cpus=4,
            num_gpus=1,
            memory_limit=16,
            time_limit=14400,  # 4 小时 per fit, 与 BeyondArena 评测协议一致
        ),
        scheduler_setup=LocalSequentialSetup(continue_on_error=True),
        prefetch_model_weights=True,
    )

    # 2. 生成作业
    print("\n正在生成作业...")
    try:
        commands = plan.setup_jobs()
    except Exception as e:
        print(f"\n作业生成失败: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)

    if not commands:
        print("\n没有作业需要运行")
        return

    print(f"生成了 {len(commands)} 个运行命令")

    # 3. 逐个执行，记录每组的耗时和结果
    overall_start = time.time()
    per_dataset: dict[str, dict] = {}

    for i, cmd in enumerate(commands, 1):
        dataset = _parse_job_command(cmd) or f"unknown_{i}"
        t0 = time.time()

        print(f"\n{'=' * 70}")
        print(f"  [{i}/{len(commands)}] {dataset}")
        print(f"  时间: {datetime.now().strftime('%H:%M:%S')}")
        print(f"{'=' * 70}")

        result = subprocess.run(cmd, shell=True, check=False)
        elapsed = time.time() - t0
        mins = int(elapsed // 60)
        secs = int(elapsed % 60)

        status = "OK" if result.returncode == 0 else f"FAIL({result.returncode})"
        print(f"  {dataset}: {status}  ({mins}m {secs}s)")

        per_dataset[dataset] = {
            "status": status,
            "returncode": result.returncode,
            "elapsed_s": round(elapsed, 1),
        }

    total_elapsed = time.time() - overall_start
    hours = int(total_elapsed // 3600)
    mins = int((total_elapsed % 3600) // 60)
    secs = int(total_elapsed % 60)

    # 4. 汇总报告
    ok_list = [d for d, v in per_dataset.items() if v["status"] == "OK"]
    fail_list = [d for d, v in per_dataset.items() if v["status"] != "OK"]

    print(f"\n{'=' * 70}")
    print(f"  评测完成!")
    print(f"  总耗时: {hours}h {mins}m {secs}s")
    print(f"  成功: {len(ok_list)} / {len(per_dataset)}")
    print(f"  失败: {len(fail_list)} / {len(per_dataset)}")
    print(f"{'=' * 70}")

    if fail_list:
        print(f"\n失败数据集 ({len(fail_list)} 个):")
        for d in fail_list:
            print(f"  - {d}: {per_dataset[d]['status']}")

    # 5. 检查结果目录
    results_dir = Path(WORKSPACE) / "output" / BENCHMARK_NAME / "data" / "TA-TabICL_c1_default_BAG_L1"
    if results_dir.exists():
        result_datasets = sorted(d.name for d in results_dir.iterdir() if d.is_dir())
        print(f"\n结果目录中已有 {len(result_datasets)} 个数据集的结果文件")
    else:
        print(f"\n结果目录尚未创建: {results_dir}")

    # 6. 保存汇总 JSON
    summary = {
        "benchmark": BENCHMARK_NAME,
        "model": "TabICL_GPU",
        "start_time": datetime.now().isoformat(),
        "total_elapsed_s": round(total_elapsed, 1),
        "total_datasets": len(per_dataset),
        "success_count": len(ok_list),
        "fail_count": len(fail_list),
        "per_dataset": per_dataset,
    }
    summary_path = Path(WORKSPACE) / f"{BENCHMARK_NAME}_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\n汇总已保存: {summary_path}")


if __name__ == "__main__":
    main()
