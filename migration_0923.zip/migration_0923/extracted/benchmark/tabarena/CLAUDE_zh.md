# CLAUDE.md

本仓库的主要智能体指南是 [`AGENTS.md`](./AGENTS.md)。**请首先阅读它**——其中的所有内容均适用于此处。

本文件仅记录针对 Claude 的特定扩展内容。

## Claude 专用工具

### Skills（`.claude/skills/`）

- **`add-model`** —— 当用户要求添加/集成/封装一个新的表格机器学习模型时使用。它编码了完整的变更内容：每个模型对应的文件夹（包含 `model.py` 包装器、`hpo.py` 搜索空间、`info.py` 注册表条目），以及对 `models/__init__.py`、`models/utils.py` 和 `pyproject.toml` 中 extra 依赖的编辑——并指向每种模型类别（foundation、torch、sklearn-like）的参考实现。该模型会通过其 `info.py` 自动发现，并由 `tests/tabarena/models/test_all_models.py` 自动进行拟合测试（无需为每个模型单独编写测试文件）；仅当其玩具拟合需要更快的超参数时，才添加 `smoke_configs.py` 覆盖配置。
  
- **`benchmark-model`** —— 当维护者希望在基准测试集群上*运行*一个已集成的模型时使用（例如，“基准测试 TabM”、“在集群上运行 Nori”、“为 DenseLight 创建 setup/eval 脚本”）。它会构建一个单一的 `tmp_scripts/run_<model>.py` 脚本，包含共享同一 `benchmark_name` + `PathSetup` 的 `setup` 和 `eval` 子命令（以防止两者偏离），自动填充 GPU/CPU 配置、评估 `subsets`、pip-extra 安装提醒，以及通过内省模型的注册表 `info.py` + `supported_problem_types()` 来预取 foundation 模型。该技能位于生命周期中的 `add-model`（集成）和 `upload-method`（发布）之间。

- **`upload-method`** —— 当维护者指向某个基准测试运行的输出目录，并希望处理/上传/注册该方法的结果时使用（例如，“上传此方法”、“托管/发布 `<model>` 的结果”、“在排行榜中注册 `<model>`”）。它会构建维护者运行的命令清单（`scripts/run_process_method.py` 先 inspect → 再 `--process`；`scripts/run_upload_results.py` 先 dry-run → 再 `--no-dry-run`），并执行 Claude 当前可以提交的编辑操作：更新模型的 `info.py` 中的 `MethodMetadata`（suite / 日期 / `cache_type` / `cache_kwargs` / verified 状态），以及在 `contexts/<arena>/methods.py` 中进行 arena-collection 注册。这对应于 AGENTS.md 中的“处理与上传方法产物（维护者）”部分。

当用户描述的工作符合某个技能的触发条件时，请通过 Skill 工具调用该技能，而不是手动重新创建步骤。

## 在本仓库中的工作风格

- **在报告任务完成之前，始终对修改过的文件运行 `ruff check --fix`**。`from __future__ import annotations` 要求（isort 的 `required-imports`）是新文件中最常见的 CI 失败原因。CI 现在强制执行 `ruff check .` + `ruff format --check .`，并且提供了 pinned 版本的 `.pre-commit-config.yaml`（可通过 `pre-commit install` 安装）——详见 AGENTS.md 中的“Lint & Format”部分。
  
- **测试位于顶层的 `tests/` 目录下，按包分组** —— 当为 `packages/tabarena/src/tabarena/<area>/foo.py` 添加测试时，请在 `tests/tabarena/<area>/test_foo.py` 下镜像相同的路径。（`tests/bencheval/` 和 `tests/tabflow_slurm/` 存放其他两个包的测试；`tests/integration/` 用于跨包测试。）

- **模型拟合测试默认被取消选择并已合并** —— `tests/tabarena/models/test_all_models.py` 会拟合每一个已注册的模型（标记为 `models`，在默认 `pytest` 中被跳过）。使用 `pytest -m models -k <Model>` 运行单个模型测试；它们需要 `tabarena[benchmark]` 依赖，运行速度较慢，并且在没有 CUDA 的情况下会跳过仅支持 GPU 的模型。不存在每个模型单独的测试文件。对于非模型相关的更改，默认的 `pytest` 已经跳过了这些测试。

- **可选模型依赖**：当添加导入可选库（例如 `tabpfn`、`tabicl`、`xrfm`）的代码时，请将导入语句保留在包装器的 `_fit` 方法或类主体内部，切勿放在模块顶层——顶层导入会导致未安装该 extra 依赖时的安装失败。

- **文档字符串描述当前行为，而非重构历史。** 当你重命名、移动或删除代码时，编写的文档字符串/注释应说明代码*当前*是什么样子——不要留下诸如“Formerly X”、“used to live in Y”、“previously did Z”或“now delegates here”之类的叙述，也不要保留对已删除类/模块的死引用。重命名/删除历史应存在于 git 记录和 PR 中，而非源代码里。仅在确实对理解当前代码至关重要时才保留历史性注释（例如，一个非显而易见的向后兼容 shim）。当 `previously` / `used to live` 用于解释*当前*行为并引用仍然存在的代码时，则是可以接受的。