# AGENTS.md

为本仓库中工作的代码智能体提供的指南。面向人类的文档位于 `README.md` 中。

## 项目概述

TabArena 是一个活跃的表格机器学习基准测试平台。它通过交叉验证集成、超参数优化（HPO）模拟和排行榜生成，在 51 个精选数据集上评估机器学习方法。该项目构建于 AutoGluon 之上。

## 仓库布局

本仓库是一个 **uv 工作区**（根目录包含 `pyproject.toml`）。其可安装的包位于 `packages/` 目录下（工作区成员包括 `tabarena`、`bencheval`、`tabflow_slurm`）， alongside 支持性目录：

- `packages/tabarena/` — 核心包。采用仓库模式管理基准数据、模型包装器、模拟、评估和绘图。依赖于 AutoGluon 和 `bencheval`。
- `packages/bencheval/` — 独立的轻量级指标/排行榜包（ELO、胜率、排名、可改进性）。从结果 DataFrame 计算排行榜。不依赖 `tabarena`。
- `packages/tabflow_slurm/` — 用于在 SLURM 集群上运行实验的包（拥有自己的 `pyproject.toml`，是 uv 工作区成员）。依赖于 `tabarena`。详见 `packages/tabflow_slurm/README.md` 和 `packages/tabflow_slurm/AGENTS.md`。
- `examples/` — 基准测试、绘图、元学习和自定义模型的使用示例。
- `tests/` — 所有测试，按包分组（`tests/tabarena/`、`tests/bencheval/`、`tests/tabflow_slurm/`，镜像每个包的 `src/` 布局），以及用于跨包测试的 `tests/integration/`。

## 设置命令

需要 Python 3.11–3.13 和 [uv](https://docs.astral.sh/uv/)。这是一个 uv *虚拟工作区*（根目录 `pyproject.toml` 没有 `[project]` 表），因此请直接从 `packages/tabarena` 安装 `tabarena` 包，而不是在根目录运行 `uv sync`。对于预发布版本的 AutoGluon 依赖项，必须使用 `--prerelease=allow`。在仓库根目录下，创建/激活虚拟环境后（`uv venv --seed --python 3.12 && source .venv/bin/activate`）：

```bash
uv pip install --prerelease=allow -e "./packages/tabarena"               # 最小化安装：仅评估/排行榜/指标
uv pip install --prerelease=allow -e "./packages/tabarena[plot]"         # + 排行榜/结果绘图
uv pip install --prerelease=allow -e "./packages/tabarena[text]"         # + 语义文本特征（sentence-transformers；会拉取 torch）
uv pip install --prerelease=allow -e "./packages/tabarena[preprocessing]" # + skrub 日期时间/统计文本特征生成器
uv pip install --prerelease=allow -e "./packages/tabarena[benchmark]"    # 完整安装（模型 + 绘图 + 文本 + 预处理）
```

核心安装故意保持最小化（issue #323）：它依赖于 `autogluon.tabular`（而非完整的 `autogluon` 元包），并将绘图、文本嵌入和 skrub 特征生成器留给上述 extras（均为懒加载）。`[benchmark]` 是这些 extras 的并集。

如需进行可编辑的 AutoGluon 开发（位于上一级目录）：

```bash
../autogluon/full_install.sh
uv pip install --prerelease=allow -e "./packages/tabarena[benchmark]"
```

## Lint 与格式化

```bash
ruff check .               # Lint（配置：ruff.toml）
ruff format .              # 格式化
```

关键规则：每个文件都必须包含 `from __future__ import annotations`（通过 isort `required-imports` 强制执行）。行长度为 120（格式化工具具有最高权威——不强制执行 `E501`）。使用 Google 风格的文档字符串。在完成任务之前，对修改过的文件运行 ruff。

**CI 运行 `ruff check .` 和 `ruff format --check .`**（参见 `.github/workflows/pytest-pytest.yml`），因此 lint/format 违规会导致构建失败。可选地安装本地 pre-commit 钩子，以便在提交到达 CI 之前自动修复：

```bash
pip install pre-commit && pre-commit install   # 每个克隆只需执行一次
```

此后，`git commit` 会对暂存文件运行 ruff；如果钩子重新格式化或修复了任何内容，提交将中止——重新 `git add` 并再次提交。ruff 版本在 `.pre-commit-config.yaml`、CI 工作流和 `packages/tabarena/pyproject.toml` 中的 `lint` 依赖组中完全固定；请保持这三者同步。

## 测试

测试位于单个顶层 `tests/` 目录中，组织结构镜像 `src/`（tabarena 区域作为子文件夹——`metrics/`、`repository/`、`benchmark/`、`models/` 等——加上其他两个包的 `tests/bencheval/` 和 `tests/tabflow_slurm/`）。根目录 `pyproject.toml` 中的 `[tool.pytest.ini_options]` 设置了 `testpaths = ["tests"]`，因此从仓库根目录运行 bare `pytest` 即可运行整个测试套件。

```bash
pytest                                      # 所有测试
pytest tests/metrics/test_metrics.py        # 单个文件
pytest -k test_name -x                      # 单个测试，失败即停
pytest tests/bencheval                      # 某个包的测试
```

默认的 `pytest` 通过 `addopts` (`-m 'not network and not models'`) 取消选择两个缓慢/脆弱的测试组：

- **`network`** — 访问网络的测试（例如，下载 Hugging Face 模型）。
- **`models`** — `test_all_models.py`，它通过 AutoGluon 的 `FitHelper` 拟合每一个已注册的模型。它在模型注册表上进行参数化，并跳过未安装可选依赖项（`ImportError`）或需要 GPU（`compute='gpu'`，无 CUDA）的模型。使用 `pytest -m models -k TabM` 运行单个模型，或使用 `pytest -m models` 运行整个扫描（需要 `tabarena[benchmark]`）。

这两个组都在夜间工作流中运行。CI 的每个 PR 作业（`.github/workflows/pytest-pytest.yml`）在 Python 3.11 上针对 `./packages/tabarena[plot,preprocessing,data-foundry]` 以及可编辑的 `tabflow_slurm` 包运行 `pytest`（因此其测试和受 data_foundry 保护的测试会运行），但**不**包含 `[text]`/`[benchmark]`——以保持快速（无模型拟合，无 torch）。

## 架构

### 核心数据流

```
原始预测 → EvaluationRepository → 模拟/组合 → 结果 DataFrames → TabArena 排行榜 (bencheval)
```

### 关键抽象

- **`EvaluationRepository`** (`packages/tabarena/src/tabarena/repository/evaluation_repository.py`) — 中央类，结合配置元数据/排名（`ZeroshotSimulatorContext`）、缓存的验证/测试预测（`TabularModelPredictions`）和 `GroundTruth`。支持通过混合类按数据集/fold/配置/问题类型子集化和集成选择。
- **`TabularModelPredictions`** (`packages/tabarena/src/tabarena/predictions/`) — 预测存储的抽象基类。实现包括：`TabularPredictionsInMemory`（基于字典）和 `TabularPredictionsMemmap`（基于磁盘内存映射，用于大型基准测试）。结构：`{dataset: {fold: {val/test: {config: predictions}}}}`。
- **`AbstractExecModel`** (`packages/tabarena/src/tabarena/benchmark/exec_models/base.py`) — 基准*执行*包装器的基类（AutoGluon 包装器位于 `benchmark/exec_models/autogluon.py`）。新的基准测试模型位于 `packages/tabarena/src/tabarena/models/<model>/` 下的每个模型文件夹中（`model.py` = 继承 AG 的 `AbstractModel`/`AbstractTorchModel` 的 AutoGluon 包装器子类，`hpo.py` = 搜索空间生成器，`info.py` = `ModelInfo`/`MethodMetadata` 注册表条目），由 `packages/tabarena/src/tabarena/models/_registry.py::discover_models()` 自动发现（随后 `packages/tabarena/src/tabarena/benchmark/exec_models/registry.py` 从中派生 AG 注册表）。使用 **`add-model` skill** —— 新模型不存在 `benchmark/models/ag/<model>/` 布局。
- **`ExperimentRunner` / `ExperimentBatchRunner`** (`packages/tabarena/src/tabarena/benchmark/experiment/`) — 跨任务执行模型拟合。通过 YAML 配置（`experiment_constructor.py`）。
- **`ZeroshotSimulatorContext`** (`packages/tabarena/src/tabarena/simulation/`) — 管理 HPO 模拟和组合生成的配置排名。
- **`BenchmarkEvaluator`** (`packages/bencheval/src/bencheval/evaluator.py`) — 从结果 DataFrame 计算排行榜。独立于核心 `tabarena` 包。

### 数据缓存

TabArena 使用五个独立的缓存。使用 `tabarena.caching.CacheConfig` 一次性配置它们——这是单一的、有文档记录的接口（`TabArenaContext(cache_config=CacheConfig.from_root(...))`；上下文在构造时应用它，并在 `run_jobs` 内部重新应用，因此分布式 worker 会继承它）。SLURM 路径使用**相同**的对象：setup 将 `context.cache_config` 嵌入到 `JobBatch` 中，每个 worker 应用它（无需 `--openml_cache_dir` 连线）。有关每个缓存的权威参考，请参阅 `CacheConfig` 文档字符串。

| 缓存 | `CacheConfig` 字段 | 存放内容 | 设置方式 | 默认值 |
|---|---|---|---|---|
| OpenML（最重要） | `openml` | 实例化的数据集 + CV 分割 + 所有 TabArena 衍生的任务产物（`tabarena_tasks/`、`tabarena_text_cache/`、`tabarena_metadata_cache/`、`local/datasets/`） | `openml.config.set_root_cache_directory`（无环境变量） | `~/.cache/openml` |
| HuggingFace | `huggingface` | Foundation 模型权重（TabPFN / Mitra / LimiX / ... + 文本嵌入模型） | `HF_HOME` | `~/.cache/huggingface/hub` |
| Data Foundry | `data_foundry` | 一次性原始数据集下载（data_foundry/BeyondArena），随后实例化到 OpenML 缓存中。**不是** `HF_HOME` — data_foundry 向 `snapshot_download` 传递显式的 `cache_dir` | `DATA_FOUNDRY_CACHE` | `~/.cache/data_foundry` |
| TabArena | `tabarena` | 结果 / 基线 / 排行榜产物（原始约 100 GB，处理后约 10 GB，每种方法结果 <1 MB） | `set_tabarena_cache_root` / `TABARENA_CACHE` | `~/.cache/tabarena` |
| Results（运行输出） | `results` | 运行器的 `expname`（`{expname}/data/{method}/{task}/{repeat}_{fold}/results.pkl`） | `run_jobs(expname=...)` | 临时目录（用完即弃） |

### 处理与上传方法产物（维护者）

将基准测试运行中已存在的原始 `results.pkl` 文件转换为缓存、托管和注册的 TabArena 产物——无需下载，无需自动生成。步骤 1–2 是单方法 CLI（完整标志参考见各脚本的模块文档字符串）；步骤 3 是小代码更改。

1. **编写 + 处理** — `scripts/run_process_method.py`（逻辑在 `tabarena.tools.process_local_raw_data` 中）：
   - 检查原始目录以获取建议的元数据片段：`python scripts/run_process_method.py <run_dir>/data`（递归；打印推断的字段 + `MethodMetadata.config/.baseline/.portfolio(...)` 片段）。将其粘贴到 `packages/tabarena/src/tabarena/models/<model>/info.py` 中，并填写 `suite`（必填，必须不同于 `method`）+ 手动字段。
   - 处理：追加 `--method-metadata tabarena.models.<model>.info:<x>_method_metadata --process`。**处理需要显式的 `MethodMetadata`**，首先针对原始数据进行验证（method_type / compute / ag_key / `config_default` / can_hpo / is_bag 必须对齐，且 `method != suite`）；`method` 名称不匹配仅警告，其他不匹配则报错，除非使用 `--ignore-metadata-mismatch`。在 TabArena 缓存下缓存 `metadata.yaml` + `processed/` + `results/`（以及原始数据和 HPO 轨迹，默认开启）。
2. **上传到 r2** — `scripts/run_upload_results.py`：
   - 干跑（默认）验证每个部分是否在本地存在，并打印内容和位置：`python scripts/run_upload_results.py --method-metadata tabarena.models.<model>.info:<x>_method_metadata`（或 `--from-cache METHOD SUITE` 从本地缓存加载）。
   - 实际上传：添加 `--no-dry-run`，并在环境中设置 `R2_ACCOUNT_ID` / `R2_ACCESS_KEY_ID` / `R2_SECRET_ACCESS_KEY`（切勿作为标志传递）。**仅限 r2** — 元数据需要 `cache_type="r2"` + `cache_kwargs={"bucket", "prefix"}`；干跑会打印确切的 `--no-dry-run` 命令，并且当凭据未设置时，说明如何获取它们（`MethodMetadata.r2_credentials_help()`）。默认上传 `raw`（使用 `--no-upload-raw` 跳过）。
3. **在相应上下文的集合中注册** — 添加方法使其出现在基准测试中。对于 TabArena，导入模型的 `info.py` `method_metadata` 并将其添加到 `packages/tabarena/src/tabarena/contexts/tabarena/methods.py` 中的 `tabarena_method_metadata_collection`（该集合直接列出每个模型的 `info.py` 元数据，并且本身是 `TabArenaContext` 使用的论文方法集）。它会自动流入 `tabarena_method_metadata_complete_collection`。其他 arena 上下文在其自己的集合中注册。


### 示例
```bash

# 验证本地缓存状态
python scripts/run_process_method.py /path/to/nori_regression_18062026/data

# 在 info.py 中编辑元数据

 python scripts/run_process_method.py /path/to/nori_regression_18062026/data --method-metadata tabarena.models.nori.info:nori_method_metadata --process

python scripts/run_upload_results.py --method-metadata tabarena.models.nori.info:nori_method_metadata

python scripts/run_upload_results.py --method-metadata tabarena.models.nori.info:nori_method_metadata --no-dry-run

# 将模型添加到 `packages/tabarena/src/tabarena/contexts/tabarena/methods.py` 中的集合
```

## 约定

- **添加新模型**：创建一个文件夹 `packages/tabarena/src/tabarena/models/<model>/`（包含 `model.py`, `hpo.py`, `info.py`, `__init__.py`），然后编辑 `models/__init__.py`（懒加载类条目）、`models/utils.py`（名称→生成器映射）和 `packages/tabarena/pyproject.toml`（每个模型的 extra）。注册表从其 `info.py` 自动发现模型，然后 `tests/tabarena/models/test_all_models.py` 自动拟合它——**没有每个模型的单独测试文件**。仅当 smoke fit 需要更快的玩具超参数或受限的问题类型集时，才在 `tests/tabarena/models/smoke_configs.py` 中添加条目（以模型的 `MethodMetadata.method` 为键）。**使用 `add-model` skill**，它编码了此过程并指向参考实现（foundation / torch / sklearn）。
- **导入**：`from __future__ import annotations` 必须是每个 `.py` 文件中的第一个导入。使用以包为根的绝对导入（例如，`from tabarena.repository import EvaluationRepository`）。
- **可选依赖项**：每个模型在 `packages/tabarena/pyproject.toml` 下都有自己的 pyproject extra；`benchmark` extra 是并集。重型/可选库绝不能在核心路径的模块顶层导入——在模型包装器内部导入。
- **限定作业范围**：在限定 `context.build_jobs` / `build_and_run_jobs` 的范围时（在示例和代码中），通过 `task_subset=` 传递类型化的 `TaskSubset`——它是可用过滤器（`subset`、`dataset_names`、`split_indices`、`problem_types`、`n_train_samples` 等）的唯一真实来源。优先使用它，而不是宽松的 `dataset_names=` / `build_kwargs={...}` 关键字便利方式。
- **除非用户要求，否则不要添加新的顶层文档文件**。就地编辑现有文件。

## PR 与提交指南

- 保持提交专注；不要将无关的重构与错误修复捆绑在一起。
- 在打开 PR 之前，在受影响的路径上运行 `ruff check .` 和 `pytest`。
- `main` 分支的 PR 必须通过 CI。

## 避免事项

- 不要添加 `tst/` 目录或每个包的 `tests/` 目录——所有测试都位于单个顶层 `tests/` 中，按包分组（`tests/tabarena/`、`tests/bencheval/`、`tests/tabflow_slurm/`、`tests/integration/`）。
- 不要在共享模块的顶部导入可选模型依赖项；在包装器内部懒加载导入。
- 不要跳过 `from __future__ import annotations` —— ruff 会导致 CI 失败。
- 未经用户明确指示，不要更改 `EvaluationRepository`、`TabularModelPredictions` 或 `bencheval.evaluator.BenchmarkEvaluator` 的公共 API；它们被外部脚本和产物使用。