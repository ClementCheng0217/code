"""Direct per-dataset comparison: Official TabICL vs Local reproduction."""
from __future__ import annotations

import gzip
import pickle
from pathlib import Path
import pandas as pd

OFFICIAL_PARQUET = r"C:\Users\admin\.cache\tabarena\artifacts\tabarena-2025-06-12\methods\TabICL_GPU\results\model_results.parquet"
LOCAL_RESULTS_DIR = Path(r"C:\Users\admin\tabarena_tabricl_results\output\tabicl_gpu_repro\data\TA-TabICL_c1_default_BAG_L1")

# Map OpenML task_id to dataset name (from task_metadata.csv)
TASK_ID_TO_NAME = {}
metadata_csv = Path(r"C:\Users\admin\tabarena_tabricl_results\setup_out\tabicl_gpu_repro\job_batch_tabicl_gpu_repro_gpu\task_metadata.csv")
with open(metadata_csv) as f:
    header = f.readline().strip().split(",")
    name_idx = header.index("dataset_name")
    tid_idx = header.index("task_id_str")
    for line in f:
        if not line.strip():
            continue
        parts = line.strip().split(",")
        if len(parts) > max(name_idx, tid_idx):
            TASK_ID_TO_NAME[parts[tid_idx]] = parts[name_idx]

# Reverse map: dataset name -> task_id
NAME_TO_TASK_ID = {v: k for k, v in TASK_ID_TO_NAME.items()}


def load_local_results():
    """Load local per-dataset aggregated results."""
    local = {}
    for d in sorted(LOCAL_RESULTS_DIR.iterdir()):
        if not d.is_dir():
            continue
        tid = d.name
        pkl = d / "0_0" / "results.pkl"
        if not pkl.exists():
            continue
        with gzip.open(pkl, "rb") as f:
            data = pickle.load(f)
        if "metric_error" not in data:
            continue
        local[tid] = {
            "dataset": TASK_ID_TO_NAME.get(tid, tid),
            "metric": data["metric"],
            "metric_error": data["metric_error"],
            "metric_error_val": data.get("metric_error_val", None),
            "time_train_s": data.get("time_train_s", 0),
        }
    return local


def load_official_results():
    """Load official results, aggregate by dataset (mean across folds)."""
    df = pd.read_parquet(OFFICIAL_PARQUET)
    # Only real (non-imputed) classification results
    real = df[(df["imputed"] == False) & (df["problem_type"].isin(["binary", "multiclass"]))]
    # Aggregate by dataset
    agg = real.groupby("dataset").agg(
        metric=("metric", "first"),
        metric_error=("metric_error", "mean"),
        metric_error_val=("metric_error_val", "mean"),
        time_train_s=("time_train_s", "mean"),
        n_folds=("fold", "count"),
    ).reset_index()
    return agg


def main():
    local = load_local_results()
    official = load_official_results()

    # Build comparison table
    official_dict = {}
    for _, row in official.iterrows():
        official_dict[row["dataset"]] = {
            "metric": row["metric"],
            "metric_error": row["metric_error"],
            "metric_error_val": row["metric_error_val"],
            "time_train_s": row["time_train_s"],
            "n_folds": row["n_folds"],
        }

    # ============================================================
    print("=" * 110)
    print("  PER-DATASET COMPARISON: Official TabICL vs Local GPU Reproduction")
    print("=" * 110)

    # Only compare classification datasets that exist in both
    common = []
    local_only = []
    official_only = []

    for tid, lr in local.items():
        ds_name = lr["dataset"]
        if ds_name in official_dict:
            common.append((tid, ds_name, lr, official_dict[ds_name]))
        else:
            local_only.append((tid, ds_name, lr))

    for ds_name, or_ in official_dict.items():
        tid = NAME_TO_TASK_ID.get(ds_name)
        if tid is None or tid not in local:
            # Check if it's one of our 36 classification datasets
            if ds_name in TASK_ID_TO_NAME.values():
                official_only.append((ds_name, or_))

    # Sort by dataset name
    common.sort(key=lambda x: x[1])

    print(f"\n  Matched datasets: {len(common)}")
    print(f"  Local-only (no official match): {len(local_only)}")
    print(f"  Official-only (failed locally): {len(official_only)}")
    print()

    # Show matched datasets with metric comparison
    print(f"  {'Dataset':<42} {'Metric':<10} {'Official':>10} {'Local':>10} {'Diff':>10} {'Match?':<8}")
    print("  " + "-" * 100)
    diffs = []
    for tid, ds_name, lr, or_ in common:
        off_err = or_["metric_error"]
        loc_err = lr["metric_error"]
        diff = loc_err - off_err
        diffs.append(diff)
        # For roc_auc, convert error to score for display
        if lr["metric"] == "roc_auc":
            off_score = 1.0 - off_err
            loc_score = 1.0 - loc_err
            diff_score = loc_score - off_score
            match = "YES" if abs(diff) < 0.005 else ("CLOSE" if abs(diff) < 0.01 else "DIFF")
            print(f"  {ds_name:<42} {lr['metric']:<10} {off_score:>10.4f} {loc_score:>10.4f} {diff_score:>+10.4f} {match:<8}")
        else:
            match = "YES" if abs(diff) < 0.005 else ("CLOSE" if abs(diff) < 0.01 else "DIFF")
            print(f"  {ds_name:<42} {lr['metric']:<10} {off_err:>10.4f} {loc_err:>10.4f} {diff:>+10.4f} {match:<8}")

    # Summary stats
    abs_diffs = [abs(d) for d in diffs]
    print(f"\n  Metric error difference summary (Local - Official):")
    print(f"    Mean abs diff: {sum(abs_diffs)/len(abs_diffs):.6f}")
    print(f"    Median abs diff: {sorted(abs_diffs)[len(abs_diffs)//2]:.6f}")
    print(f"    Max abs diff: {max(abs_diffs):.6f}")
    print(f"    Perfect matches (<0.001): {sum(1 for d in abs_diffs if d < 0.001)}/{len(abs_diffs)}")
    print(f"    Close matches (<0.005): {sum(1 for d in abs_diffs if d < 0.005)}/{len(abs_diffs)}")
    print(f"    Close matches (<0.01): {sum(1 for d in abs_diffs if d < 0.01)}/{len(abs_diffs)}")

    # Show datasets that failed locally but succeeded officially
    if official_only:
        print(f"\n  [DATASETS THAT FAILED LOCALLY BUT EXIST IN OFFICIAL BENCHMARK] ({len(official_only)}):")
        print(f"  {'Dataset':<45} {'Metric':<10} {'Official':>10} {'Time(s)':>10} {'Folds':>8} {'Cells':>12}")
        print("  " + "-" * 100)
        for ds_name, or_ in official_only:
            tid = NAME_TO_TASK_ID.get(ds_name, "?")
            # Get dataset size from task_metadata
            n_samples = "?"
            n_features = "?"
            # Read from the task metadata CSV
            with open(metadata_csv) as f:
                f.readline()
                for line in f:
                    parts = line.strip().split(",")
                    if len(parts) > 1 and parts[-1] == tid:
                        h = f.readline().strip().split(",") if False else None
                        break
            metric = or_["metric"]
            off_err = or_["metric_error"]
            if metric == "roc_auc":
                off_score = 1.0 - off_err
            else:
                off_score = off_err
            cells_str = f"{n_samples} x {n_features}"
            print(f"  {ds_name:<45} {metric:<10} {off_score:>10.4f} {or_['time_train_s']:>10.0f} {or_['n_folds']:>8} {cells_str:>12}")

    # Training time comparison
    print(f"\n  [TRAINING TIME COMPARISON]")
    off_times = [or_["time_train_s"] for _, _, _, or_ in common]
    loc_times = [lr["time_train_s"] for _, _, lr, _ in common]
    print(f"    Official median train time: {sorted(off_times)[len(off_times)//2]:.0f}s")
    print(f"    Local median train time:    {sorted(loc_times)[len(loc_times)//2]:.0f}s")
    print(f"    Official total train time:  {sum(off_times):.0f}s ({sum(off_times)/3600:.1f}h)")
    print(f"    Local total train time:     {sum(loc_times):.0f}s ({sum(loc_times)/3600:.1f}h)")

    print("\n" + "=" * 110)
    print("  KEY FINDING:")
    print(f"  TabArena publishes per-dataset, per-fold metrics for every model (parquet files).")
    print(f"  Official TabICL successfully ran on ALL 36 classification datasets.")
    print(f"  Local reproduction succeeded on {len(common)}/{len(common)+len(official_only)} of those.")
    print(f"  For the {len(common)} matched datasets, per-dataset metrics are directly comparable above.")
    print("=" * 110)


if __name__ == "__main__":
    main()
