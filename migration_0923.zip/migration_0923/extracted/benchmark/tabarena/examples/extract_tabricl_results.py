"""Extract and summarize TabICL GPU benchmark results."""
from __future__ import annotations

import gzip
import pickle
from pathlib import Path

RESULTS_DIR = Path(r"C:\Users\admin\tabarena_tabricl_results\output\tabicl_gpu_repro\data\TA-TabICL_c1_default_BAG_L1")
TASK_METADATA_CSV = Path(r"C:\Users\admin\tabarena_tabricl_results\setup_out\tabicl_gpu_repro\job_batch_tabicl_gpu_repro_gpu\task_metadata.csv")


def load_task_names() -> dict[str, str]:
    """Load OpenML task_id_str -> dataset name mapping."""
    mapping = {}
    with open(TASK_METADATA_CSV) as f:
        header = f.readline().strip().split(",")
        # Find column indices
        name_idx = header.index("dataset_name")
        task_id_idx = header.index("task_id_str")
        for line in f:
            if not line.strip():
                continue
            parts = line.strip().split(",")
            if len(parts) > max(name_idx, task_id_idx):
                name = parts[name_idx]
                task_id = parts[task_id_idx]
                mapping[task_id] = name
    return mapping


def load_pickle(path: Path):
    """Load a gzip-compressed pickle file."""
    with gzip.open(path, "rb") as f:
        return pickle.load(f)


def extract_metrics(results_dir: Path) -> dict:
    """Extract metrics from all results.pkl files."""
    task_names = load_task_names()
    results = {}

    all_dirs = sorted(
        [d for d in results_dir.iterdir() if d.is_dir()],
        key=lambda x: x.name,
    )

    for dataset_dir in all_dirs:
        task_id = dataset_dir.name
        dataset_name = task_names.get(task_id, f"unknown_{task_id}")

        result_files = list(dataset_dir.glob("**/results.pkl"))
        if not result_files:
            results[task_id] = {
                "name": dataset_name,
                "status": "NO_RESULTS",
                "error": "No results.pkl found",
            }
            continue

        try:
            data = load_pickle(result_files[0])

            if isinstance(data, dict) and "metric" in data and "metric_error" in data:
                metric_name = data["metric"]
                metric_error = data["metric_error"]
                train_time = data.get("time_train_s", 0)
                # Convert error to actual score (roc_auc = 1 - error, log_loss stays as is)
                if metric_name == "roc_auc":
                    metric_value = 1.0 - metric_error
                else:
                    metric_value = metric_error
                results[task_id] = {
                    "name": dataset_name,
                    "status": "SUCCESS",
                    "metric": metric_name,
                    "value": float(metric_value),
                    "error": float(metric_error),
                    "time_s": float(train_time),
                    "size": result_files[0].stat().st_size,
                }
            else:
                results[task_id] = {
                    "name": dataset_name,
                    "status": "NO_METRIC",
                    "error": f"Results found but couldn't extract metric (keys: {list(data.keys())[:10] if isinstance(data, dict) else type(data).__name__})",
                    "size": result_files[0].stat().st_size,
                }

        except Exception as e:
            results[task_id] = {
                "name": dataset_name,
                "status": "ERROR",
                "error": str(e)[:120],
            }

    return results


def print_summary(results: dict):
    """Print a formatted summary table."""
    print("=" * 100)
    print("TabICL GPU Benchmark Results Summary")
    print("=" * 100)

    success = []
    failed = []

    for task_id in sorted(results.keys()):
        r = results[task_id]
        if r["status"] == "SUCCESS":
            success.append((task_id, r))
        else:
            failed.append((task_id, r))

    print(f"\n[SUCCESS] ({len(success)}/{len(results)} datasets):")
    print("-" * 100)
    print(f"{'Task ID':<10} {'Dataset Name':<42} {'Metric':<10} {'Score':<10} {'Time(s)':<10}")
    print("-" * 100)
    for task_id, r in success:
        metric = r.get("metric", "?")
        value = r.get("value", "?")
        time_s = r.get("time_s", 0)
        value_str = f"{value:.4f}" if isinstance(value, float) else str(value)[:10]
        time_str = f"{time_s:.0f}" if isinstance(time_s, (int, float)) else str(time_s)[:10]
        print(f"{task_id:<10} {r['name']:<42} {metric:<10} {value_str:<10} {time_str:<10}")

    print(f"\n[FAILED / SKIPPED] ({len(failed)}/{len(results)} datasets):")
    print("-" * 100)
    print(f"{'Task ID':<10} {'Dataset Name':<45} {'Reason':<40}")
    print("-" * 100)
    for task_id, r in failed:
        reason = r.get("error", r.get("status", "unknown"))
        print(f"{task_id:<10} {r['name']:<45} {reason:<40}")

    print("\n" + "=" * 100)

    # Print datasets in task list but not in results
    all_expected = set()
    task_names_all = load_task_names()
    all_expected = set(task_names_all.keys())

    in_results = set(results.keys())
    missing = all_expected - in_results
    extra = in_results - all_expected

    if missing:
        print(f"\n[NOT EVALUATED] Datasets in task list but NO output directory ({len(missing)}):")
        for tid in sorted(missing):
            print(f"   {tid} - {task_names_all.get(tid, 'unknown')}")

    if extra:
        print(f"\n[EXTRA] Directories without task metadata ({len(extra)}):")
        for tid in sorted(extra):
            print(f"   {tid}")

    print(f"\nResults directory: {RESULTS_DIR}")
    print(f"Total: {len(success)} successful / {len(failed)} failed / {len(missing)} not evaluated")
    print("=" * 100)


if __name__ == "__main__":
    results = extract_metrics(RESULTS_DIR)
    print_summary(results)
