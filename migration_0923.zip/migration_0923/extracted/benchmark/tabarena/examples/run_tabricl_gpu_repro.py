"""TabICL GPU 本地复现脚本 — 在所有 51 个 TabArena 数据集上顺序运行。

方案二：有 GPU 的单机（本地顺序运行）
- 每个 (dataset, fold, repeat) 在独立子进程中运行，GPU OOM 不影响其他任务
- 自动跳过不兼容的数据集（回归问题等）
- 最后汇总成功/失败/跳过的数据集

用法:
    python examples/run_tabricl_gpu_repro.py
"""

from __future__ import annotations

import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

# ── 修复 KMP 重复加载 libiomp5md.dll 的问题 ──
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

from tabarena.benchmark.experiment import TabArenaV0pt1ExperimentBundle
from tabarena.benchmark.task.metadata import TaskSubset
from tabarena.contexts import TabArenaContext
from tabflow_slurm import (
    LocalSequentialSetup,
    ModelJob,
    PathSetup,
    TabArenaBenchmarkPlan,
    TabArenaV0pt1ResourcesSetup,
)

# ── 配置 ──
BENCHMARK_NAME = "tabicl_gpu_repro"
WORKSPACE = str(Path.home() / "tabarena_tabricl_results")
PYTHON_PATH = sys.executable


def main() -> None:
    print("=" * 70)
    print("  TabICL GPU 本地复现")
    print(f"  启动时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  Python:    {PYTHON_PATH}")
    print(f"  工作目录:  {WORKSPACE}")
    print("=" * 70)

    # ── 1. 创建 Benchmark Plan ──
    plan = TabArenaBenchmarkPlan(
        benchmark_name=BENCHMARK_NAME,
        model_jobs=[
            ModelJob(
                models=("TabICL_GPU", 0),  # 只使用默认配置（can_hpo=False）
                name="gpu",
                resources={"num_gpus": 1},
            ),
        ],
        context=TabArenaContext(),
        # lite = 全部 51 个数据集
        task_subset=TaskSubset(subset="lite"),
        experiment_bundle=TabArenaV0pt1ExperimentBundle(),
        path_setup=PathSetup(workspace=WORKSPACE, python_path=PYTHON_PATH),
        resources_setup=TabArenaV0pt1ResourcesSetup(
            num_cpus=4,
            num_gpus=1,
            memory_limit=16,  # GB, 对于 GPU 模型来说主要是 VRAM 限制
            time_limit=7200,  # 2 小时 per fit，处理大数据集
        ),
        # continue_on_error=True: GPU OOM 时跳过，继续下一个
        scheduler_setup=LocalSequentialSetup(continue_on_error=True),
        prefetch_model_weights=True,
    )

    # ── 2. 生成作业并运行 ──
    print("\n正在生成作业...")
    try:
        commands = plan.setup_jobs()
    except Exception as e:
        print(f"\n作业生成失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

    if not commands:
        print("\n没有作业需要运行（可能全部已缓存或过滤掉了）")
        return

    print(f"\n生成了 {len(commands)} 个运行命令")

    # ── 3. 逐个执行 ──
    overall_start = time.time()
    exit_codes = []

    for i, cmd in enumerate(commands, 1):
        print(f"\n{'=' * 70}")
        print(f"  运行第 {i}/{len(commands)} 组作业")
        print(f"  命令: {cmd}")
        print(f"{'=' * 70}")
        result = subprocess.run(cmd, shell=True, check=False)
        exit_codes.append(result.returncode)

    elapsed = time.time() - overall_start
    hours = int(elapsed // 3600)
    mins = int((elapsed % 3600) // 60)
    secs = int(elapsed % 60)

    print(f"\n{'=' * 70}")
    print(f"  全部完成!")
    print(f"  总耗时: {hours}h {mins}m {secs}s")
    print(f"  退出码: {exit_codes}")
    print(f"{'=' * 70}")

    # ── 4. 检查结果 ──
    results_dir = Path(WORKSPACE) / BENCHMARK_NAME / "data" / "TabICL_GPU"
    if results_dir.exists():
        datasets = sorted(d.name for d in results_dir.iterdir() if d.is_dir())
        print(f"\n已生成结果的数据集 ({len(datasets)} 个):")
        for ds in datasets:
            folds_dir = results_dir / ds
            folds = sorted(d.name for d in folds_dir.iterdir() if d.is_dir())
            print(f"  - {ds}: {len(folds)} folds")
    else:
        print(f"\n结果目录不存在: {results_dir}")


if __name__ == "__main__":
    main()
