from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

if TYPE_CHECKING:
    from tabarena.models._method_metadata import MethodMetadata


class MethodMetadataCollection:
    def __init__(self, method_metadata_lst: list[MethodMetadata]):
        self.method_metadata_lst = method_metadata_lst

    def with_additional_methods(self, method_metadata_lst: list[MethodMetadata]) -> MethodMetadataCollection:
        """Return a new collection: this collection's methods followed by ``method_metadata_lst``.

        Lets a superset collection be derived from a base one by appending extra ``MethodMetadata``
        (e.g. a complete/historical collection from the latest collection) without rebuilding the
        base list. The base collection is left unchanged.
        """
        return MethodMetadataCollection(method_metadata_lst=[*self.method_metadata_lst, *method_metadata_lst])

    def get_method_metadata(
        self,
        method: str,
        suite: str | None = None,
    ) -> MethodMetadata:
        """Return the unique MethodMetadata that matches the provided identifiers.

        The full unique key is (method, suite). This function accepts a
        *partial* key: it filters using only the provided (non-None) fields. If
        that partial key matches exactly one item, that item is returned. If it
        matches zero or multiple items, an informative exception is raised. In the
        multiple-match case, a pandas DataFrame of indistinguishable candidates is
        included.

        Parameters
        ----------
        method
            Method name to match (required).
        suite
            Optional artifact name to further constrain the search.

        Returns:
        -------
        MethodMetadata
            The single MethodMetadata uniquely identified by the provided fields.

        Raises:
        ------
        LookupError
            If zero items match the provided filters.
        ValueError
            If multiple items match (i.e., the provided filters are insufficient
            to uniquely identify a single MethodMetadata). The error message
            includes a DataFrame of candidate rows that cannot be distinguished.
        """
        if not self.method_metadata_lst:
            raise LookupError("No MethodMetadata objects are available in the collection.")

        # 1) Fast pre-filter by method (cheap, avoids converting the whole list).
        by_method = [m for m in self.method_metadata_lst if m.method == method]

        if not by_method:
            valid_methods = [m.method for m in self.method_metadata_lst]
            raise LookupError(
                f"No MethodMetadata entries exist with method='{method}'.\nValid methods: {valid_methods}",
            )

        # 2) Apply only the provided (non-None) fields.
        candidates = [m for m in by_method if suite is None or m.suite == suite]

        # 3) Resolve outcomes without building any DataFrame unless necessary.
        if len(candidates) == 1:
            return candidates[0]

        # Helper: build a tiny DF only for display (lazy import).
        def _candidates_df(objs: list[MethodMetadata]):
            rows = [
                {
                    "method": getattr(m, "method", None),
                    "suite": getattr(m, "suite", None),
                }
                for m in objs
            ]
            # Show unique identifier rows only
            return pd.DataFrame(rows).drop_duplicates().reset_index(drop=True)

        if len(candidates) == 0:
            # Nothing matches *with* the extra filters; show what's available for this method.
            df = _candidates_df(by_method)
            raise LookupError(
                "No MethodMetadata matches the provided filters.\n"
                f"Filters used: method={method!r}, suite={suite!r}\n"
                "Available candidates for this method:\n"
                f"{df.to_string(index=False)}",
            )

        # More than one remains → ambiguous; show just those indistinguishable candidates.
        df = _candidates_df(candidates)
        raise ValueError(
            "Provided filters are insufficient to uniquely identify a MethodMetadata.\n"
            f"Filters used: method={method!r}, suite={suite!r}\n"
            "Indistinguishable candidates:\n"
            f"{df.to_string(index=False)}",
        )

    def info(self) -> pd.DataFrame:
        info_lst = []
        for method_metadata in self.method_metadata_lst:
            cur_info = method_metadata.to_info_dict()
            info_lst.append(cur_info)

        return pd.DataFrame(info_lst)

    def upload_method_metadata_to_s3(self):
        for method_metadata in self.method_metadata_lst:
            method_uploader = method_metadata.method_uploader()
            method_uploader.upload_metadata()
