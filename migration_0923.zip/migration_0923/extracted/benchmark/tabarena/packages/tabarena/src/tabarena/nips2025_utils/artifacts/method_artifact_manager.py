from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing_extensions import Self

from tabarena.models._method_metadata import MethodMetadata
from tabarena.nips2025_utils.artifacts.download_utils import download_and_extract_zip
from tabarena.nips2025_utils.end_to_end import EndToEndSingle


@dataclass(slots=True)
class MethodArtifactManager:
    """Orchestrates download → local cache → upload-to-S3 for a single method."""

    name: str  # method name, e.g., "xRFM_GPU" <- Method identifier. (name, suite) must be unique.
    model_key: str  # e.g., "XRFM_GPU" <- Model key to use for differentiating model families.
    suite: str  # e.g., "tabarena-2025-09-03" <- Differentiates methods with the same name by origin.
    path_suffix: Path  # e.g., Path("leaderboard_submissions/data_xRFM_11092025.zip")
    download_prefix: str  # e.g., "https://data.lennart-purucker.com/tabarena/"
    local_prefix: Path  # e.g., Path("local_data") <- Local dir to download raw files. Can delete after cache.
    s3_bucket: str | None  # e.g., "my-bucket"
    s3_prefix: str | None  # e.g., "cache"
    upload_as_public: bool = False  # Whether the s3 upload will make files public readable
    method_metadata: MethodMetadata | None = None

    def __post_init__(self):
        if not isinstance(self.path_suffix, Path):
            self.path_suffix = Path(self.path_suffix)
        if self.path_suffix.suffix != ".zip":
            raise ValueError(f"path_suffix should be a .zip, got {self.path_suffix}")
        if not self.download_prefix:
            raise ValueError("download_prefix must be non-empty")
        if not isinstance(self.local_prefix, Path):
            self.local_prefix = Path(self.local_prefix)
        # Normalize s3_prefix to avoid accidental '//' in keys
        if self.s3_prefix is not None:
            self.s3_prefix = self.s3_prefix.strip("/")

    @classmethod
    def from_method_metadata(
        cls,
        method_metadata: MethodMetadata,
        path_suffix: Path,
        download_prefix: str,
        local_prefix: Path,
    ) -> Self:
        return cls(
            name=method_metadata.method,
            suite=method_metadata.suite,
            model_key=method_metadata.model_key,
            s3_bucket=method_metadata.cache_kwargs.get("bucket"),
            s3_prefix=method_metadata.cache_kwargs.get("prefix"),
            upload_as_public=method_metadata.cache_kwargs.get("upload_as_public", False),
            method_metadata=method_metadata,
            path_suffix=path_suffix,
            download_prefix=download_prefix,
            local_prefix=local_prefix,
        )

    @property
    def path_raw(self) -> Path:
        return (self.local_prefix / self.path_suffix).with_suffix("")

    @property
    def url(self) -> str:
        return f"{self.download_prefix}{Path(self.path_suffix).as_posix()}"

    def download_raw(self) -> None:
        """Download the zip from `self.url` and extract into `self.path_raw`."""
        download_and_extract_zip(url=self.url, path_local=self.path_raw)

    def cache(self, cache_hpo_trajectories: bool = False) -> EndToEndSingle:
        """Requires first having the raw files locally by calling `self.download_raw()`.

        Cached files will be saved under ~/.cache/tabarena/artifacts/{self.suite}/methods/{self.name}/

        Run logic end-to-end and cache all results:
        1. load raw artifacts
            path_raw should be a directory containing `results.pkl` files for each run.
        2. infer method_metadata
        3. cache method_metadata
        4. cache raw artifacts
        5. infer task_metadata
        5. generate processsed
        6. cache processed
        7. generate results
        8. cache results
        9. (optional, when ``cache_hpo_trajectories=True``) generate and cache HPO trajectories

        Once this is executed once, it does not need to be run again.

        Parameters
        ----------
        cache_hpo_trajectories : bool = False
            If True, also generates and caches HPO trajectories. Only takes effect for
            ``method_type == "config"`` methods.
        """
        return EndToEndSingle.from_path_raw(
            path_raw=self.path_raw,
            method_metadata=self.method_metadata,
            name=self.name,
            model_key=self.model_key,
            suite=self.suite,
            cache=True,
            cache_raw=True,
            cache_hpo_trajectories=cache_hpo_trajectories,
        )

    def upload_to_s3(self) -> None:
        """Upload the local cache for this method to S3 under:
        s3://{self.s3_bucket}/{self.s3_prefix}/artifacts/{self.suite}/methods/{self.name}/.
        """
        method_metadata = self.load_metadata()
        uploader = method_metadata.method_uploader()
        uploader.upload_all()

    def load_metadata(self) -> MethodMetadata:
        """Load MethodMetadata from the local cache for this method."""
        return MethodMetadata.from_yaml(method=self.name, suite=self.suite)
