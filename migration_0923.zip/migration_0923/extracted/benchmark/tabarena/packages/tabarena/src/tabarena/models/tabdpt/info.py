from __future__ import annotations

from tabarena.models._method_metadata import ModelDescriptor
from tabarena.models._model_info import ModelInfo
from tabarena.models.tabdpt.hpo import gen_tabdpt
from tabarena.models.tabdpt.model import TabDPTModel, prefetch_weights

tabdpt_descriptor = ModelDescriptor(
    display_name="TabDPT",
    compute="gpu",
    is_bag=False,
    reference_url="https://arxiv.org/abs/2410.18164",
)

tabdpt_method_metadata = tabdpt_descriptor.method_metadata(
    method="TabDPT_GPU",
    suite="tabarena-2025-10-20",
    ag_key="TABDPT",
    model_key="TABDPT_GPU",
    config_default="TabDPT_GPU_c1_BAG_L1",
    cache_type="s3",
    cache_kwargs={"bucket": "tabarena", "prefix": "cache", "upload_as_public": True},
    date="2025-10-20",
)


tabdpt_info = ModelInfo(
    model_cls=TabDPTModel,
    search_space=gen_tabdpt,
    method_metadata=tabdpt_method_metadata,
    pip_extra=("tabdpt>=1.1.10",),
    prefetch_weights=prefetch_weights,
)
