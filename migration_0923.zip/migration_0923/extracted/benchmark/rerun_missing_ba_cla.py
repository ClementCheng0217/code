#!/usr/bin/env python3
"""Rerun missing BeyondArena classification splits, merge into existing results.

Usage:
  python rerun_missing_ba_cla.py --dry-run   # only print missing stats
  python rerun_missing_ba_cla.py             # run missing jobs on 8 GPUs
"""
import os
import sys
import time
import json
import hashlib
import multiprocessing as mp
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TABPFN_CACHE_DIR", "/ssd/lamdatfm/.cache/tabpfn")
os.environ.setdefault("DATA_FOUNDRY_CACHE", "/ssd/lamdatfm/chengzj/datasets")
os.environ.setdefault("OPENML_CACHE_DIR", "/ssd/lamdatfm/chengzj/datasets/openml_cache")
os.environ.setdefault("XDG_CONFIG_HOME", "/ssd/lamdatfm/chengzj/.config")

import tabpfn.browser_auth as ba
ba.ensure_license_accepted = lambda hf_repo_id: True

from run_all_benchmarks import (
    build_context,
    build_config_generator,
    build_experiments,
    _worker_run_jobs,
    _extract_dataset_name,
    generate_csvs,
    save_json,
    load_json,
    filter_jobs_by_data_availability,
    DATA_DIR,
)

BENCHMARK = "beyondarena"
MODEL_NAME = "tabicl-v2.1"
ARENA_ADAPTER = "tabicl_v2"
TASK_TYPE = "classification"
CHECKPOINT = (
    "/ssd/lamdatfm/chengzj/models/self/260721_float32_stage1/step-500000.ckpt"
)
NUM_GPUS = 8
TIME_LIMIT = 7200
OUTPUT_ROOT = Path("benchmark_results_tabicl_v21_2")
MODEL_TAG = "tabicl-v2.1_cla"
OUT_DIR = OUTPUT_ROOT / BENCHMARK / MODEL_TAG


def _load_existing():
    raw_path = OUT_DIR / "raw_results.json"
    existing = load_json(raw_path) if raw_path.exists() else []
    existing_keys = set()
    for r in existing:
        tm = r.get("task_metadata", {})
        if isinstance(tm, dict) and tm.get("name") is not None:
            existing_keys.add((tm["name"], tm.get("repeat"), tm.get("fold")))
    return existing, existing_keys


def build_missing_jobs():
    context = build_context(BENCHMARK, DATA_DIR)
    config_gen = build_config_generator(ARENA_ADAPTER, CHECKPOINT, TASK_TYPE)
    experiments = build_experiments(BENCHMARK, config_gen, TIME_LIMIT)
    jobs = context.build_jobs(experiments, subset=["all", TASK_TYPE])
    jobs, missing_notes = filter_jobs_by_data_availability(BENCHMARK, jobs)
    return jobs, missing_notes


def _retryable_failed_keys():
    """从 errors.json 读取失败项，仅保留可重试类型（CUDA OOM / 超时 / 文本缓存）。
    数据列类型问题（isnan / 类型比较）重跑必败，直接跳过。"""
    errors_path = OUT_DIR / "errors.json"
    if not errors_path.exists():
        return set(), {}
    err = load_json(errors_path)
    keys = set()
    info = {}
    for item in err.get("failed", []):
        if not isinstance(item, dict):
            continue
        e = str(item.get("error", ""))
        ds = item.get("dataset")
        if not ds:
            continue
        key = (ds, item.get("repeat"), item.get("fold"))
        if "isnan" in e or "not supported between" in e:
            continue
        if any(k in e for k in ("CUDA", "timed out", "Text cache")):
            keys.add(key)
            info[key] = e[:120]
    return keys, info


def main():
    dry_run = "--dry-run" in sys.argv
    retry_failed = "--retry-failed" in sys.argv

    jobs, missing_notes = build_missing_jobs()
    print("full jobs:", len(jobs), "datasets:", len(set(j.task.dataset for j in jobs)))

    existing, existing_keys = _load_existing()
    print("existing results:", len(existing), "unique keys:", len(existing_keys))

    if retry_failed:
        retry_keys, retry_info = _retryable_failed_keys()
        print("retryable failed keys:", len(retry_keys))
        missing_jobs = [
            j
            for j in jobs
            if (j.task.dataset, j.task.repeat, j.task.fold) in retry_keys
        ]
    else:
        missing_jobs = [
            j
            for j in jobs
            if (j.task.dataset, j.task.repeat, j.task.fold) not in existing_keys
        ]
    miss_ds = sorted(set(j.task.dataset for j in missing_jobs))
    print("missing jobs:", len(missing_jobs), "datasets:", len(miss_ds))

    if dry_run or not missing_jobs:
        if not missing_jobs:
            print("nothing missing, exit")
        return

    job_dicts = [j.to_dict() for j in missing_jobs]
    gpu_job_dicts = [[] for _ in range(NUM_GPUS)]
    for i, jd in enumerate(job_dicts):
        gpu_job_dicts[i % NUM_GPUS].append(jd)
    for gid, jds in enumerate(gpu_job_dicts):
        if jds:
            print(f"  GPU {gid}: {len(jds)} jobs")

    run_cache_key = hashlib.sha256(
        json.dumps({"rerun_missing_ba_cla": True, "ts": int(time.time())}).encode()
    ).hexdigest()[:16]
    worker_base = OUT_DIR / "_runs" / run_cache_key

    mp.set_start_method("spawn", force=True)
    result_queue: mp.Queue = mp.Queue()
    processes = []

    original_visible = os.environ.get("CUDA_VISIBLE_DEVICES")
    visible_pool = (
        [s.strip() for s in original_visible.split(",") if s.strip()]
        if original_visible
        else [str(i) for i in range(NUM_GPUS)]
    )
    try:
        for gpu_id in range(NUM_GPUS):
            if not gpu_job_dicts[gpu_id]:
                continue
            os.environ["CUDA_VISIBLE_DEVICES"] = visible_pool[gpu_id]
            p = mp.Process(
                target=_worker_run_jobs,
                args=(
                    gpu_id,
                    gpu_job_dicts[gpu_id],
                    DATA_DIR,
                    str(worker_base),
                    BENCHMARK,
                    ARENA_ADAPTER,
                    result_queue,
                    TIME_LIMIT,
                ),
            )
            p.start()
            processes.append(p)
    finally:
        if original_visible is None:
            os.environ.pop("CUDA_VISIBLE_DEVICES", None)
        else:
            os.environ["CUDA_VISIBLE_DEVICES"] = original_visible

    import queue

    all_results = []
    all_failed = []
    completed = 0
    t0 = time.time()
    partial_path = worker_base / "partial_results.json"
    while completed < len(processes):
        try:
            wr = result_queue.get(timeout=30)
            all_results.extend(wr.get("results", []))
            all_failed.extend(wr.get("failed", []))
            completed += 1
            # incremental save to survive worker crashes
            save_json(all_results, partial_path)
            print(f"  collected {completed}/{len(processes)} workers, "
                  f"results so far: {len(all_results)}, elapsed {time.time()-t0:.0f}s")
        except queue.Empty:
            alive = sum(1 for p in processes if p.is_alive())
            if alive == 0:
                print(f"  all workers exited, collected {completed}/{len(processes)}")
                while True:
                    try:
                        wr = result_queue.get_nowait()
                        all_results.extend(wr.get("results", []))
                        all_failed.extend(wr.get("failed", []))
                        completed += 1
                    except queue.Empty:
                        break
                break
            continue
    print(f"  total collected: {completed}/{len(processes)}, "
          f"success: {len(all_results)}, failed: {len(all_failed)}")

    for p in processes:
        p.join(timeout=30)
        if p.is_alive():
            p.terminate()
            p.join(timeout=5)

    # merge: new results win on same key
    new_keys = set()
    for r in all_results:
        tm = r.get("task_metadata", {})
        if isinstance(tm, dict) and tm.get("name") is not None:
            new_keys.add((tm["name"], tm.get("repeat"), tm.get("fold")))
    merged = [r for r in existing if _extract_dataset_name(r) and (
        (r.get("task_metadata", {}).get("name"), r.get("task_metadata", {}).get("repeat"),
         r.get("task_metadata", {}).get("fold")) not in new_keys
    )] + all_results
    print("merged total:", len(merged), "(new:", len(all_results), ")")

    save_json(merged, OUT_DIR / "raw_results.json")

    # errors.json: keep old failures, add new ones (new wins on same key)
    errors_path = OUT_DIR / "errors.json"
    old_errors = load_json(errors_path) if errors_path.exists() else {}
    old_failed = old_errors.get("failed", [])
    if isinstance(old_failed, dict):
        old_failed = []
    fail_map = {}
    for item in old_failed:
        if isinstance(item, dict):
            k = (item.get("dataset"), item.get("repeat"), item.get("fold"))
            fail_map[k] = item
    for item in all_failed:
        if isinstance(item, dict):
            k = (item.get("dataset"), item.get("repeat"), item.get("fold"))
            fail_map[k] = item
    old_missing = old_errors.get("missing_datasets", {})
    merged_notes = dict(old_missing)
    merged_notes.update(missing_notes or {})
    save_json(
        {"failed": list(fail_map.values()), "missing_datasets": merged_notes},
        errors_path,
    )

    summary = {
        "benchmark": BENCHMARK,
        "model_type": MODEL_NAME,
        "task_type": TASK_TYPE,
        "arena_adapter": ARENA_ADAPTER,
        "checkpoint": CHECKPOINT,
        "num_gpus": NUM_GPUS,
        "n_estimators": None,
        "run_config": {
            "runner_schema_version": 1,
            "benchmark": BENCHMARK,
            "task_type": TASK_TYPE,
            "model_name": MODEL_NAME,
            "arena_adapter": ARENA_ADAPTER,
            "checkpoint": CHECKPOINT,
            "n_estimators": None,
            "time_limit": TIME_LIMIT,
            "debug": False,
            "debug_datasets": None,
            "debug_splits_per_dataset": None,
            "beyondarena_subset": "all",
            "data_dir": DATA_DIR,
        },
        "run_cache_key": run_cache_key,
        "num_jobs": len(jobs),
        "num_datasets": len(set(j.task.dataset for j in jobs)),
        "num_success": len(merged),
        "num_failed": len(all_failed),
        "elapsed_seconds": time.time() - t0,
        "missing_datasets": merged_notes,
        "note": "rerun missing splits, merged with existing results",
    }
    save_json(summary, OUT_DIR / "summary.json")

    # regenerate CSVs: classification results + regression notes preserved
    results_map = {(TASK_TYPE, MODEL_NAME): merged}
    fail_notes = {}
    for item in all_failed:
        if isinstance(item, dict) and item.get("dataset"):
            fail_notes[str(item["dataset"])] = (
                f"{MODEL_NAME} 运行失败: {item.get('error', 'unknown')}"
            )
    # 保留回归任务的失败备注行（不重跑回归，仅保留 CSV 中的回归信息）
    reg_notes = {}
    reg_err_path = OUTPUT_ROOT / BENCHMARK / "tabicl-v2.1_reg" / "errors.json"
    if reg_err_path.exists():
        reg_err = load_json(reg_err_path)
        for item in reg_err.get("failed", []):
            if isinstance(item, dict) and item.get("dataset"):
                reg_notes[str(item["dataset"])] = (
                    f"{MODEL_NAME} 运行失败: {item.get('error', 'unknown')}"
                )
        for ds, nt in (reg_err.get("missing_datasets") or {}).items():
            reg_notes.setdefault(str(ds), str(nt))
    notes = {"classification": fail_notes, "regression": reg_notes}
    generate_csvs(
        benchmark=BENCHMARK,
        results=results_map,
        notes=notes,
        output_dir=OUTPUT_ROOT,
        model_names=[MODEL_NAME],
    )
    print("DONE. CSV regenerated.")


if __name__ == "__main__":
    main()
