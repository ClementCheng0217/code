#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""260914 十二个权重（6 分类 + 6 回归）在 tabarena 的评估：
- cls: 260914_pretrain_cls_s1_260907_fourier_hybrid_attn-res_muon_qkv @step-500000
       (step / ema / lawa_10 / lawa_20 / lawa_50 / lawa_100)
- reg: 260914_pretrain_reg_s3_260909_r2_hard @step-10000
       (step / ema / lawa_10 / lawa_20 / lawa_50 / lawa_100)
每个目录下全部 ckpt。串行执行：分类 6 个在前（重），回归 6 个在后（轻）。

用法：
  python run_full_ta_ba_0914.py --benchmark tabarena --gpus 0,1,2,3,4,5,6,7
"""
import argparse, hashlib, json, os, sys, time, multiprocessing as mp
from pathlib import Path

BENCH_DIR = "/ssd/lamdatfm/chengzj/benchmark"
sys.path.insert(0, BENCH_DIR)
os.chdir(BENCH_DIR)

import run_all_benchmarks as R

M = "/ssd/lamdatfm/chengzj/models/self"
CLS_DIR = f"{M}/260914_pretrain_cls_s1_260907_fourier_hybrid_attn-res_muon_qkv"
REG_DIR = f"{M}/260914_pretrain_reg_s3_260909_r2_hard"


def _mk(key, name, ckpt, task):
    return {"ckpt": ckpt, "name": name, "key": key, "task": task}


MODELS = {
    # ---- 分类: fourier_hybrid_attn-res_muon_qkv @ step-500000 (6 个权重) ----
    "cls_s1_260907_fhmq_s500k":    _mk("cls_s1_260907_fhmq_s500k",    "self-cls-s1-260907-fhmq-s500k",    f"{CLS_DIR}/step-500000.ckpt",          "classification"),
    "cls_s1_260907_fhmq_ema":      _mk("cls_s1_260907_fhmq_ema",      "self-cls-s1-260907-fhmq-ema",      f"{CLS_DIR}/step_500000_ema.ckpt",      "classification"),
    "cls_s1_260907_fhmq_lawa10":   _mk("cls_s1_260907_fhmq_lawa10",   "self-cls-s1-260907-fhmq-lawa10",   f"{CLS_DIR}/step_500000_lawa_10.ckpt",  "classification"),
    "cls_s1_260907_fhmq_lawa20":   _mk("cls_s1_260907_fhmq_lawa20",   "self-cls-s1-260907-fhmq-lawa20",   f"{CLS_DIR}/step_500000_lawa_20.ckpt",  "classification"),
    "cls_s1_260907_fhmq_lawa50":   _mk("cls_s1_260907_fhmq_lawa50",   "self-cls-s1-260907-fhmq-lawa50",   f"{CLS_DIR}/step_500000_lawa_50.ckpt",  "classification"),
    "cls_s1_260907_fhmq_lawa100":  _mk("cls_s1_260907_fhmq_lawa100",  "self-cls-s1-260907-fhmq-lawa100",  f"{CLS_DIR}/step_500000_lawa_100.ckpt", "classification"),
    # ---- 回归: r2_hard @ step-10000 (6 个权重) ----
    "reg_s3_260909_r2hard_s10k":   _mk("reg_s3_260909_r2hard_s10k",   "self-reg-s3-260909-r2hard-s10k",   f"{REG_DIR}/step-10000.ckpt",           "regression"),
    "reg_s3_260909_r2hard_ema":    _mk("reg_s3_260909_r2hard_ema",    "self-reg-s3-260909-r2hard-ema",    f"{REG_DIR}/step_10000_ema.ckpt",       "regression"),
    "reg_s3_260909_r2hard_lawa10": _mk("reg_s3_260909_r2hard_lawa10", "self-reg-s3-260909-r2hard-lawa10", f"{REG_DIR}/step_10000_lawa_10.ckpt",   "regression"),
    "reg_s3_260909_r2hard_lawa20": _mk("reg_s3_260909_r2hard_lawa20", "self-reg-s3-260909-r2hard-lawa20", f"{REG_DIR}/step_10000_lawa_20.ckpt",   "regression"),
    "reg_s3_260909_r2hard_lawa50": _mk("reg_s3_260909_r2hard_lawa50", "self-reg-s3-260909-r2hard-lawa50", f"{REG_DIR}/step_10000_lawa_50.ckpt",   "regression"),
    "reg_s3_260909_r2hard_lawa100":_mk("reg_s3_260909_r2hard_lawa100","self-reg-s3-260909-r2hard-lawa100",f"{REG_DIR}/step_10000_lawa_100.ckpt",  "regression"),
}
# 串行顺序: 分类 6 个(重, 约 12min/模型×8卡) 在前, 回归 6 个(轻, 约 2min/模型×8卡) 在后
ORDER = [k for k in MODELS if k.startswith("cls_")] + [k for k in MODELS if k.startswith("reg_")]
GPU_LIST = os.environ.get("TA_BA_GPUS", "0,1,2,3,4,5,6")
# 按用户要求：统一不跑 consumer_complaints_1m（所有模型都跳过）
SKIP_DATASETS = ["consumer_complaints_1m"]

STALL_TIMEOUT = int(os.environ.get("TA_BA_STALL_TIMEOUT", "1800"))
WATCHDOG_MAX = int(os.environ.get("TA_BA_WATCHDOG_MAX", "604800"))  # 7 天
JOB_TIMEOUT = int(os.environ.get("TA_BA_JOB_TIMEOUT", "43200"))
RESULT_BASE = Path("/var/tmp/czj_bench_results")  # /ssd 已满,输出迁到根分区


def time_limit_of(benchmark, task):
    """tabarena 分类沿用 3600；回归沿用 reg_s1_260830_idempotency 先例 7200。"""
    if benchmark != "tabarena":
        return 43200
    return 3600 if task == "classification" else 7200


def build_official_jobs(ckpt, benchmark, task):
    context = R.build_context(benchmark, R.DATA_DIR)
    config_gen = R.build_config_generator("tabicl_v2", ckpt, task)
    experiments = R.build_experiments(benchmark, config_gen, time_limit_of(benchmark, task))
    jobs = context.build_jobs(experiments, subset=["all", task])
    jobs, _ = R.filter_jobs_by_data_availability(benchmark, jobs)
    return context, jobs


def make_run_config(model_name, ckpt, benchmark, task):
    return {
        "runner_schema_version": R.RUNNER_SCHEMA_VERSION,
        "benchmark": benchmark,
        "task_type": task,
        "model_name": model_name,
        "arena_adapter": "tabicl_v2",
        "checkpoint": str(Path(ckpt).expanduser().resolve()),
        "n_estimators": None,
        "time_limit": time_limit_of(benchmark, task),
        "debug": False,
        "debug_datasets": None,
        "debug_splits_per_dataset": None,
        "beyondarena_subset": "all",
        "ba_max_train_rows": None,
        "ba_max_cols": None,
        "datasets": None,
        "data_dir": R.DATA_DIR,
    }


def load_raw(path):
    if not path.exists():
        return []
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def key_of(r):
    tm = r.get("task_metadata", {})
    return (str(tm.get("name")), tm.get("repeat", 0), tm.get("fold"))


def count_pkl(runs_dir, gpu_id):
    d = runs_dir / f"_worker_gpu{gpu_id}" / "data"
    if not d.exists():
        return 0
    return len(list(d.rglob("results.pkl")))


def done_set(runs_dir):
    done = set()
    if runs_dir.exists():
        for p in runs_dir.rglob("results.pkl"):
            done.add((p.parent.parent.name, p.parent.name))
    return done


def build_tid_map(context):
    """dataset 名 → openml tid（pkl 缓存目录用的是 tid，而 job 只有 dataset 名）。"""
    m = {}
    try:
        for name, meta in context.task_metadata_collection.task_metadata_by_dataset().items():
            try:
                from tabarena.benchmark.task.metadata.schema import tid_from_task_id_str
                m[name] = str(tid_from_task_id_str(meta.task_id_str))
            except Exception:
                continue
    except Exception:
        pass
    return m


def job_key(j, tid_map=None):
    name = str(j.task.dataset)
    tid = (tid_map or {}).get(name)
    return (tid if tid else name, f"{j.task.repeat}_{j.task.fold}")


MAX_JOB_RETRY = int(os.environ.get("TA_BA_MAX_JOB_RETRY", "20"))


def run_jobs(jobs, out_dir, run_cache_key, benchmark, gpu_list=None, tid_map=None):
    pool = [s.strip() for s in (gpu_list or GPU_LIST).split(",") if s.strip()]
    num_gpus = len(pool)
    runs_dir = out_dir / "_runs" / run_cache_key
    # ⚠ 必须先设置 spawn 再创建 Queue：否则 SemLock 属于 fork 上下文，spawn 子进程
    #   反序列化时报 "A SemLock created in a fork context is being shared with a process in a spawn context"
    mp.set_start_method("spawn", force=True)
    # ⚠ result_queue 必须在 run_jobs 顶层创建并保留引用：内联在 args 里会被 GC 回收，
    #   导致子进程反序列化 SemLock 时 FileNotFoundError
    result_queue = mp.Queue()

    def spawn(gpu_job_dicts):
        procs = []
        original = os.environ.get("CUDA_VISIBLE_DEVICES")
        try:
            for gpu_id in range(num_gpus):
                if not gpu_job_dicts[gpu_id]:
                    continue
                os.environ["CUDA_VISIBLE_DEVICES"] = pool[gpu_id]
                p = mp.Process(
                    target=R._worker_run_jobs,
                    args=(
                        gpu_id, gpu_job_dicts[gpu_id], R.DATA_DIR,
                        str(runs_dir), benchmark, "tabicl_v2",
                        result_queue, JOB_TIMEOUT, tid_map,
                    ),
                )
                p.start()
                procs.append((gpu_id, p))
        finally:
            if original is None:
                os.environ.pop("CUDA_VISIBLE_DEVICES", None)
            else:
                os.environ["CUDA_VISIBLE_DEVICES"] = original
        return procs

    wd_start = time.time()
    retry_count = {}
    final_skip = set()
    round_no = 0
    while True:
        round_no += 1
        done = done_set(runs_dir)
        remaining = [j for j in jobs if job_key(j, tid_map) not in done and job_key(j, tid_map) not in final_skip]
        if not remaining:
            print(f"  剩余 0 个 job，全部完成/跳过", flush=True)
            break
        if time.time() - wd_start > WATCHDOG_MAX:
            print(f"  ⚠ 看门狗总时长超限 {WATCHDOG_MAX}s，放弃剩余 {len(remaining)} 个 job", flush=True)
            break
        remaining.sort(key=lambda j: (1 if "1m" in str(j.task.dataset) else 0, str(j.task.dataset), j.task.repeat, j.task.fold))
        gpu_job_dicts = [[] for _ in range(num_gpus)]
        for i, j in enumerate(remaining):
            gpu_job_dicts[i % num_gpus].append(j.to_dict())
        print(f"  [轮次 {round_no}] 剩余 {len(remaining)} 个 job，分配 {[len(x) for x in gpu_job_dicts]} / GPU {pool}", flush=True)
        processes = spawn(gpu_job_dicts)

        last_count = {g: count_pkl(runs_dir, g) for g, p in processes}
        last_seen = {g: time.time() for g, p in processes}
        alive = {g: p for g, p in processes}
        while any(p.is_alive() for p in alive.values()):
            time.sleep(60)
            if time.time() - wd_start > WATCHDOG_MAX:
                print(f"  ⚠ 看门狗总时长超限 {WATCHDOG_MAX}s，强制终止所有 worker", flush=True)
                for p in alive.values():
                    if p.is_alive():
                        p.kill()
                        p.join(timeout=30)
                alive = {}
                break
            for g, p in list(alive.items()):
                if not p.is_alive():
                    continue
                n = count_pkl(runs_dir, g)
                if n > last_count[g]:
                    last_count[g] = n
                    last_seen[g] = time.time()
                elif time.time() - last_seen[g] > STALL_TIMEOUT:
                    print(f"  ⚠ Worker GPU{g} (pid={p.pid}) 卡死 {STALL_TIMEOUT}s 无新结果，强制终止（剩余 job 下轮重分配）", flush=True)
                    p.kill()
                    p.join(timeout=30)
                    del alive[g]
        for g, p in processes:
            if p.is_alive():
                p.terminate()
                p.join(timeout=30)
            if p.exitcode not in (0, None):
                print(f"  ⚠ Worker GPU{g} (pid={p.pid}) 退出码 {p.exitcode}", flush=True)

        new_done = done_set(runs_dir)
        for j in remaining:
            k = job_key(j, tid_map)
            if k in new_done:
                continue
            retry_count[k] = retry_count.get(k, 0) + 1
            if retry_count[k] >= MAX_JOB_RETRY:
                final_skip.add(k)
                print(f"  ⏭ job {k} 连续 {MAX_JOB_RETRY} 轮未完成，标记跳过", flush=True)

    # 从 pkl 缓存收集结果（不读 result_queue，防死锁）
    all_results = []
    import gzip, pickle as _pkl
    for i in range(num_gpus):
        d = runs_dir / f"_worker_gpu{i}" / "data"
        if not d.exists():
            continue
        for pkl in sorted(d.rglob("results.pkl")):
            try:
                with gzip.open(pkl, "rb") as f:
                    all_results.append(_pkl.load(f))
            except Exception as e:
                print(f"  ⚠ 读取缓存失败 {pkl}: {e}", flush=True)
    print(f"  📦 pkl 收集: {len(all_results)} 条", flush=True)
    return all_results, []


def recover_from_pkl(out_dir, run_cache_key):
    import gzip, pickle as _pkl
    runs_dir = out_dir / "_runs" / run_cache_key
    if not runs_dir.exists():
        return
    raw_path = out_dir / "raw_results.json"
    old_raw = load_raw(raw_path)
    have = {key_of(r) for r in old_raw}
    recovered = list(old_raw)
    for pkl in sorted(runs_dir.rglob("results.pkl")):
        try:
            with gzip.open(pkl, "rb") as f:
                r = _pkl.load(f)
            k = key_of(r)
            if k not in have:
                recovered.append(r)
                have.add(k)
        except Exception as e:
            print(f"  ⚠ 读取缓存失败 {pkl}: {e}", flush=True)
    if len(recovered) > len(old_raw):
        R.save_json(recovered, raw_path)
        print(f"  ↩ 从 pkl 缓存恢复 raw_results.json: {len(old_raw)} → {len(recovered)}", flush=True)


def export_per_dataset_csv(out_dir, model_name, task):
    """从 raw_results.json 聚合生成 per_dataset_results.csv（格式与已有惯例一致）"""
    import csv as _csv

    raw = load_raw(out_dir / "raw_results.json")
    by_ds = {}
    for r in raw:
        tm = r.get("task_metadata", {})
        name = str(tm.get("name"))
        err = r.get("metric_error")
        if err is None:
            continue
        by_ds.setdefault(name, []).append(err)

    def fmt(vals):
        if not vals:
            return "N/A"
        if len(vals) == 1:
            return "%.3f" % vals[0]
        mean = sum(vals) / len(vals)
        std = (sum((v - mean) ** 2 for v in vals) / (len(vals) - 1)) ** 0.5
        return "%.3f±%.3f" % (mean, std)

    label, metric = ("分类", "1-ROC-AUC") if task == "classification" else ("回归", "RMSE")
    path = out_dir.parent / "per_dataset_results.csv"
    names = sorted(by_ds.keys())
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = _csv.writer(f)
        w.writerow(["数据集名字", "split总数", "分类/回归", "指标（越低越好）", f"{model_name}性能", "备注"])
        for n in names:
            vals = by_ds[n]
            w.writerow([n, len(vals), label, metric, fmt(vals), ""])
    print(f"  📄 per_dataset_results.csv: {path} ({len(names)} 数据集)")


def process_model(name, cfg, benchmark, gpu_list=None):
    task = cfg["task"]
    suffix = "_cla" if task == "classification" else "_reg"
    print("=" * 60, flush=True)
    print(f"########## {benchmark.upper()} 评估 {name} ({time.strftime('%Y-%m-%d %H:%M:%S')}) ##########", flush=True)
    out_dir = RESULT_BASE / f"{benchmark}_{cfg['key']}" / benchmark / f"{cfg['name']}{suffix}"
    out_dir.mkdir(parents=True, exist_ok=True)

    run_config = make_run_config(cfg["name"], cfg["ckpt"], benchmark, task)
    run_cache_key = hashlib.sha256(
        json.dumps(run_config, ensure_ascii=True, sort_keys=True).encode("utf-8")
    ).hexdigest()[:16]

    recover_from_pkl(out_dir, run_cache_key)

    _, jobs = build_official_jobs(cfg["ckpt"], benchmark, task)
    official = {(str(j.task.dataset), j.task.repeat, j.task.fold) for j in jobs}
    print(f"  官方 jobs: {len(jobs)} / 数据集 {len(set(k[0] for k in official))}", flush=True)

    old_raw = load_raw(out_dir / "raw_results.json")
    have = {key_of(r) for r in old_raw}
    missing_keys = official - have
    skipped = set()
    if benchmark == "beyondarena":
        skipped = {k for k in missing_keys if any(str(k[0]).startswith(s) for s in SKIP_DATASETS)}
        if skipped:
            print(f"  ⏭ 跳过 {len(skipped)} 个 job（SKIP_DATASETS）：{sorted(set(k[0] for k in skipped))}", flush=True)
        missing_keys -= skipped
    print(f"  已有 {len(have)}，缺失 {len(missing_keys)}（跳过 {len(skipped)}）", flush=True)

    summary_path = out_dir / "summary.json"
    if summary_path.exists():
        summary = json.load(open(summary_path, encoding="utf-8"))
        if summary.get("run_config") != run_config:
            print("  ⚠ 已有 summary 配置不匹配，重置")
            summary = {}
    else:
        summary = {}
    if not summary.get("run_config"):
        summary = {
            "benchmark": benchmark, "model_type": cfg["name"], "task_type": task,
            "arena_adapter": "tabicl_v2",
            "run_config": run_config, "run_cache_key": run_cache_key,
            "num_jobs": len(official), "num_success": len(have),
            "num_failed": 0,
            "start_timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        R.save_json(summary, summary_path)
    if not (out_dir / "errors.json").exists():
        R.save_json({"failed": []}, out_dir / "errors.json")

    if not missing_keys:
        print("  无缺失，跳过")
    else:
        miss_jobs = [j for j in jobs if (str(j.task.dataset), j.task.repeat, j.task.fold) in missing_keys]
        miss_jobs.sort(key=lambda j: (1 if "1m" in str(j.task.dataset) else 0, str(j.task.dataset), j.task.repeat, j.task.fold))
        print(f"  待跑: {len(miss_jobs)} 个 job（1m 大 job 已排到最后）", flush=True)

        t0 = time.time()
        context = R.build_context(benchmark, R.DATA_DIR)
        context.task_metadata_collection.subset_to_jobs(miss_jobs).materialize()
        print(f"  数据就绪，耗时 {time.time() - t0:.1f}s", flush=True)

        # ⚠ tid_map 仅用于 tabarena（其 pkl 缓存目录用 openml tid）；beyondarena 的
        #   pkl 目录用数据集名，若传 tid_map 会导致 done_set/job_key 不匹配、无限重放
        tid_map = build_tid_map(context) if benchmark == "tabarena" else None
        new_results, new_failed = run_jobs(miss_jobs, out_dir, run_cache_key, benchmark, gpu_list=gpu_list, tid_map=tid_map)
        print(f"  运行完成: 成功 {len(new_results)}，失败 {len(new_failed)}", flush=True)

        merged = {key_of(r): r for r in old_raw}
        for r in new_results:
            merged[key_of(r)] = r
        final = list(merged.values())
        R.save_json(final, out_dir / "raw_results.json")

        old_errors = json.load(open(out_dir / "errors.json", encoding="utf-8"))
        old_errors["failed"] = old_errors.get("failed", []) + new_failed
        R.save_json(old_errors, out_dir / "errors.json")

        summary["num_jobs"] = len(official)
        summary["num_success"] = len(final)
        summary["num_failed"] = len(old_errors.get("failed", []))
        summary["elapsed_seconds"] = summary.get("elapsed_seconds", 0) + (time.time() - t0)
        summary["rerun_timestamp"] = time.strftime("%Y-%m-%d %H:%M:%S")
        R.save_json(summary, summary_path)
        print(f"  合并后 raw_results: {len(final)} / 官方 {len(official)}", flush=True)

    export_per_dataset_csv(out_dir, cfg["name"], task)
    print(f"########## 结束 {name} ({time.strftime('%Y-%m-%d %H:%M:%S')}) ##########", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark", default="tabarena", choices=["tabarena", "beyondarena"])
    parser.add_argument("--models", default=",".join(ORDER), help="逗号分隔")
    parser.add_argument("--gpus", default=GPU_LIST, help="GPU 编号列表，如 0,1,2,3,4,5,6")
    args = parser.parse_args()
    models = [m.strip() for m in args.models.split(",") if m.strip()]
    for name in models:
        process_model(name, MODELS[name], args.benchmark, gpu_list=args.gpus)
    print(f"\n===== {args.benchmark.upper()} 全部评估完成 =====")
