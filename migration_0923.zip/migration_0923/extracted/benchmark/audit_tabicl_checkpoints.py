#!/usr/bin/env python3
"""Audit TabICL checkpoint readability, metadata, hash, and finite weights."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
from typing import Any

import torch


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkpoints", nargs="+", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def audit(path: Path) -> dict[str, Any]:
    resolved = path.expanduser().resolve()
    row: dict[str, Any] = {
        "checkpoint": str(resolved),
        "size_bytes": resolved.stat().st_size,
        "sha256": sha256(resolved),
    }
    try:
        checkpoint = torch.load(
            resolved,
            map_location="cpu",
            weights_only=True,
            mmap=True,
        )
        state_dict = checkpoint["state_dict"]
        floating_values = 0
        nonfinite_values = 0
        nonfinite_tensors = 0
        examples: list[str] = []
        for key, value in state_dict.items():
            if not torch.is_tensor(value) or not (
                value.is_floating_point() or value.is_complex()
            ):
                continue
            floating_values += value.numel()
            count = int((~torch.isfinite(value)).sum().item())
            if count:
                nonfinite_tensors += 1
                nonfinite_values += count
                if len(examples) < 10:
                    examples.append(str(key))
        row.update(
            {
                "load_status": "passed",
                "model_impl": checkpoint.get("model_impl"),
                "task_mode": checkpoint.get("task_mode"),
                "state_dict_tensors": len(state_dict),
                "floating_values": floating_values,
                "nonfinite_tensors": nonfinite_tensors,
                "nonfinite_values": nonfinite_values,
                "nonfinite_tensor_examples": examples,
                "health": "healthy" if nonfinite_values == 0 else "invalid_nonfinite",
            }
        )
    except Exception as error:
        row.update(
            {
                "load_status": "failed",
                "health": "invalid_unreadable",
                "error": f"{type(error).__name__}: {error}",
            }
        )
    return row


def main() -> None:
    args = parse_args()
    rows = [audit(path) for path in args.checkpoints]
    payload = {
        "schema_version": 1,
        "status": "complete",
        "checkpoint_count": len(rows),
        "healthy_count": sum(row["health"] == "healthy" for row in rows),
        "invalid_nonfinite_count": sum(
            row["health"] == "invalid_nonfinite" for row in rows
        ),
        "invalid_unreadable_count": sum(
            row["health"] == "invalid_unreadable" for row in rows
        ),
        "checkpoints": rows,
    }
    output = args.output.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, output)
    print(json.dumps({key: payload[key] for key in payload if key != "checkpoints"}))


if __name__ == "__main__":
    main()
