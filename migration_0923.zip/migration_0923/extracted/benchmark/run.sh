python -u run_tabarena_cls.py \
    --model tabicl \
    --checkpoint /ssd/lamdatfm/chengzj/models/self/test/tabicl/tabicl-classifier-v2-20260212.ckpt \
    --data_dir /ssd/lamdatfm/chengzj/datasets/openml_cache \
    --benchmark both --num_gpus 8 --model_name self_260721_step500k 2>&1 | tee benchmark_cls.txt

python -u run_tabarena_reg.py \
    --model tabicl \
    --checkpoint /ssd/lamdatfm/chengzj/models/self/test/tabicl/tabicl-regressor-v2-20260212.ckpt \
    --data_dir /ssd/lamdatfm/chengzj/datasets/openml_cache \
    --benchmark both --num_gpus 8 --model_name self_260721_step500k 2>&1 | tee benchmark_reg.txt