#!/bin/bash
# 增量 patch pylib 副本: 校验循环也要跳过 checkpoint 中多余的 key
set -e
CP=/ssd/lamdatfm/chengzj/pylib/exaonetabular/checkpoint.py

/ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python - "$CP" <<'EOF'
import sys
p = sys.argv[1]
src = open(p, encoding="utf-8").read()

old = """    for key, value in checkpoint.items():
        target = targets[key]
        if value.layout is not torch.strided or value.dtype not in _CHECKPOINT_DTYPES:
            raise ValueError("checkpoint tensor has an unsupported domain")
        if value.shape != target.shape:
            raise ValueError("checkpoint tensor metadata does not match the model")
        if not bool(torch.isfinite(value).all()):
            raise ValueError("checkpoint tensor contains a nonfinite value")"""

new = """    for key in targets:
        value = checkpoint[key]
        if value.layout is not torch.strided or value.dtype not in _CHECKPOINT_DTYPES:
            raise ValueError("checkpoint tensor has an unsupported domain")
        if value.shape != target.shape:
            raise ValueError("checkpoint tensor metadata does not match the model")
        if not bool(torch.isfinite(value).all()):
            raise ValueError("checkpoint tensor contains a nonfinite value")"""

assert src.count(old) == 1, f"expected exactly 1 occurrence, got {src.count(old)}"
src = src.replace(old, new)
open(p, "w", encoding="utf-8").write(src)
print("PATCH2 OK")
EOF

echo "===== 再次验证 ====="
cd /ssd/lamdatfm/chengzj/benchmark
PYTHONPATH=/ssd/lamdatfm/chengzj/pylib /ssd/lamdatfm/chengzj/miniconda3/envs/arena/bin/python - <<'EOF'
import exaonetabular, os
print("loaded from:", os.path.dirname(exaonetabular.__file__))

import numpy as np
from exaonetabular import EXAONETabularRegressor

CKPT = "/ssd/lamdatfm/chengzj/models/exaone-tabular-regressor-v1_default.safetensors"
m = EXAONETabularRegressor.from_pretrained(weights=CKPT, device="cpu", seed=0)
print("LOAD OK, is_fitted =", m.is_fitted)

rng = np.random.default_rng(0)
Xtr = rng.normal(size=(200, 5)).astype(np.float32)
ytr = (Xtr[:, 0] * 2 + Xtr[:, 1] - Xtr[:, 2]).astype(np.float32)
Xte = rng.normal(size=(10, 5)).astype(np.float32)
m.fit(Xtr, ytr)
p = m.predict(Xte)
print("predict OK, shape:", p.shape, "sample:", np.round(p[:5], 4))
assert np.isfinite(p).all()
print("ALL GOOD")
EOF
