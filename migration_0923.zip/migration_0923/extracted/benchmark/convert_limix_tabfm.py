#!/usr/bin/env python3
"""
将 tabarena_limix-2M / tabarena_limix-16M / tabarena_tabfm 的原始结果
转换为 benchmark_results_tabicl_v21/tabarena/per_dataset_results.csv 的格式。

指标口径（与 TabArena 默认一致）:
- binary 分类: 1 - ROC-AUC (limix 直接用 AutoGluon 的 metric_error)
- multiclass 分类: log_loss (limix 直接用 metric_error; tabfm 从 y_true/y_pred_proba 计算)
- 回归: RMSE (limix 直接用 metric_error; tabfm 的 y_true/y_pred 在标准化空间，
  通过重新加载 openml 数据重 fit StandardScaler 还原到原始空间后计算，与 limix 同口径)

输出: benchmark_results_tabicl_v21/tabarena/per_dataset_results_limix_tabfm.csv
"""
from __future__ import annotations

import csv
import json
import math
from collections import defaultdict
from pathlib import Path

import numpy as np

BASE = Path("/ssd/lamdatfm/chengzj/benchmark")
LFS_OBJ = BASE / ".git/lfs/objects"
RESULTS = BASE / "benchmark_results"

# LFS oid -> (目录, 标签)
RAW_SOURCES = {
    "b637c07eedc24c9a67c29c697a34a53dbd186905c9b6827b2a85d3e2e56ace14": ("tabarena_limix-2M", "cls", "limix-2M"),
    "d10c186fb92317b73f64c95563f92061ea5f8112b8fc3b22d86c929d0d118e90": ("tabarena_limix-2M", "reg", "limix-2M"),
    "45d5f019032365d4a9d874d168160cee9340c378de5807a5c4579f3270a2df3b": ("tabarena_limix-16M", "cls", "limix-16M"),
    "989700507700faf3cc9c4535ad4d80b11b2c4bc98dff5cd253e91af3412e8b5e": ("tabarena_limix-16M", "reg", "limix-16M"),
    "9e396cac67ebe7784b633343ac9722fb6dfbc0823c00c1f6fa158d9fb91012e4": ("tabarena_tabfm", "reg", "tabfm"),
}
# tabfm cls 是真实 JSON 文件
TABFM_CLS_RAW = RESULTS / "tabarena_tabfm/cls/raw_results.json"

V21_CSV = BASE / "benchmark_results_tabicl_v21/tabarena/per_dataset_results.csv"
# benchmark_results_tabicl_v21/ 目录属于 yuky 用户，lamdatfm 无写权限，
# 因此输出到有写权限的 benchmark_results/ 下
OUT_CSV = BASE / "benchmark_results/per_dataset_results_limix_tabfm.csv"

MODEL_ORDER = ["limix-2M", "limix-16M", "tabfm"]
TASK_LABEL = {"classification": "分类", "regression": "回归"}

# tabfm worker 回归时用 StandardScaler 标准化 y（统计量来自训练集），保存的是标准化空间的值；
# 这里从本地 openml 缓存重新加载数据，按相同 (repeat, fold) 重 fit scaler，还原到原始空间
OPENML_ROOT = "/ssd/lamdatfm/chengzj/datasets/openml_cache"


def load_lfs_json(oid: str):
    path = LFS_OBJ / oid[:2] / oid[2:4] / oid
    if not path.exists():
        raise FileNotFoundError(f"LFS object missing: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def collect_limix(records: list[dict]) -> dict[str, dict[str, float]]:
    """{dataset: {split_key: metric_error}}"""
    out: dict[str, dict[str, float]] = defaultdict(dict)
    for r in records:
        if r is None or "metric_error" not in r or r["metric_error"] is None:
            continue
        tm = r.get("task_metadata") or {}
        ds = tm.get("name") or r.get("dataset")
        fold = tm.get("fold", r.get("fold"))
        repeat = tm.get("repeat", r.get("repeat", 0))
        if ds is None or fold is None:
            continue
        try:
            err = float(r["metric_error"])
        except (ValueError, TypeError):
            continue
        out[ds][f"r{repeat}_f{fold}"] = err
    return dict(out)


def collect_tabfm_cls(records: list[dict]) -> dict[str, dict[str, float]]:
    """{dataset: {split_key: metric_error}}
    binary  -> 1 - ROC-AUC
    multiclass -> log_loss
    """
    from sklearn.metrics import log_loss, roc_auc_score

    out: dict[str, dict[str, float]] = defaultdict(dict)
    for r in records:
        ds = r.get("dataset")
        fold, repeat = r.get("fold"), r.get("repeat", 0)
        if ds is None or fold is None:
            continue
        y_true = np.asarray(r["y_true"])
        proba = r["y_pred_proba"]
        pt = r.get("problem_type", "binary")
        try:
            if pt == "binary":
                yp = np.asarray(proba, dtype=float)
                err = 1.0 - float(roc_auc_score(y_true, yp))
            else:
                yp = np.asarray(proba, dtype=float)
                n_classes = yp.shape[1]
                err = float(log_loss(y_true, yp, labels=list(range(n_classes))))
        except Exception as e:
            print(f"  [WARN] tabfm cls {ds} f{fold}r{repeat}: {e}")
            continue
        out[ds][f"r{repeat}_f{fold}"] = err
    return dict(out)


def collect_tabfm_reg(records: list[dict], tid_map: dict[str, int]) -> dict[str, dict[str, float]]:
    """{dataset: {split_key: RMSE}}（原始 y 空间，与 limix 同口径）

    还原方式: y_pred_raw = y_pred_scaled * std_train + mean_train
    （scaler 在每个 split 的 y_train 上重 fit，与 worker 一致）
    """
    import openml
    from sklearn.preprocessing import StandardScaler

    openml.config.set_root_cache_directory(OPENML_ROOT)
    out: dict[str, dict[str, float]] = defaultdict(dict)
    cache: dict[str, tuple] = {}
    for r in records:
        ds = r.get("dataset")
        fold, repeat = r.get("fold"), r.get("repeat", 0)
        if ds is None or fold is None:
            continue
        y_true_s = np.asarray(r["y_true"], dtype=float)
        y_pred_s = np.asarray(r["y_pred"], dtype=float)
        try:
            if ds not in cache:
                tid = tid_map.get(ds)
                if tid is None:
                    print(f"  [WARN] tabfm reg {ds}: 无 tid，跳过")
                    continue
                task = openml.tasks.get_task(tid)
                _, y_full = task.get_X_and_y(dataset_format="dataframe")
                cache[ds] = (task, y_full)
            task, y_full = cache[ds]
            train_idx, test_idx = task.get_train_test_split_indices(fold=fold, repeat=repeat)
            y_train_np = y_full.iloc[train_idx].to_numpy()
            y_test_raw = y_full.iloc[test_idx].to_numpy().ravel()
            scaler = StandardScaler()
            scaler.fit(y_train_np.reshape(-1, 1))
            y_pred_raw = y_pred_s * scaler.scale_[0] + scaler.mean_[0]
            rmse = float(np.sqrt(np.mean((y_test_raw - y_pred_raw) ** 2)))
        except Exception as e:
            print(f"  [WARN] tabfm reg {ds} f{fold}r{repeat}: {e}")
            continue
        out[ds][f"r{repeat}_f{fold}"] = rmse
    return dict(out)


def format_value(mean: float | None, std: float | None) -> str:
    if mean is None:
        return "N/A"
    if std is None or std == 0.0:
        return f"{mean:.3f}"
    return f"{mean:.3f}±{std:.3f}"


def main() -> None:
    # 1. 读取 v21 CSV 作为行模板（保持数据集顺序与分类/回归标记）
    template_rows = []
    with open(V21_CSV, encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            template_rows.append({
                "数据集名字": row["数据集名字"],
                "分类/回归": row["分类/回归"],
            })

    # 2. 加载 limix 结果（从 LFS 对象），同时收集 dataset -> tid 映射（用于 tabfm 回归还原）
    print("加载 limix / tabfm reg 结果（LFS 对象）...")
    per_model_task: dict[tuple[str, str], dict] = {}
    tid_map: dict[str, int] = {}
    for oid, (dir_, tag, model) in RAW_SOURCES.items():
        records = load_lfs_json(oid)
        task_type = "classification" if tag == "cls" else "regression"
        if model.startswith("limix"):
            per_model_task[(model, task_type)] = collect_limix(records)
            if task_type == "regression":
                for r in records:
                    tm = r.get("task_metadata") or {}
                    if tm.get("name") and tm.get("tid"):
                        tid_map[tm["name"]] = tm["tid"]
        else:
            per_model_task[(model, task_type)] = collect_tabfm_reg(records, tid_map)
        print(f"  {model} {tag}: {len(records)} 条原始记录 -> "
              f"{len(per_model_task[(model, task_type)])} 个数据集")
    print(f"  tid 映射: {len(tid_map)} 个数据集")

    # 3. 加载 tabfm cls（真实 JSON）
    print("加载 tabfm cls 结果...")
    with open(TABFM_CLS_RAW, encoding="utf-8") as f:
        tabfm_cls_records = json.load(f)
    per_model_task[("tabfm", "classification")] = collect_tabfm_cls(tabfm_cls_records)
    print(f"  tabfm cls: {len(tabfm_cls_records)} 条原始记录 -> "
          f"{len(per_model_task[('tabfm', 'classification')])} 个数据集")

    # 4. 生成 per-dataset 行
    rows = []
    for t in template_rows:
        ds = t["数据集名字"]
        task_type = "classification" if t["分类/回归"] == "分类" else "regression"
        metric_name = "1-ROC-AUC" if task_type == "classification" else "RMSE"

        model_splits: dict[str, dict[str, float]] = {}
        for model in MODEL_ORDER:
            model_splits[model] = per_model_task.get((model, task_type), {}).get(ds, {})

        # split 总数 = 各模型 split 数的最大值（与原生成逻辑一致）
        n_splits = max((len(v) for v in model_splits.values()), default=0)

        notes = []
        max_n = n_splits
        for model in MODEL_ORDER:
            n = len(model_splits[model])
            if n == 0:
                notes.append(f"{model} 无结果")
            elif max_n > 0 and n < max_n:
                notes.append(f"{model} 仅 {n}/{max_n} 个split")
        note = "；".join(notes)

        row = {
            "数据集名字": ds,
            "split总数": n_splits,
            "分类/回归": t["分类/回归"],
            "指标（越低越好）": metric_name,
            "备注": note,
        }
        for model in MODEL_ORDER:
            values = list(model_splits[model].values())
            mean = float(np.mean(values)) if values else None
            std = float(np.std(values, ddof=1)) if len(values) > 1 else None
            row[f"{model}性能"] = format_value(mean, std)
        rows.append(row)

    # 5. 写 CSV（utf-8-sig，与 v21 一致）
    fields = [
        "数据集名字", "split总数", "分类/回归", "指标（越低越好）",
        *[f"{m}性能" for m in MODEL_ORDER], "备注",
    ]
    with open(OUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    print(f"\n已写出 {OUT_CSV}: {len(rows)} 行")

    # 6. 简要打印
    for row in rows:
        print(f"  {row['数据集名字']:<45} split={row['split总数']:<3} "
              f"{' | '.join(row[f'{m}性能'] for m in MODEL_ORDER)}  {row['备注']}")


if __name__ == "__main__":
    main()
