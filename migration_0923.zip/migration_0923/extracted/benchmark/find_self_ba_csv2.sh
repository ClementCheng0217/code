#!/bin/bash
# 列出 7 个 self 模型在 BeyondArena 上的 per_dataset_results.csv 完整位置
BASE=/ssd/lamdatfm/chengzj/benchmark/benchmark_results
for d in \
  beyondarena_reg_s1_260808_float32 \
  beyondarena_reg_s1_260813_muon \
  beyondarena_reg_s2_260815_float32 \
  beyondarena_reg_s3_260820_float32 \
  beyondarena_cls_s1_260817 \
  beyondarena_cls_s3_260819 \
  beyondarena_260814_s3amp ; do
  echo "=== $d ==="
  find $BASE/$d -name 'per_dataset_results.csv' 2>/dev/null
done
